/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type IndustryType = 'salon' | 'fitness' | 'tutor' | 'doctor' | 'consultant' | 'coach';

export interface Service {
  id: string;
  name: string;
  duration: number; // in minutes
  price: number;
  description: string;
  industry: IndustryType;
  icon?: string;
}

export interface StaffMember {
  id: string;
  name: string;
  role: string;
  avatar: string;
  rating: number;
  specialty: string;
  services: string[]; // service IDs
  industry: IndustryType;
  email: string;
  workingHours: {
    start: string; // "09:00"
    end: string;   // "17:00"
  };
}

export type BookingStatus = 'pending' | 'confirmed' | 'completed' | 'cancelled';

export interface Booking {
  id: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  customerNotes?: string;
  serviceId: string;
  staffId: string;
  date: string; // "YYYY-MM-DD"
  timeSlot: string; // "10:30"
  customDuration?: number; // duration in minutes selected by the user
  status: BookingStatus;
  price: number;
  createdAt: string;
  industry: IndustryType;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  notes: string;
  totalBookings: number;
  lifetimeSpent: number;
  lastBookingDate?: string;
}

export interface EmailLog {
  id: string;
  bookingId: string;
  recipientEmail: string;
  type: 'confirmation' | 'reminder' | 'cancellation';
  subject: string;
  body: string;
  sentAt: string;
}

export interface SupabaseConfig {
  supabaseUrl: string;
  supabaseAnonKey: string;
  isConnected: boolean;
}
