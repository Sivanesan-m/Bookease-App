/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Scissors, Dumbbell, GraduationCap, Stethoscope, Briefcase, Compass,
  ChevronRight, Calendar, Clock, User, Mail, Phone, FileText, CheckCircle2,
  CalendarCheck2, ArrowLeft, Star, Heart, Sparkles, CheckCircle, Smartphone,
  Linkedin, Github, Instagram, MailCheck, Send, ExternalLink
} from 'lucide-react';
import { Service, StaffMember, IndustryType, Booking } from '../types';
import { INDUSTRIES, SERVICES, STAFF } from '../data';
import { bookEaseStore } from '../supabaseClient';
import { motion, AnimatePresence } from 'motion/react';
import { parseAISchedulingRequest } from '../lib/aiHelper';

interface PublicBookingProps {
  currentIndustry: IndustryType;
  onNavigateToDashboard: () => void;
  onIndustryChange: (ind: IndustryType) => void;
  isDarkMode?: boolean;
}

export default function PublicBooking({ 
  currentIndustry, 
  onNavigateToDashboard,
  onIndustryChange,
  isDarkMode = false
}: PublicBookingProps) {
  const [step, setStep] = useState<number>(1);
  
  // Conversational AI States
  const [aiPrompt, setAiPrompt] = useState<string>('');
  const [aiParsing, setAiParsing] = useState<boolean>(false);
  const [aiError, setAiError] = useState<string>('');
  const [aiSuggestedResult, setAiSuggestedResult] = useState<any | null>(null);
  
  // Selection states
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [customDuration, setCustomDuration] = useState<number>(30);
  const [selectedStaff, setSelectedStaff] = useState<StaffMember | null>(null);
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedTime, setSelectedTime] = useState<string>('');
  
  // Custom forms
  const [customerName, setCustomerName] = useState<string>('');
  const [customerEmail, setCustomerEmail] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [customerNotes, setCustomerNotes] = useState<string>('');
  
  // Success states
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [createdBooking, setCreatedBooking] = useState<Booking | null>(null);

  // Auto scroll to top on steps
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [step]);

  // Filters
  const industryInfo = INDUSTRIES.find(ind => ind.id === currentIndustry) || INDUSTRIES[0];
  const servicesOfIndustry = SERVICES.filter(srv => srv.industry === currentIndustry);
  
  // Filter staff who offer this specific service (if service is selected) or are in this industry
  const eligibleStaff = STAFF.filter(st => {
    if (selectedService) {
      return st.services.includes(selectedService.id);
    }
    return st.industry === currentIndustry;
  });

  // Calendar dates generation (next 14 days starting today)
  const getNext14Days = () => {
    const dates = [];
    const today = new Date();
    // In our simulation, today is 2026-06-09
    const baseDate = new Date('2026-06-09');
    
    for (let i = 0; i < 14; i++) {
      const nextDate = new Date(baseDate);
      nextDate.setDate(baseDate.getDate() + i);
      
      const year = nextDate.getFullYear();
      const month = String(nextDate.getMonth() + 1).padStart(2, '0');
      const day = String(nextDate.getDate()).padStart(2, '0');
      const dateString = `${year}-${month}-${day}`;
      
      const weekdayName = nextDate.toLocaleDateString('en-US', { weekday: 'short' });
      const dayNum = nextDate.getDate();
      const monthName = nextDate.toLocaleDateString('en-US', { month: 'short' });
      
      dates.push({ dateString, weekdayName, dayNum, monthName });
    }
    return dates;
  };

  const datesList = getNext14Days();

  // Get service icon
  const getIndustryIcon = (ind: IndustryType, sizeClass = "w-5 h-5") => {
    switch (ind) {
      case 'salon': return <Scissors className={sizeClass} />;
      case 'fitness': return <Dumbbell className={sizeClass} />;
      case 'tutor': return <GraduationCap className={sizeClass} />;
      case 'doctor': return <Stethoscope className={sizeClass} />;
      case 'consultant': return <Briefcase className={sizeClass} />;
      case 'coach': return <Compass className={sizeClass} />;
      default: return <Sparkles className={sizeClass} />;
    }
  };

  // Generate availability time slots based on chosen staff hours and designated service duration
  const getTimeSlotsForDate = () => {
    const startHour = selectedStaff ? parseInt(selectedStaff.workingHours.start.split(':')[0]) : 9;
    const endHour = selectedStaff ? parseInt(selectedStaff.workingHours.end.split(':')[0]) : 17;
    const startMin = selectedStaff ? parseInt(selectedStaff.workingHours.start.split(':')[1]) || 0 : 0;
    const endMin = selectedStaff ? parseInt(selectedStaff.workingHours.end.split(':')[1]) || 0 : 0;
    
    const startTotalMins = startHour * 60 + startMin;
    const endTotalMins = endHour * 60 + endMin;
    const duration = customDuration || (selectedService ? selectedService.duration : 30);
    
    const list = [];
    // Generate intervals every 30 minutes, but check that start_time + duration <= end_time
    for (let timeMins = startTotalMins; timeMins + duration <= endTotalMins; timeMins += 30) {
      const h = Math.floor(timeMins / 60);
      const m = timeMins % 60;
      const formattedTime = `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
      list.push(formattedTime);
    }
    return list;
  };

  const availableSlots = getTimeSlotsForDate();

  const handleBookingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedService || !selectedStaff || !selectedDate || !selectedTime) return;

    if (!customerName || !customerEmail || !customerPhone) {
      alert('Please fill out all required details.');
      return;
    }

    setIsSubmitting(true);

    try {
      // Simulate small API lag of 800ms
      await new Promise(resolve => setTimeout(resolve, 800));

      const mockBookingData = {
        customerName,
        customerEmail,
        customerPhone,
        customerNotes,
        serviceId: selectedService.id,
        staffId: selectedStaff.id,
        date: selectedDate,
        timeSlot: selectedTime,
        customDuration: customDuration,
        status: 'confirmed' as const, // Automatically confirmed for instant demo flow
        price: selectedService.price,
        industry: currentIndustry
      };

      const result = await bookEaseStore.createBooking(mockBookingData);
      setCreatedBooking(result);
      setStep(5);
    } catch (err) {
      console.error('Failed to create booking', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const restartBookingFlow = () => {
    setSelectedService(null);
    setCustomDuration(30);
    setSelectedStaff(null);
    setSelectedDate('');
    setSelectedTime('');
    setCustomerName('');
    setCustomerEmail('');
    setCustomerPhone('');
    setCustomerNotes('');
    setCreatedBooking(null);
    setStep(1);
  };

  // Industry color helpers
  const getThemeColors = (ind: IndustryType) => {
    switch (ind) {
      case 'salon': return { bg: 'bg-indigo-600', text: 'text-indigo-600', border: 'border-indigo-600', ring: 'focus:ring-indigo-500', headerBg: isDarkMode ? 'bg-indigo-950/20' : 'bg-indigo-50' };
      case 'fitness': return { bg: 'bg-emerald-600', text: 'text-emerald-600', border: 'border-emerald-600', ring: 'focus:ring-emerald-500', headerBg: isDarkMode ? 'bg-emerald-950/20' : 'bg-emerald-50' };
      case 'tutor': return { bg: 'bg-amber-600', text: 'text-amber-600', border: 'border-amber-600', ring: 'focus:ring-amber-500', headerBg: isDarkMode ? 'bg-amber-950/20' : 'bg-amber-50' };
      case 'doctor': return { bg: 'bg-rose-600', text: 'text-rose-600', border: 'border-rose-600', ring: 'focus:ring-rose-500', headerBg: isDarkMode ? 'bg-rose-950/20' : 'bg-rose-50' };
      case 'consultant': return { bg: 'bg-sky-600', text: 'text-sky-600', border: 'border-sky-600', ring: 'focus:ring-sky-500', headerBg: isDarkMode ? 'bg-sky-950/20' : 'bg-sky-50' };
      case 'coach': return { bg: 'bg-violet-600', text: 'text-violet-600', border: 'border-violet-600', ring: 'focus:ring-violet-500', headerBg: isDarkMode ? 'bg-violet-950/20' : 'bg-violet-50' };
      default: return { bg: 'bg-brand-600', text: 'text-brand-600', border: 'border-brand-600', ring: 'focus:ring-brand-500', headerBg: isDarkMode ? 'bg-slate-900/40' : 'bg-gray-50' };
    }
  };

  const handleAIParsing = async () => {
    if (!aiPrompt.trim()) return;
    setAiParsing(true);
    setAiError('');
    setAiSuggestedResult(null);

    // AI dynamic prediction spinner simulation
    await new Promise(resolve => setTimeout(resolve, 1400));
    
    const parsed = parseAISchedulingRequest(aiPrompt);
    if (parsed) {
      setAiSuggestedResult(parsed);
    } else {
      setAiError("Sorry, we couldn't resolve that prompt. Try styling statements such as: 'Precision haircut with Sarah Jenkins tomorrow morning'.");
    }
    setAiParsing(false);
  };

  const applyAISuggestion = () => {
    if (!aiSuggestedResult) return;
    
    if (aiSuggestedResult.industry !== currentIndustry) {
      onIndustryChange(aiSuggestedResult.industry);
    }
    setSelectedService(aiSuggestedResult.service);
    if (aiSuggestedResult.service) {
      setCustomDuration(aiSuggestedResult.service.duration);
    }
    setSelectedStaff(aiSuggestedResult.staff);
    setSelectedDate(aiSuggestedResult.dateStr);
    setSelectedTime(aiSuggestedResult.timeSlot);
    
    // Skip directly to detail validation step!
    setStep(4);
    
    setAiPrompt('');
    setAiSuggestedResult(null);
  };

  const scheme = getThemeColors(currentIndustry);

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Top Banner Industry Picker */}
      {step < 5 && (
        <div className={`rounded-2xl border p-6 mb-8 text-center transition-all duration-300 ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white shadow-sm border-slate-100'}`}>
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-widest block mb-2">BookEase Public Scheduler</span>
          <h2 className={`text-2xl font-bold mb-4 ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>Select Your Service Industry</h2>
          
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {INDUSTRIES.map((ind) => {
              const active = ind.id === currentIndustry;
              return (
                <button
                  key={ind.id}
                  id={`btn_industry_select_${ind.id}`}
                  onClick={() => {
                    onIndustryChange(ind.id);
                    restartBookingFlow();
                  }}
                  className={`flex flex-col items-center justify-center p-3 rounded-xl border transition-all duration-300 group cursor-pointer ${
                    active 
                      ? 'border-slate-800 bg-slate-900 text-white shadow-md dark:bg-indigo-600 dark:border-indigo-500' 
                      : isDarkMode 
                        ? 'border-slate-800 bg-slate-950 text-slate-300 hover:bg-slate-900' 
                        : 'border-slate-100 hover:border-slate-300 bg-slate-50 hover:bg-white text-slate-700'
                  }`}
                >
                  <div className={`p-2 rounded-lg mb-2 ${active ? 'bg-slate-800 text-white dark:bg-indigo-700' : isDarkMode ? 'bg-slate-900 text-slate-300' : 'bg-white text-slate-700 group-hover:scale-110 transition-transform'}`}>
                    {getIndustryIcon(ind.id, "w-5 h-5")}
                  </div>
                  <span className="text-xs font-medium whitespace-nowrap">{ind.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Main Booking Panel */}
      <div className={`rounded-3xl shadow-xl border overflow-hidden transition-all duration-300 ${isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-100'}`}>
        {/* Step Indicator Header */}
        {step < 5 && (
          <div className={`p-6 sm:p-8 ${scheme.headerBg} border-b flex items-center justify-between transition ${isDarkMode ? 'border-slate-800' : 'border-slate-100'}`}>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className={`text-xs px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider border ${isDarkMode ? 'bg-slate-950 border-slate-800 text-slate-300' : 'bg-white border-slate-200'} ${scheme.text}`}>
                  {industryInfo.name}
                </span>
              </div>
              <h1 className={`text-xl sm:text-2xl font-bold ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>
                {step === 1 && "Choose Your Service"}
                {step === 2 && "Choose Your Professional"}
                {step === 3 && "Select Date & Time"}
                {step === 4 && "Confirm Booking Information"}
              </h1>
            </div>
            
            {/* Steps Progress Visualizer */}
            <div className="hidden sm:flex items-center gap-1.5">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="flex items-center">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold ${
                    step === i 
                      ? `${scheme.bg} text-white font-bold hMR-disable shadow-md` 
                      : step > i 
                        ? 'bg-slate-800 text-white' 
                        : isDarkMode ? 'bg-slate-950 text-slate-500' : 'bg-slate-100 text-slate-400'
                  }`}>
                    {step > i ? '✓' : i}
                  </div>
                  {i < 4 && <div className={`w-6 h-0.5 ${step > i ? 'bg-slate-800' : isDarkMode ? 'bg-slate-950' : 'bg-slate-100'}`} />}
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="p-6 sm:p-8">
          <AnimatePresence mode="wait">
            {/* STEP 1: SERVICE SELECTION */}
            {step === 1 && (
              <motion.div
                key="step1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
              >
                {/* Generative AI Copilot Bar */}
                <div className={`p-5 rounded-2xl border backdrop-blur-xl mb-6 relative overflow-hidden transition-all duration-300 ${
                  isDarkMode 
                    ? 'bg-gradient-to-br from-indigo-950/30 to-slate-900/60 border-indigo-500/25 text-white' 
                    : 'bg-gradient-to-br from-indigo-50/70 to-purple-50/40 border-indigo-100/80 text-slate-800 shadow-sm'
                }`}>
                  <div className="absolute right-0 top-0 bottom-0 w-24 bg-gradient-to-l from-indigo-500/5 to-transparent pointer-events-none" />
                  <div className="flex items-center gap-2 mb-2">
                    <div className="bg-indigo-600 text-white p-1.5 rounded-lg">
                      <Sparkles className="w-4 h-4 animate-pulse text-indigo-200" />
                    </div>
                    <div>
                      <h4 className="text-sm font-black tracking-tight flex items-center gap-1">
                        BookEase AI Copilot <span className="text-[8px] tracking-wider uppercase bg-indigo-500/10 text-indigo-400 px-1.5 py-0.5 rounded">Active</span>
                      </h4>
                      <p className="text-[9px] text-indigo-400 font-extrabold uppercase">State Scheduling Co-Processor</p>
                    </div>
                  </div>

                  <p className="text-xs text-slate-400 mb-3.5 leading-relaxed">
                    Simply type your requirements (e.g. <em>"an afternoon workout with Harrison next Monday"</em>) to configure services, staff, dates, and times automatically!
                  </p>

                  <div className="flex flex-col sm:flex-row gap-2">
                    <input
                      type="text"
                      value={aiPrompt}
                      onChange={(e) => setAiPrompt(e.target.value)}
                      placeholder="e.g. Hair color with Chloe on Thursday afternoon..."
                      className={`flex-1 px-4 py-3 text-xs rounded-xl border focus:outline-none focus:ring-2 focus:ring-indigo-500/15 focus:border-indigo-500/60 transition ${
                        isDarkMode 
                          ? 'bg-slate-950/80 border-slate-800 text-white placeholder-slate-500' 
                          : 'bg-white border-slate-200 text-slate-800 placeholder-slate-400'
                      }`}
                      onKeyDown={(e) => { if (e.key === 'Enter') handleAIParsing(); }}
                    />
                    <button
                      type="button"
                      disabled={aiParsing || !aiPrompt.trim()}
                      onClick={handleAIParsing}
                      className="px-5 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black flex items-center justify-center gap-1.5 transition active:scale-97 disabled:opacity-50 cursor-pointer"
                    >
                      {aiParsing ? (
                        <>
                          <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin inline-block" />
                          <span>Parsing...</span>
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>Analyze with AI</span>
                        </>
                      )}
                    </button>
                  </div>

                  {aiError && (
                    <div className="mt-3 text-xs text-rose-400 bg-rose-500/10 border border-rose-500/20 p-2.5 rounded-xl font-medium">
                      ⚠️ {aiError}
                    </div>
                  )}

                  <AnimatePresence>
                    {aiSuggestedResult && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className={`mt-4 p-4 rounded-xl border relative ${
                          isDarkMode 
                            ? 'bg-slate-950/60 border-indigo-500/20' 
                            : 'bg-indigo-50/50 border-indigo-200/60 text-slate-700'
                        }`}
                      >
                        <h5 className={`text-xs font-bold mb-1.5 flex items-center gap-1.5 ${isDarkMode ? 'text-indigo-300' : 'text-indigo-700'}`}>
                          <CheckCircle2 className="w-4.5 h-4.5 text-emerald-400" />
                          Coordinate Proposal Formulated
                        </h5>
                        <p className="text-xs mb-3 leading-relaxed" dangerouslySetInnerHTML={{ __html: aiSuggestedResult.explanation }} />
                        
                        <div className="flex gap-2 justify-end">
                          <button
                            type="button"
                            onClick={() => setAiSuggestedResult(null)}
                            className="px-3 py-1.5 rounded-lg border text-[10px] font-bold text-slate-400 hover:text-slate-300 cursor-pointer"
                          >
                            Discard
                          </button>
                          <button
                            type="button"
                            onClick={applyAISuggestion}
                            className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-[10px] font-black flex items-center gap-1 cursor-pointer shadow-md"
                          >
                            <Sparkles className="w-3 h-3" /> Execute AI Scheduler Setup
                          </button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <div className="grid gap-4">
                  {servicesOfIndustry.map((srv) => (
                    <div
                      key={srv.id}
                      id={`srv_card_${srv.id}`}
                      onClick={() => {
                        setSelectedService(srv);
                        setCustomDuration(srv.duration);
                        // Auto advance to next step or reset selections
                        setSelectedStaff(null);
                        setSelectedDate('');
                        setSelectedTime('');
                        setStep(2);
                      }}
                      className={`group p-5 rounded-2xl border-2 transition-all duration-300 cursor-pointer text-left flex flex-col md:flex-row justify-between items-start md:items-center gap-4 ${
                        selectedService?.id === srv.id
                          ? isDarkMode ? 'border-indigo-600 bg-indigo-950/20' : 'border-slate-800 bg-slate-50/50'
                          : isDarkMode ? 'border-slate-800 hover:border-slate-700 hover:bg-slate-800/10' : 'border-slate-100 hover:border-slate-300 hover:bg-slate-50/20'
                      }`}
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1.5">
                          <h3 className={`font-bold group-hover:text-indigo-400 text-lg ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>{srv.name}</h3>
                          <span className={`text-xs px-2 py-0.5 rounded-full flex items-center gap-1 ${isDarkMode ? 'bg-slate-950 text-slate-400' : 'bg-slate-100 text-slate-500'}`}>
                            <Clock className="w-3" /> {srv.duration} mins
                          </span>
                        </div>
                        <p className={`text-sm leading-relaxed ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>{srv.description}</p>
                      </div>
                      <div className={`flex items-center justify-between w-full md:w-auto gap-4 self-stretch md:self-auto pt-3 md:pt-0 border-t md:border-t-0 ${isDarkMode ? 'border-slate-800' : 'border-slate-100'}`}>
                        <span className={`text-xl font-black ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>${srv.price}</span>
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
                          selectedService?.id === srv.id 
                            ? 'bg-slate-900 text-white' 
                            : isDarkMode ? 'bg-slate-800 text-slate-400' : 'bg-slate-100 text-slate-500 group-hover:bg-slate-800 group-hover:text-white'
                        }`}>
                          <ChevronRight className="w-5 h-5" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* STEP 2: STAFF SELECTION */}
            {step === 2 && (
              <motion.div
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
              >
                <button
                  onClick={() => setStep(1)}
                  className="inline-flex items-center gap-2 text-sm font-semibold text-slate-500 hover:text-slate-800 mb-6 group"
                >
                  <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" /> Back to Services
                </button>

                <div className="grid sm:grid-cols-2 gap-4">
                  {eligibleStaff.map((st) => {
                    const isSelected = selectedStaff?.id === st.id;
                    return (
                      <div
                        key={st.id}
                        id={`staff_card_${st.id}`}
                        onClick={() => {
                          setSelectedStaff(st);
                          setSelectedDate('');
                          setSelectedTime('');
                          setStep(3);
                        }}
                        className={`p-5 rounded-2xl border-2 transition-all duration-300 cursor-pointer text-left flex gap-4 ${
                          isSelected
                            ? 'border-slate-800 bg-slate-50/50 shadow-md'
                            : 'border-slate-100 hover:border-slate-300 hover:bg-slate-50/25'
                        }`}
                      >
                        <img 
                          referrerPolicy="no-referrer"
                          src={st.avatar} 
                          alt={st.name} 
                          className="w-16 h-16 rounded-2xl object-cover border border-slate-100"
                        />
                        <div className="flex-1">
                          <h3 className="font-bold text-slate-900 leading-tight mb-1">{st.name}</h3>
                          <p className="text-xs text-slate-400 font-medium mb-1">{st.role}</p>
                          <div className="text-xs bg-slate-100 text-slate-600 px-2 py-0.5 rounded-md inline-block mb-3">
                            🏢 {st.specialty}
                          </div>
                          
                          <div className="flex items-center gap-3 text-xs font-semibold text-slate-500 mt-1">
                            <span className="flex items-center gap-0.5 text-amber-500 font-bold">
                              ★ {st.rating}
                            </span>
                            <span>•</span>
                            <span className="flex items-center gap-1">
                              <Clock className="w-3.5" /> {st.workingHours.start} - {st.workingHours.end}
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </motion.div>
            )}

            {/* STEP 3: DATE & TIME SELECTOR */}
            {step === 3 && (
              <motion.div
                key="step3"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
              >
                <div className="flex justify-between items-center mb-6">
                  <button
                    onClick={() => setStep(2)}
                    className="inline-flex items-center gap-2 text-sm font-semibold text-slate-500 hover:text-slate-800 group"
                  >
                    <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" /> Back to Staff
                  </button>
                  {selectedService && (
                    <div className="text-right text-xs bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-2 rounded-xl">
                      <span className="text-slate-400">Selected: </span>
                      <strong className="text-slate-700 dark:text-slate-200">{selectedService.name}</strong> • ${selectedService.price}
                    </div>
                  )}
                </div>

                {/* Service Duration Customizer Picker */}
                <div className={`mb-6 p-4 rounded-2xl border ${
                  isDarkMode ? 'bg-slate-950/60 border-slate-850' : 'bg-slate-50/60 border-slate-150'
                }`}>
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div>
                      <h4 className="font-extrabold text-slate-800 dark:text-slate-200 text-sm mb-1">Select Booking Duration</h4>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium leading-normal">
                        Choose appointment length to dynamically adjust and filter scheduling grids for {selectedStaff?.name || 'the specialist'}
                      </p>
                    </div>
                    
                    <div className="flex flex-wrap gap-2.5">
                      {[30, 60, 90].map((d) => (
                        <button
                          key={d}
                          id={`btn_duration_select_${d}`}
                          type="button"
                          onClick={() => {
                            setCustomDuration(d);
                            setSelectedTime(''); // clear invalid time
                          }}
                          className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
                            customDuration === d
                              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/15 border-2 border-indigo-500'
                              : isDarkMode
                                ? 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800'
                                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                          }`}
                        >
                          {d} min
                        </button>
                      ))}

                      {/* If service's normal duration is not 30, 60, or 90, include it as a standard option! */}
                      {selectedService && ![30, 60, 90].includes(selectedService.duration) && (
                        <button
                          id={`btn_duration_select_${selectedService.duration}`}
                          type="button"
                          onClick={() => {
                            setCustomDuration(selectedService.duration);
                            setSelectedTime('');
                          }}
                          className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
                            customDuration === selectedService.duration
                              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/15 border-2 border-indigo-500'
                              : isDarkMode
                                ? 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800'
                                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                          }`}
                        >
                          {selectedService.duration} min (Standard)
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                {/* Date Slider Horizontal */}
                <h3 className="font-bold text-slate-850 dark:text-slate-100 text-base mb-3 leading-none">1. Choose Booking Date</h3>
                <div className="flex gap-2 overflow-x-auto pb-4 scrollbar-thin scrollbar-thumb-slate-200">
                  {datesList.map((dt) => {
                    const isSelected = selectedDate === dt.dateString;
                    return (
                      <button
                        key={dt.dateString}
                        id={`btn_date_picker_${dt.dateString}`}
                        onClick={() => {
                          setSelectedDate(dt.dateString);
                          setSelectedTime(''); // clear time
                        }}
                        className={`flex flex-col items-center justify-center p-3 rounded-xl border min-w-16 transition-all cursor-pointer ${
                          isSelected
                            ? 'border-slate-800 bg-slate-900 text-white shadow-md'
                            : 'border-slate-100 hover:border-slate-300 bg-slate-50 text-slate-700 hover:bg-white'
                        }`}
                      >
                        <span className="text-[10px] font-bold uppercase opacity-80">{dt.weekdayName}</span>
                        <span className="text-lg font-extrabold my-0.5">{dt.dayNum}</span>
                        <span className="text-[10px] font-medium">{dt.monthName}</span>
                      </button>
                    );
                  })}
                </div>

                {/* Time Grid Picker */}
                {selectedDate ? (
                  <div className="mt-6">
                    <h3 className="font-bold text-slate-800 text-base mb-3 leading-none">2. Select Time Slot</h3>
                    <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2.5">
                      {availableSlots.map((time) => {
                        const isSelected = selectedTime === time;
                        return (
                          <button
                            key={time}
                            id={`btn_time_slot_${time}`}
                            onClick={() => setSelectedTime(time)}
                            className={`p-3 rounded-xl border text-sm font-semibold transition-all cursor-pointer ${
                              isSelected
                                ? `${scheme.bg} text-white border-transparent shadow-md`
                                : 'border-slate-100 hover:border-slate-300 bg-slate-50 text-slate-700 hover:bg-white'
                            }`}
                          >
                            {time}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ) : (
                  <div className="bg-slate-50 rounded-2xl py-8 text-center text-slate-400 text-sm border border-dashed border-slate-200 mt-6">
                    👉 Please select a booking date first
                  </div>
                )}

                {/* Advance Button */}
                {selectedDate && selectedTime && (
                  <div className="text-right mt-8 border-t border-slate-100 pt-6">
                    <button
                      id="btn_advance_to_details"
                      onClick={() => setStep(4)}
                      className={`px-8 py-3.5 rounded-xl text-white font-extrabold flex items-center gap-2 ml-auto shadow-lg hover:brightness-110 active:scale-98 transition ${scheme.bg} cursor-pointer`}
                    >
                      Continue to Details <ChevronRight className="w-5 h-5" />
                    </button>
                  </div>
                )}
              </motion.div>
            )}

            {/* STEP 4: CONTACT & NOTES CONFORMATION */}
            {step === 4 && (
              <motion.div
                key="step4"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
              >
                <div className="flex justify-between items-center mb-6">
                  <button
                    onClick={() => setStep(3)}
                    className="inline-flex items-center gap-2 text-sm font-semibold text-slate-500 hover:text-slate-800 group"
                  >
                    <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" /> Back to Scheduling
                  </button>
                </div>

                <div className="grid md:grid-cols-3 gap-8">
                  {/* Summary Card */}
                  <div className={`${isDarkMode ? 'bg-slate-950/80 border-slate-850' : 'bg-slate-50'} rounded-2xl p-5 border h-fit`}>
                    <h3 className="font-bold text-slate-800 dark:text-slate-200 text-sm mb-4 pb-2 border-b border-slate-200 dark:border-slate-800 uppercase tracking-wider">Appointment Summary</h3>
                    
                    {selectedService && (
                      <div className="space-y-4 text-left">
                        {/* Service summary */}
                        <div>
                          <label className="text-xs text-slate-400 uppercase tracking-widest block font-bold">Service</label>
                          <span className="font-extrabold text-slate-800 dark:text-slate-100">{selectedService.name}</span>
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{customDuration} mins • ${selectedService.price}</p>
                        </div>
                        
                        {/* Staff member summary */}
                        {selectedStaff && (
                          <div className={`flex items-center gap-2.5 p-2.5 rounded-xl border ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'}`}>
                            <img referrerPolicy="no-referrer" src={selectedStaff.avatar} className="w-10 h-10 rounded-lg object-cover" alt="" />
                            <div>
                              <label className="text-[10px] text-slate-400 font-bold block uppercase">Professional</label>
                              <strong className="text-xs text-slate-700 dark:text-slate-200">{selectedStaff.name}</strong>
                            </div>
                          </div>
                        )}

                        {/* Date selection and hour */}
                        <div className="grid grid-cols-2 gap-2 pt-2">
                          <div className={`p-2 rounded-xl border ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'}`}>
                            <label className="text-[10px] text-slate-400 block uppercase font-bold">Date</label>
                            <strong className="text-xs text-slate-700 dark:text-slate-200 flex items-center gap-1">
                              <Calendar className="w-3 text-slate-500" /> {selectedDate.split('-').slice(1).join('/')}
                            </strong>
                          </div>
                          <div className={`p-2 rounded-xl border ${isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'}`}>
                            <label className="text-[10px] text-slate-400 block uppercase font-bold">Time</label>
                            <strong className="text-xs text-slate-700 dark:text-slate-200 flex items-center gap-1">
                              <Clock className="w-3 text-slate-500" /> {selectedTime}
                            </strong>
                          </div>
                        </div>

                        {/* Pricing */}
                        <div className={`pt-4 border-t flex justify-between items-center p-3 rounded-xl ${isDarkMode ? 'bg-slate-900/60 border-slate-850' : 'bg-slate-100'}`}>
                          <span className="font-extrabold text-xs text-slate-500 dark:text-slate-400 uppercase tracking-wider">Total Due</span>
                          <span className="text-xl font-black text-slate-800 dark:text-slate-100">${selectedService.price}</span>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Form fields elements */}
                  <form onSubmit={handleBookingSubmit} className="md:col-span-2 space-y-4">
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <label className="text-xs font-bold text-slate-600 block mb-1.5 flex items-center gap-1">
                          <User className="w-3.5 h-3.5" /> Full Name <span className="text-rose-500">*</span>
                        </label>
                        <input
                          type="text"
                          id="input_cust_name"
                          required
                          value={customerName}
                          onChange={(e) => setCustomerName(e.target.value)}
                          placeholder="e.g. Sivanesan M"
                          className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:border-slate-800 focus:ring-slate-100 transition"
                        />
                      </div>
                      <div>
                        <label className="text-xs font-bold text-slate-600 block mb-1.5 flex items-center gap-1">
                          <Mail className="w-3.5 h-3.5" /> Contact Email <span className="text-rose-500">*</span>
                        </label>
                        <input
                          type="email"
                          id="input_cust_email"
                          required
                          value={customerEmail}
                          onChange={(e) => setCustomerEmail(e.target.value)}
                          placeholder="e.g. it055m.sivanesan@gmail.com"
                          className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:border-slate-800 focus:ring-slate-100 transition"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-600 block mb-1.5 flex items-center gap-1">
                        <Phone className="w-3.5 h-3.5" /> Mobile Number <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="tel"
                        id="input_cust_phone"
                        required
                        value={customerPhone}
                        onChange={(e) => setCustomerPhone(e.target.value)}
                        placeholder="e.g. 9025020293"
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:border-slate-800 focus:ring-slate-100 transition"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-600 block mb-1.5 flex items-center gap-1">
                        <FileText className="w-3.5 h-3.5" /> Special Requests or Notes
                      </label>
                      <textarea
                        value={customerNotes}
                        onChange={(e) => setCustomerNotes(e.target.value)}
                        placeholder="Add any specific requirements or preferences here..."
                        rows={3}
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:border-slate-800 focus:ring-slate-100 transition"
                      />
                    </div>

                    <div className="bg-slate-50 border border-slate-100 p-4 rounded-xl flex gap-2.5">
                      <MailCheck className={`w-5 h-5 flex-shrink-0 ${scheme.text} mt-0.5`} />
                      <p className="text-xs text-slate-500 leading-relaxed">
                        <strong>Simulated Instant Notifications:</strong> When you complete the appointment, BookEase will mock-send a tailored booking confirmation email. You can preview this email in the **Email Log / Sandbox** of the Admin Dashboard.
                      </p>
                    </div>

                    <button
                      id="btn_submit_booking"
                      type="submit"
                      disabled={isSubmitting}
                      className={`w-full py-4 rounded-xl text-white font-extrabold flex items-center justify-center gap-2 shadow-lg active:scale-98 transition ${
                        isSubmitting ? 'bg-slate-400 cursor-not-allowed' : scheme.bg
                      } cursor-pointer`}
                    >
                      {isSubmitting ? 'Processing appointment...' : 'Confirm BookEase Appointment ✔'}
                    </button>
                  </form>
                </div>
              </motion.div>
            )}

            {/* STEP 5: BOOKING CONFIRMATION & CREATOR CARD */}
            {step === 5 && createdBooking && (
              <motion.div
                key="step5"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center py-6"
              >
                <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4 animate-bounce">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                
                <span className="text-xs font-extrabold text-emerald-600 uppercase tracking-widest block mb-1.5">Booking Registered Successfully!</span>
                <h2 className="text-3xl font-extrabold text-slate-900 mb-2">You're All Set!</h2>
                <p className="text-slate-500 text-sm max-w-md mx-auto mb-8">
                  Your appointment slot is locked. An instant confirmation email has been logged to the Admin panel.
                </p>

                {/* Digital Receipt Card */}
                <div className="bg-slate-50 rounded-2xl border border-slate-100 max-w-xl mx-auto p-6 text-left mb-8 relative overflow-hidden">
                  <div className={`absolute top-0 right-0 left-0 h-1.5 ${scheme.bg}`} />
                  
                  <div className="flex justify-between items-center mb-4 pb-4 border-b border-dashed border-slate-200">
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase block">Booking Reference</span>
                      <strong className="text-slate-700 tracking-wider">#{createdBooking.id.split('_').slice(-2).join('-').toUpperCase() || 'BKE-120'}</strong>
                    </div>
                    <span className="text-xs px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-lg font-bold">● CONFIRMED</span>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase block">Customer Name</span>
                      <strong className="text-slate-700 text-sm">{createdBooking.customerName}</strong>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase block">Provider</span>
                      <strong className="text-slate-700 text-sm">{selectedStaff?.name}</strong>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4 mt-3">
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase block">Service Selected</span>
                      <strong className="text-slate-700 text-sm">{selectedService?.name}</strong>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase block">Date & Schedule</span>
                      <strong className="text-slate-700 text-sm">{createdBooking.date} • {createdBooking.timeSlot}</strong>
                    </div>
                  </div>

                  {/* Pricing and Notes */}
                  <div className="mt-4 pt-4 border-t border-slate-200 flex justify-between items-center">
                    <span className="text-xs font-bold text-slate-400">Total Price Paid</span>
                    <strong className="text-xl font-black text-slate-800">${createdBooking.price}</strong>
                  </div>
                </div>

                {/* SIVANESAN (CREATOR CARD) - INTEGRATED ACCORDING TO USER'S INSTRUCTIONS */}
                <div className="bg-slate-900 text-white rounded-2xl p-6 max-w-xl mx-auto text-left relative overflow-hidden shadow-xl mb-8">
                  <div className="absolute right-0 top-0 bottom-0 w-24 bg-gradient-to-l from-indigo-500/20 to-transparent pointer-events-none" />
                  
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-1.5 mb-1.5">
                        <span className="text-slate-400 text-[10px] uppercase font-bold tracking-widest block">BookEase SaaS Lead Architect</span>
                        <span className="bg-indigo-500 text-white text-[9px] px-1.5 py-0.5 rounded font-extrabold uppercase animate-pulse">Developer</span>
                      </div>
                      <h4 className="text-lg font-black tracking-tight">Sivanesan M</h4>
                      <p className="text-xs text-indigo-200 mt-1">Full-Stack Engineer & SaaS Founder Portfolio</p>
                    </div>
                    <a 
                      href="mailto:it055m.sivanesan@gmail.com"
                      className="text-xs bg-slate-800 text-white hover:bg-slate-700 transition px-3 py-1.5 rounded-lg border border-slate-700 flex items-center gap-1"
                    >
                      it055m.sivanesan@gmail.com
                    </a>
                  </div>

                  {/* Links Row */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5 pt-4 border-t border-slate-800">
                    <a
                      href="https://www.linkedin.com/in/m-sivanesan-66415b24a/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1 text-xs text-slate-300 hover:text-white transition"
                    >
                      <Linkedin className="w-3.5 h-3.5 text-indigo-400" /> LinkedIn <ExternalLink className="w-2.5 h-2.5 opacity-50" />
                    </a>
                    <a
                      href="https://github.com/Sivanesan-m"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1 text-xs text-slate-300 hover:text-white transition"
                    >
                      <Github className="w-3.5 h-3.5 text-slate-300" /> GitHub <ExternalLink className="w-2.5 h-2.5 opacity-50" />
                    </a>
                    <a
                      href="mailto:developersivanesan2004@gmail.com"
                      className="flex items-center gap-1 text-xs text-slate-300 hover:text-white transition"
                    >
                      <Mail className="w-3.5 h-3.5 text-rose-400" /> Alternate Mail
                    </a>
                    <a
                      href="tel:9025020293"
                      className="flex items-center gap-1 text-xs text-slate-300 hover:text-white transition"
                    >
                      <Smartphone className="w-3.5 h-3.5 text-emerald-400" /> +91 9025020293
                    </a>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row justify-center gap-3">
                  <button
                    onClick={restartBookingFlow}
                    className={`px-6 py-3 rounded-xl border border-slate-200 hover:border-slate-800 text-slate-600 hover:text-slate-900 transition flex items-center justify-center gap-1.5 cursor-pointer`}
                  >
                    <Send className="w-4 h-4" /> Schedule New Appointment
                  </button>
                  <button
                    id="btn_view_on_dashboard"
                    onClick={onNavigateToDashboard}
                    className="px-6 py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer shadow"
                  >
                    Go to Admin Dashboard <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
