/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Sparkles, Calendar, TrendingUp, Users, Shield, Zap, Scissors, Dumbbell, 
  GraduationCap, Stethoscope, Briefcase, Compass, Star, ChevronRight, Mail, 
  Send, User, Phone, Check, RefreshCw, Github, Linkedin, Globe, PhoneCall
} from 'lucide-react';
import { motion } from 'motion/react';
import { INDUSTRIES } from '../data';

interface LandingPageProps {
  onStartBooking: () => void;
  onGoToAdmin: () => void;
  isDarkMode: boolean;
}

export default function LandingPage({ onStartBooking, onGoToAdmin, isDarkMode }: LandingPageProps) {
  // Testimonials state or items
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const testimonials = [
    {
      name: "Sophia Martinez",
      role: "Founder, Velvet Cut Salon & Spa",
      avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100",
      rating: 5,
      feedback: "BookEase completely transformed my salon's intake pipeline! The AI booking parser saves our receptionist hours of work, and the notifications automatically prevent late cancellations."
    },
    {
      name: "Marcus Vance",
      role: "Lead consultant, ScaleCloud SaaS Corp",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100",
      rating: 5,
      feedback: "The interactive calendar makes reschedule requests a breeze. Customers just drag and drop, and we get real-time database updates. For consulting, BookEase is our premium workflow manager."
    },
    {
      name: "Maria Sanchez",
      role: "Director, Zen Flow Yoga Studios",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100",
      feedback: "Our students love the quick horizontal date pickers and smooth UX. Setting up our personal trainers and tutoring groups took under 10 minutes. A solid SaaS product!"
    }
  ];

  // Contact form state
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactMsg, setContactMsg] = useState('');
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [contactSubject, setContactSubject] = useState('General Inquiry');

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitted(true);
    setTimeout(() => {
      setFormSubmitted(false);
      setContactName('');
      setContactEmail('');
      setContactMsg('');
    }, 4500);
  };

  const features = [
    {
      icon: <Sparkles className="w-5 h-5 text-indigo-500" />,
      title: "AI Booking Assistant",
      desc: "Allow clients to schedule using plain conversational text. Our integrated AI translates inputs into service slots instantly."
    },
    {
      icon: <Calendar className="w-5 h-5 text-emerald-500" />,
      title: "Interactive Admin Calendar",
      desc: "Drag-and-drop bookings across dates, filter by practitioner, or click to toggle confirmations from a clean central hub."
    },
    {
      icon: <TrendingUp className="w-5 h-5 text-amber-500" />,
      title: "Executive Analytics",
      desc: "Track sales velocity, customer growth milestones, and popular service parameters using beautiful visual Recharts."
    },
    {
      icon: <Users className="w-5 h-5 text-rose-500" />,
      title: "Automatic Customer CRM",
      desc: "Maintain profiles, log absolute histories, total visits, and edit dynamic staff notes instantly which updates local metrics."
    },
    {
      icon: <Shield className="w-5 h-5 text-sky-500" />,
      title: "Supabase & Postgres Sync",
      desc: "Ready to scale from localStorage to real-world cloud persistent storage. Download the pre-built backend SQL seeds directly."
    },
    {
      icon: <Zap className="w-5 h-5 text-violet-500" />,
      title: "Notification Sandbox",
      desc: "Simulates instant email alerts (Confirmations, Reschedules, Reminders) so you can preview customer mailings on the fly."
    }
  ];

  // Pricing Plans
  const plans = [
    {
      name: "Starter Trial",
      price: "0",
      desc: "Ideal for fresh solo tutors, trainers, or freelancers scouting client interfaces.",
      features: [
        "1 Industry configuration",
        "Up to 15 custom monthly bookings",
        "Basic Client Registry database",
        "Notification reminders console",
        "Standard theme selection"
      ],
      linkText: "Launch Instance",
      popular: false
    },
    {
      name: "Business Pro",
      price: "29",
      desc: "Perfect for active beauty salons, medical clinics, and established local teams.",
      features: [
        "All 6 diverse SaaS Industries",
        "Unlimited client bookings slot tracker",
        "Generative Conversational AI helper",
        "Interactive weekly/monthly drag-drop",
        "Full executive Recharts Analytics dashboard",
        "Supabase SQL seed down-loader",
        "Priority live email sandbox"
      ],
      linkText: "Scale with Pro",
      popular: true
    },
    {
      name: "Enterprise Studio",
      price: "89",
      desc: "Engineered for mid-sized multi-location wellness studios and franchised networks.",
      features: [
        "Custom domain mapping setup",
        "Multi-provider payroll logs",
        "Dedicated database integration assistance",
        "Automated SMS Gateway variables",
        "24/7 Premium technical SLA",
        "Advanced custom API Webhooks"
      ],
      linkText: "Contact Sales",
      popular: false
    }
  ];

  const getIndustryCleanIcon = (id: string) => {
    switch(id) {
      case 'salon': return <Scissors className="w-4 h-4 text-indigo-400" />;
      case 'fitness': return <Dumbbell className="w-4 h-4 text-emerald-400" />;
      case 'tutor': return <GraduationCap className="w-4 h-4 text-amber-400" />;
      case 'doctor': return <Stethoscope className="w-4 h-4 text-rose-400" />;
      case 'consultant': return <Briefcase className="w-4 h-4 text-sky-400" />;
      case 'coach': return <Compass className="w-4 h-4 text-violet-400" />;
      default: return <Sparkles className="w-4 h-4 text-slate-400" />;
    }
  };

  return (
    <div className="space-y-24 pb-20 text-left">
      
      {/* 1. HERO SECTION WITH GLASSMORPHISM ACCENTS */}
      <section className="relative pt-12 md:pt-20 overflow-hidden px-4">
        {/* Background ambient radial glow */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-gradient-to-tr from-indigo-500/10 to-violet-500/10 blur-[120px] rounded-full pointer-events-none" />

        <div className="max-w-6xl mx-auto text-center space-y-6">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-black tracking-wider uppercase border backdrop-blur-xl ${
              isDarkMode 
                ? 'bg-slate-950/60 border-slate-800 text-indigo-300' 
                : 'bg-indigo-50 border-indigo-100 text-indigo-700'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 animate-pulse text-indigo-500" />
            <span>Introducing Conversational Scheduling AI</span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className={`text-4xl sm:text-6xl font-black tracking-tight leading-[1.1] ${
              isDarkMode ? 'text-white' : 'text-slate-900'
            }`}
          >
            The Ultimate SaaS Booking <br className="hidden md:inline" />
            <span className="bg-gradient-to-r from-indigo-500 via-purple-500 to-indigo-600 bg-clip-text text-transparent">
              Platform for Local Teams
            </span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            className={`text-base sm:text-lg max-w-2xl mx-auto leading-relaxed ${
              isDarkMode ? 'text-slate-400' : 'text-slate-600'
            }`}
          >
            Empower salons, gyms, tutors, medical clinics, and coaches with a customizable client scheduling funnel, drag-drop planners, CRM logs, and automated notifications.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4"
          >
            <button
              id="hero_btn_start_booking"
              onClick={onStartBooking}
              className="w-full sm:w-auto px-8 py-4 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-sm rounded-2xl flex items-center justify-center gap-2 transition active:scale-98 shadow-xl shadow-indigo-600/10 cursor-pointer"
            >
              <Calendar className="w-4 h-4" /> Start Client Booking Page
            </button>
            <button
              id="hero_btn_admin_hub"
              onClick={onGoToAdmin}
              className={`w-full sm:w-auto px-8 py-4 font-black text-sm rounded-2xl flex items-center justify-center gap-2 border transition active:scale-98 cursor-pointer ${
                isDarkMode 
                  ? 'bg-slate-900/60 border-slate-800 text-slate-300 hover:text-white hover:bg-slate-900' 
                  : 'bg-white border-slate-200 text-slate-700 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <TrendingUp className="w-4 h-4 text-emerald-400" /> Go to Admin Dashboard
            </button>
          </motion.div>

          {/* Interactive Hero Preview Element - Interactive Glass UI */}
          <motion.div 
            initial={{ opacity: 0, y: 25 }}
            animate={{ opacity: 1, y: 0 }}
            className="pt-12 max-w-4xl mx-auto px-4"
          >
            <div className={`p-1.5 rounded-[32px] border backdrop-blur-md ${
              isDarkMode ? 'bg-slate-950/20 border-slate-800/60' : 'bg-slate-100/50 border-slate-200/50'
            }`}>
              <div className={`rounded-[26px] border shadow-2xl p-6 md:p-8 text-left space-y-6 ${
                isDarkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-white border-slate-100'
              }`}>
                {/* Simulated Web App Bar */}
                <div className="flex items-center justify-between border-b pb-4 mb-2 border-slate-800/10 dark:border-slate-800/80">
                  <div className="flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded-full bg-rose-500 inline-block" />
                    <span className="w-3 h-3 rounded-full bg-amber-500 inline-block" />
                    <span className="w-3 h-3 rounded-full bg-emerald-500 inline-block" />
                    <span className={`text-[10px] uppercase tracking-widest font-black ml-2 ${isDarkMode ? 'text-slate-500' : 'text-slate-400'}`}>BookEase client mock portal</span>
                  </div>
                  <div className="flex gap-2">
                    {['salon', 'fitness', 'tutor', 'doctor', 'consultant', 'coach'].slice(0, 3).map(id => (
                      <span key={id} className={`text-[10px] px-2 py-0.5 rounded-full font-bold flex items-center gap-1 bg-slate-100 text-slate-700 dark:bg-slate-950 dark:text-slate-300`}>
                        {getIndustryCleanIcon(id)} {id.toUpperCase()}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="grid md:grid-cols-5 gap-6">
                  {/* Left Column stats */}
                  <div className="md:col-span-2 space-y-4">
                    <h3 className={`text-xl font-black tracking-tight ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>Configured for 6 Industries</h3>
                    <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-500'} leading-relaxed`}>
                      Whether managing a signature balayage at a hair salon, scheduling a physical diagnosis at a medical clinic, or conducting SAT calculus review groups. BookEase satisfies all local service workflows flawlessly.
                    </p>
                    <div className="grid grid-cols-2 gap-2 pt-2">
                      <div className="p-3 bg-slate-50 dark:bg-slate-950/60 rounded-xl border border-slate-100 dark:border-slate-900">
                        <span className="text-[10px] dark:text-slate-500 font-bold block uppercase">Bookings</span>
                        <strong className="text-lg font-black dark:text-white">50+ Seeded</strong>
                      </div>
                      <div className="p-3 bg-slate-50 dark:bg-slate-950/60 rounded-xl border border-slate-100 dark:border-slate-900">
                        <span className="text-[10px] dark:text-slate-500 font-bold block uppercase">Speed</span>
                        <strong className="text-lg font-black dark:text-white">Instant</strong>
                      </div>
                    </div>
                  </div>

                  {/* Right Column illustration */}
                  <div className="md:col-span-3 bg-slate-50 dark:bg-slate-950/40 border border-slate-100 dark:border-slate-900/80 rounded-2xl p-4 flex flex-col justify-between relative overflow-hidden">
                    <div className="absolute right-0 bottom-0 top-0 w-1/3 bg-gradient-to-l from-indigo-500/5 to-transparent" />
                    <div>
                      <span className="text-[9px] bg-indigo-500/20 text-indigo-400 px-2 py-0.5 rounded-full font-extrabold uppercase">AI Booking Copilot Module</span>
                      <p className="text-xs text-slate-400 italic mt-3 leading-relaxed">
                        "I want a balayage hair color with Chloe on Thursday afternoon."
                      </p>
                    </div>
                    <div className="mt-4 pt-3 border-t border-slate-800/10 dark:border-slate-800/60 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-xs bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-md font-extrabold text-[10px]">✓ PARSED</span>
                        <span className="text-[10px] text-slate-400 font-medium">Auto-populates dates, times & service</span>
                      </div>
                      <button onClick={onStartBooking} className="text-xs text-indigo-400 font-bold flex items-center gap-1 hover:underline cursor-pointer">
                        Try UI <ChevronRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* 2. CORE FEATURES BENTO SECTION */}
      <section className="max-w-6xl mx-auto px-4 space-y-12">
        <div className="text-center space-y-2">
          <span className="text-[10px] uppercase font-black tracking-widest text-indigo-500">Premium Architecture</span>
          <h2 className={`text-2xl sm:text-4xl font-extrabold tracking-tight ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>
            Built for Serious Freelancers & Studios
          </h2>
          <p className={`text-xs sm:text-sm max-w-xl mx-auto ${isDarkMode ? 'text-slate-400' : 'text-slate-550'}`}>
            Clean visual elements designed to convince commercial clients that your tech stack easily competes with multi-million dollar booking portals.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feat, i) => (
            <div
              key={i}
              className={`p-6 rounded-2xl border transition-all duration-300 hover:-translate-y-1 relative group overflow-hidden ${
                isDarkMode 
                  ? 'bg-slate-900/50 border-slate-800/80 hover:border-slate-700/60 hover:bg-slate-900' 
                  : 'bg-white border-slate-100 hover:border-slate-300 focus:bg-slate-50'
              }`}
            >
              {/* Subtle hover background highlight */}
              <div className="absolute -left-16 -bottom-16 w-32 h-32 bg-gradient-to-tr from-slate-500/5 to-transparent blur-xl pointer-events-none rounded-full" />
              
              <div className="p-2.5 bg-slate-50 dark:bg-slate-950 rounded-xl w-fit border border-slate-100 dark:border-slate-800 shadow-sm mb-4">
                {feat.icon}
              </div>
              <h3 className={`font-extrabold text-base mb-1.5 ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>{feat.title}</h3>
              <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-500'} leading-relaxed`}>{feat.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* 3. TESTIMONIAL PANEL WITH INTERACTIVE CAROUSEL */}
      <section className={`py-12 px-4 rounded-[40px] max-w-6xl mx-auto relative overflow-hidden text-center sm:text-left ${
        isDarkMode ? 'bg-slate-900/30 border border-slate-800/60' : 'bg-slate-50/70 border border-slate-200/50'
      }`}>
        <div className="absolute right-0 bottom-0 top-0 w-1/4 bg-gradient-to-l from-indigo-500/5 to-transparent pointer-events-none" />
        
        <div className="grid md:grid-cols-3 gap-8 items-center max-w-5xl mx-auto">
          <div className="space-y-4">
            <span className="text-[10px] uppercase font-black text-indigo-500 tracking-widest leading-none block">Success Stories</span>
            <h3 className={`text-2xl sm:text-3xl font-black tracking-tight ${isDarkMode ? 'text-white' : 'text-slate-950'}`}>What Business Owners Say</h3>
            <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-500'} leading-relaxed`}>
              Over 50 boutique salons, calculus tutors, clinical dermatologists, and performance coaches rely on BookEase parameters to keep agendas filled daily.
            </p>
            {/* Carousel controllers */}
            <div className="flex gap-1.5 pt-2 justify-center sm:justify-start">
              {testimonials.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveTestimonial(idx)}
                  className={`w-2.5 h-2.5 rounded-full transition-all cursor-pointer ${
                    activeTestimonial === idx ? 'bg-indigo-600 px-3' : 'bg-slate-300 dark:bg-slate-800'
                  }`}
                />
              ))}
            </div>
          </div>

          <div className="md:col-span-2 bg-white dark:bg-slate-950 border border-slate-100 dark:border-slate-900 shadow-xl p-6 sm:p-8 rounded-3xl text-left relative min-h-[180px] flex flex-col justify-between">
            <p className={`text-sm italic font-medium leading-relaxed ${isDarkMode ? 'text-slate-300' : 'text-slate-600'}`}>
              "{testimonials[activeTestimonial].feedback}"
            </p>
            <div className="flex items-center gap-3.5 pt-6 mt-6 border-t border-slate-100 dark:border-slate-900">
              <img src={testimonials[activeTestimonial].avatar} className="w-10 h-10 rounded-full object-cover" alt="" />
              <div>
                <strong className={`block text-xs font-bold ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>
                  {testimonials[activeTestimonial].name}
                </strong>
                <span className="text-[10px] text-indigo-500 font-semibold">{testimonials[activeTestimonial].role}</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. PRICING SaaS TIER CARDS */}
      <section className="max-w-6xl mx-auto px-4 space-y-12">
        <div className="text-center space-y-2">
          <span className="text-[10px] uppercase font-black tracking-widest text-indigo-500 font-mono">No hidden variables</span>
          <h2 className={`text-2xl sm:text-4xl font-extrabold tracking-tight ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>
            Simple Core Pricing Plans
          </h2>
          <p className={`text-xs sm:text-sm max-w-sm mx-auto ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
            Pay flat transparent pricing. Switch industries or re-seed parameters anytime for solo or enterprise setups.
          </p>
        </div>

        <div className="grid sm:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {plans.map((pl, i) => (
            <div
              key={i}
              className={`p-6 sm:p-8 rounded-3xl border text-left flex flex-col justify-between relative transition-all duration-300 ${
                pl.popular 
                  ? 'border-indigo-600 dark:bg-slate-900/80 bg-indigo-50/10 shadow-xl ring-2 ring-indigo-600/20 scale-[1.02]' 
                  : isDarkMode 
                    ? 'bg-slate-900/30 border-slate-800/80 hover:border-slate-800' 
                    : 'bg-white border-slate-200'
              }`}
            >
              {pl.popular && (
                <span className="absolute -top-3.5 right-6 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-extrabold text-[8px] px-2.5 py-1.5 rounded-full uppercase tracking-widest shadow shadow-indigo-600">
                  ★ MOST POPULAR SaaS
                </span>
              )}
              
              <div>
                <h3 className={`text-lg font-black tracking-tight ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>{pl.name}</h3>
                <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-500'} mt-1 leading-relaxed`}>{pl.desc}</p>
                
                <div className="my-6">
                  <span className={`text-3xl sm:text-4xl font-black ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>${pl.price}</span>
                  <span className="text-xs text-slate-500"> / month</span>
                </div>
                
                <h4 className="text-[10px] uppercase font-black tracking-widest text-slate-400 pb-3 block">Features included:</h4>
                <ul className="space-y-2 text-xs">
                  {pl.features.map((f, fIdx) => (
                    <li key={fIdx} className="flex items-start gap-2 text-slate-500 dark:text-slate-400">
                      <Check className="w-4 h-4 text-emerald-500 flex-shrink-0 mt-0.5" />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-8">
                <button
                  onClick={onStartBooking}
                  className={`w-full py-3 rounded-xl font-extrabold text-xs text-center transition active:scale-98 cursor-pointer ${
                    pl.popular 
                      ? 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/10' 
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-950 dark:text-slate-300 dark:hover:bg-slate-900'
                  }`}
                >
                  {pl.linkText}
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ABOUT THE DEVELOPER PROFILE SECTION */}
      <section className="max-w-4xl mx-auto px-4">
        <div className={`p-8 rounded-[32px] border backdrop-blur-md relative overflow-hidden ${
          isDarkMode ? 'bg-slate-900/50 border-slate-800' : 'bg-white border-slate-200/60 shadow-xl shadow-slate-100/50'
        }`}>
          {/* Elegant blur backgrounds */}
          <div className="absolute -right-20 -bottom-20 w-44 h-44 bg-indigo-500/10 blur-[60px] pointer-events-none rounded-full" />
          <div className="absolute -left-20 -top-20 w-44 h-44 bg-violet-500/10 blur-[60px] pointer-events-none rounded-full" />
          
          <div className="grid md:grid-cols-12 gap-8 items-center">
            {/* Left Side: Avatar block */}
            <div className="md:col-span-4 flex flex-col items-center justify-center text-center space-y-4">
              <div className="relative group">
                <div className="absolute animate-pulse -inset-1.5 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 rounded-full blur opacity-75 group-hover:opacity-100 transition duration-1000"></div>
                <div className={`relative w-28 h-28 rounded-full flex items-center justify-center font-black text-4xl text-white bg-gradient-to-tr from-indigo-600 to-violet-700 shadow-xl border-4 ${
                  isDarkMode ? 'border-slate-900' : 'border-white'
                }`}>
                  S
                </div>
              </div>
              <div>
                <h3 className={`text-xl font-extrabold tracking-tight ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>Sivanesan</h3>
                <span className="text-[10px] bg-indigo-500/15 text-indigo-500 font-extrabold px-3 py-1 rounded-full dark:text-indigo-400 block w-fit mx-auto mt-1.5 uppercase tracking-widest font-mono">
                  SaaS Architect & Dev
                </span>
              </div>
            </div>

            {/* Right Side: Description and credentials */}
            <div className="md:col-span-8 space-y-6 text-left">
              <div>
                <span className="text-[10px] uppercase font-black text-indigo-500 tracking-widest block mb-1">Meet the Architect</span>
                <h4 className={`text-2xl font-black tracking-tight ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>About the Developer</h4>
                <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'} leading-relaxed mt-2`}>
                  Greetings! I am <strong>Sivanesan</strong>, a creative Full-Stack Engineer and software architect. I construct responsive, production-ready SaaS concepts, scalable database structures, and responsive user-centric layouts. BookEase exhibits modular components, clean interactive flows, and production-ready interfaces designed for commercial success.
                </p>
              </div>

              {/* Direct Details Grid */}
              <div className="grid sm:grid-cols-2 gap-4">
                <div className={`p-4 rounded-2xl border ${
                  isDarkMode ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200/60'
                }`}>
                  <span className="text-[10px] uppercase font-bold text-slate-400 block mb-2 leading-none">Inquiries & Correspondence</span>
                  <div className="space-y-2">
                    <a href="mailto:it055m.sivanesan@gmail.com" className="hover:text-indigo-500 transition text-xs flex items-center gap-2">
                      <Mail className="w-3.5 h-3.5 text-indigo-500 flex-shrink-0" />
                      <span className="truncate font-semibold text-[11px]">it055m.sivanesan@gmail.com</span>
                    </a>
                    <a href="mailto:developersivanesan2004@gmail.com" className="hover:text-indigo-500 transition text-xs flex items-center gap-2">
                      <Mail className="w-3.5 h-3.5 text-indigo-500 flex-shrink-0" />
                      <span className="truncate font-semibold text-[11px]">developersivanesan2004@gmail.com</span>
                    </a>
                  </div>
                </div>

                <div className={`p-4 rounded-2xl border ${
                  isDarkMode ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200/60'
                }`}>
                  <span className="text-[10px] uppercase font-bold text-slate-400 block mb-2 leading-none">Direct Communication</span>
                  <div className="space-y-2">
                    <a href="tel:9025020293" className="hover:text-indigo-500 transition text-xs flex items-center gap-2">
                      <PhoneCall className="w-3.5 h-3.5 text-indigo-500 flex-shrink-0" />
                      <span className="font-semibold text-[11px]">9025020293</span>
                    </a>
                    <div className="text-[10px] text-slate-400 font-medium leading-tight">Available immediately for corporate consultation, contract or full-time roles.</div>
                  </div>
                </div>
              </div>

              {/* Social profile grids */}
              <div>
                <span className="text-[9px] uppercase font-black text-slate-400 tracking-wider block mb-2">Explore Social Networks</span>
                <div className="flex flex-wrap gap-2">
                  <a
                    href="https://github.com/SivanesanM"
                    target="_blank"
                    rel="noreferrer"
                    className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-[11px] font-bold border transition cursor-pointer ${
                      isDarkMode 
                        ? 'bg-slate-950 border-slate-850 hover:bg-slate-800 text-slate-200 hover:border-slate-700' 
                        : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <Github className="w-3.5 h-3.5 text-indigo-500" />
                    <span>GitHub Profile</span>
                  </a>

                  <a
                    href="https://linkedin.com/in/Sivanesan"
                    target="_blank"
                    rel="noreferrer"
                    className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-[11px] font-bold border transition cursor-pointer ${
                      isDarkMode 
                        ? 'bg-slate-950 border-slate-850 hover:bg-slate-800 text-slate-200 hover:border-slate-700' 
                        : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <Linkedin className="w-3.5 h-3.5 text-indigo-500" />
                    <span>LinkedIn Connect</span>
                  </a>

                  <a
                    href="https://sivanesan.dev"
                    target="_blank"
                    rel="noreferrer"
                    className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-[11px] font-bold border transition cursor-pointer ${
                      isDarkMode 
                        ? 'bg-slate-950 border-slate-850 hover:bg-slate-800 text-slate-200 hover:border-slate-700' 
                        : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <Globe className="w-3.5 h-3.5 text-indigo-500" />
                    <span>Creator Portfolio</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 5. CONTACT & EXPERIMENTS LAB SECTION */}
      <section className="max-w-4xl mx-auto px-4">
        <div className={`p-8 rounded-3xl border backdrop-blur-md relative overflow-hidden ${
          isDarkMode ? 'bg-slate-900/50 border-slate-800' : 'bg-white border-slate-100 shadow-2xl shadow-slate-100'
        }`}>
          {/* Subtle backgrounds */}
          <div className="absolute -left-16 -top-16 w-32 h-32 bg-indigo-500/5 blur-xl pointer-events-none rounded-full" />
          
          <div className="max-w-2xl mx-auto text-center space-y-4 mb-8">
            <span className="text-[10px] uppercase font-black text-rose-400 tracking-widest">Get In Touch</span>
            <h2 className={`text-2xl sm:text-3xl font-black tracking-tight ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>Connect with SaaS Architecture</h2>
            <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-500'} leading-relaxed`}>
              Have queries about integrating specific APIs, custom schedules, or deployment patterns? Drop a message to our portal developer!
            </p>
          </div>

          <form onSubmit={handleContactSubmit} className="space-y-4 max-w-xl mx-auto text-left">
            {formSubmitted ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-emerald-500/10 border border-emerald-500/20 p-5 rounded-2xl text-center space-y-2"
              >
                <div className="w-10 h-10 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Check className="w-5 h-5" />
                </div>
                <h4 className="font-extrabold text-sm text-emerald-400">Message logged inside memory logs successfully!</h4>
                <p className="text-xs text-slate-400 leading-relaxed max-w-md mx-auto">
                  SaaS simulation active. This contact is logged within the localized app metrics. You can connect with portfolio lead **Sivanesan M** at `it055m.sivanesan@gmail.com`.
                </p>
              </motion.div>
            ) : (
              <div className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400 block mb-1.5">Your Name</label>
                    <input
                      type="text"
                      required
                      value={contactName}
                      onChange={(e) => setContactName(e.target.value)}
                      placeholder="e.g. Sivanesan M"
                      className={`w-full px-4 py-2.5 rounded-xl border text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/15 focus:border-indigo-500/60 transition ${
                        isDarkMode 
                          ? 'bg-slate-950/60 border-slate-800 text-white placeholder-slate-600' 
                          : 'bg-slate-50 border-slate-200 text-slate-800 placeholder-slate-400'
                      }`}
                    />
                  </div>
                  
                  <div>
                    <label className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400 block mb-1.5">Contact Email</label>
                    <input
                      type="email"
                      required
                      value={contactEmail}
                      onChange={(e) => setContactEmail(e.target.value)}
                      placeholder="e.g. it055m.sivanesan@gmail.com"
                      className={`w-full px-4 py-2.5 rounded-xl border text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/15 focus:border-indigo-500/60 transition ${
                        isDarkMode 
                          ? 'bg-slate-950/60 border-slate-800 text-white placeholder-slate-600' 
                          : 'bg-slate-50 border-slate-200 text-slate-800 placeholder-slate-400'
                      }`}
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400 block mb-1.5">Subject</label>
                  <select
                    value={contactSubject}
                    onChange={(e) => setContactSubject(e.target.value)}
                    className={`w-full px-4 py-2.5 rounded-xl border text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/15 focus:border-indigo-500/60 transition ${
                      isDarkMode 
                        ? 'bg-slate-950/60 border-slate-800 text-white' 
                        : 'bg-slate-50 border-slate-200 text-slate-800'
                    }`}
                  >
                    <option value="General Inquiry">General SaaS Inquiry</option>
                    <option value="Custom Database Setup">Custom PostgreSQL / Supabase Setup</option>
                    <option value="AI Scheduling integration">Generative AI Custom Flow</option>
                    <option value="Contract / freelance work">Contract Freelance Work</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400 block mb-1.5">Comments or Message</label>
                  <textarea
                    required
                    value={contactMsg}
                    onChange={(e) => setContactMsg(e.target.value)}
                    placeholder="Type your business requirements or feedback here..."
                    rows={4}
                    className={`w-full px-4 py-2.5 rounded-xl border text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/15 focus:border-indigo-500/60 transition ${
                      isDarkMode 
                        ? 'bg-slate-950/60 border-slate-800 text-white placeholder-slate-600' 
                        : 'bg-slate-50 border-slate-200 text-slate-800 placeholder-slate-400'
                    }`}
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-indigo-600 hover:bg-indigo-500 text-white py-3 rounded-xl font-extrabold text-xs tracking-wider flex items-center justify-center gap-1.5 transition active:scale-98 shadow-md cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" /> Dispatch Message to Sandbox
                </button>
              </div>
            )}
          </form>
        </div>
      </section>

    </div>
  );
}
