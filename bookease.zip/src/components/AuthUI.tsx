/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Mail, ShieldCheck, Key, RefreshCw, UserPlus, LogIn, ArrowRight, Sparkles, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface AuthUIProps {
  onSuccess: (adminEmail: string) => void;
  onCancel: () => void;
  isDarkMode: boolean;
}

export default function AuthUI({ onSuccess, onCancel, isDarkMode }: AuthUIProps) {
  // Mode: 'login' | 'signup' | 'forgot'
  const [mode, setMode] = useState<'login' | 'signup' | 'forgot'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [newsletter, setNewsletter] = useState(true);
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setErrorMsg('');
    setSuccessMsg('');

    try {
      // Simulate high-fidelity network request
      await new Promise((resolve) => setTimeout(resolve, 1000));

      if (mode === 'login') {
        if (email.trim() && password.length >= 4) {
          onSuccess(email);
        } else {
          setErrorMsg('Invalid email or password (must be at least 4 chars)');
        }
      } else if (mode === 'signup') {
        if (!email || !password || !fullName) {
          setErrorMsg('All fields are required.');
        } else {
          setSuccessMsg('Account created successfully! Auto-logging you in...');
          setTimeout(() => {
            onSuccess(email);
          }, 1500);
        }
      } else {
        if (!email) {
          setErrorMsg('Please specify your registered email');
        } else {
          setSuccessMsg('Passcode reset link was dispatched to your inbox.');
        }
      }
    } catch (err) {
      setErrorMsg('Server connection timeout. Try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const fillDemoCreds = () => {
    setEmail('it055m.sivanesan@gmail.com');
    setPassword('demopass123');
    setFullName('Sivanesan M');
  };

  return (
    <div className={`flex items-center justify-center min-h-[550px] p-4 text-left`}>
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        className={`w-full max-w-md p-8 rounded-3xl border backdrop-blur-2xl transition-all duration-300 relative overflow-hidden shadow-2xl ${
          isDarkMode 
            ? 'bg-slate-900/80 border-slate-700/60 shadow-slate-950/80 text-white' 
            : 'bg-white/90 border-slate-200/80 shadow-slate-200/80 text-slate-800'
        }`}
      >
        {/* Glow Element */}
        <div className="absolute -right-16 -top-16 w-36 h-36 bg-gradient-to-br from-indigo-500/20 to-purple-500/25 blur-2xl rounded-full" />
        
        {/* Logo */}
        <div className="flex items-center gap-2 mb-6">
          <div className="bg-indigo-600 text-white p-2 rounded-xl flex items-center justify-center shadow-md">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold tracking-tight">BookEase Auth</h2>
            <p className="text-[10px] uppercase font-bold tracking-widest text-indigo-400">SaaS Access Gate</p>
          </div>
        </div>

        <h3 className="text-lg font-black tracking-tight mb-1">
          {mode === 'login' && 'Access Admin Suite'}
          {mode === 'signup' && 'Register SaaS Workspace'}
          {mode === 'forgot' && 'Reset Secure Password'}
        </h3>
        <p className={`text-xs mb-6 ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
          {mode === 'login' && 'Admin credentials authorize calendar edits, live customer lists and mail sandboxing.'}
          {mode === 'signup' && 'Launch instant salon, tutor, consultant, or coaching hubs with 1 click.'}
          {mode === 'forgot' && 'Provide your workspace email and we will dispatch recovery coordinates.'}
        </p>

        {/* Feedback alerts */}
        <AnimatePresence mode="wait">
          {errorMsg && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="p-3 bg-rose-500/10 border border-rose-500/25 text-rose-400 text-xs rounded-xl font-semibold mb-4"
            >
              ⚠️ {errorMsg}
            </motion.div>
          )}

          {successMsg && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="p-3 bg-emerald-500/10 border border-emerald-500/25 text-emerald-400 text-xs rounded-xl font-semibold mb-4 flex items-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <span>{successMsg}</span>
            </motion.div>
          )}
        </AnimatePresence>

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === 'signup' && (
            <div>
              <label className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block mb-1.5">Business / Founder Name</label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-slate-400 text-sm">👤</span>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="e.g. Sivanesan M"
                  className={`w-full pl-10 pr-4 py-2.5 text-sm rounded-xl border focus:outline-none focus:ring-2 focus:ring-indigo-500/15 focus:border-indigo-500/60 transition ${
                    isDarkMode 
                      ? 'bg-slate-950/60 border-slate-800 text-slate-100 placeholder-slate-500' 
                      : 'bg-slate-50 border-slate-200 text-slate-800 placeholder-slate-400'
                  }`}
                />
              </div>
            </div>
          )}

          <div>
            <label className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block mb-1.5">Email Address</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="it055m.sivanesan@gmail.com"
                className={`w-full pl-10 pr-4 py-2.5 text-sm rounded-xl border focus:outline-none focus:ring-2 focus:ring-indigo-500/15 focus:border-indigo-500/60 transition ${
                  isDarkMode 
                    ? 'bg-slate-950/60 border-slate-800 text-slate-100 placeholder-slate-500' 
                    : 'bg-slate-50 border-slate-200 text-slate-800 placeholder-slate-400'
                }`}
              />
            </div>
          </div>

          {mode !== 'forgot' && (
            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">Workspace Passcode</label>
                {mode === 'login' && (
                  <button
                    type="button"
                    onClick={() => { setMode('forgot'); setErrorMsg(''); setSuccessMsg(''); }}
                    className="text-[10px] text-indigo-400 hover:text-indigo-300 font-bold tracking-wide"
                  >
                    Forgot passcode?
                  </button>
                )}
              </div>
              <div className="relative">
                <Key className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className={`w-full pl-10 pr-4 py-2.5 text-sm rounded-xl border focus:outline-none focus:ring-2 focus:ring-indigo-500/15 focus:border-indigo-500/60 transition ${
                    isDarkMode 
                      ? 'bg-slate-950/60 border-slate-800 text-slate-100 placeholder-slate-500' 
                      : 'bg-slate-50 border-slate-200 text-slate-800 placeholder-slate-400'
                  }`}
                />
              </div>
            </div>
          )}

          {mode === 'signup' && (
            <label className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer pt-1">
              <input
                type="checkbox"
                checked={newsletter}
                onChange={(e) => setNewsletter(e.target.checked)}
                className="accent-indigo-500"
              />
              <span>Subscribe to BookEase performance updates & tips</span>
            </label>
          )}

          <div className="pt-2">
            <button
              type="submit"
              disabled={isSubmitting}
              className={`w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-black text-sm flex items-center justify-center gap-2 transition active:scale-98 shadow-lg shadow-indigo-600/10 cursor-pointer ${
                isSubmitting ? 'brightness-75' : ''
              }`}
            >
              {isSubmitting ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" /> Working...
                </>
              ) : (
                <>
                  {mode === 'login' && 'Verify Credentials'}
                  {mode === 'signup' && 'Boot SaaS Workspace'}
                  {mode === 'forgot' && 'Reset Secure Password'}
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </form>

        {/* Alternate link selector and fast demo */}
        <div className="mt-6 pt-5 border-t border-slate-800/20 flex flex-col items-center justify-center gap-4 text-xs">
          <div className="flex gap-1.5 text-slate-400">
            <span>
              {mode === 'login' && "Don't have an admin workspace?"}
              {mode === 'signup' && "Already registered?"}
              {mode === 'forgot' && "Remembered your passcode?"}
            </span>
            <button
              onClick={() => {
                setErrorMsg('');
                setSuccessMsg('');
                if (mode === 'login') setMode('signup');
                else setMode('login');
              }}
              className="text-indigo-400 hover:text-indigo-300 font-bold"
            >
              {mode === 'login' && 'Create one free'}
              {mode === 'signup' && 'Login here'}
              {mode === 'forgot' && 'Return to login'}
            </button>
          </div>

          {/* Quick Trial Fill */}
          <button
            onClick={fillDemoCreds}
            className={`px-4 py-2 rounded-xl text-[11px] font-extrabold tracking-wider border transition flex items-center gap-1.5 cursor-pointer ${
              isDarkMode 
                ? 'bg-slate-950/40 hover:bg-slate-900 border-slate-800/80 text-indigo-200' 
                : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-indigo-700'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 animate-pulse text-indigo-400" />
            <span>Load Quick Demo Coordinates (Sivanesan)</span>
          </button>

          <button onClick={onCancel} className="text-slate-400 hover:text-slate-300 text-[10px] font-bold">
            ← Cancel and Return
          </button>
        </div>
      </motion.div>
    </div>
  );
}
