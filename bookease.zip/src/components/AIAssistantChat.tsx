import React, { useState, useRef, useEffect } from 'react';
import { Sparkles, X, Send, Bot, User, CornerDownLeft, RefreshCcw, HelpCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
}

// Simple dynamic formatter to handle styling without adding bulky markdown packages
function formatText(text: string) {
  // Split by double asterisks first for bolding
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return parts.map((part, idx) => {
    if (part.startsWith('**') && part.endsWith('**')) {
      return (
        <strong key={idx} className="font-extrabold text-indigo-400 dark:text-indigo-300">
          {part.slice(2, -2)}
        </strong>
      );
    }
    // Simple inline items or bullet highlights
    if (part.startsWith('- ') || part.startsWith('* ')) {
      return (
        <span key={idx} className="block pl-4 py-0.5 relative before:content-['•'] before:absolute before:left-1 before:text-indigo-500">
          {part.slice(2)}
        </span>
      );
    }
    return <span key={idx}>{part}</span>;
  });
}

function getClientFallbackResponse(message: string): string {
  const lowercase = message.toLowerCase().trim();
  
  if (lowercase.includes("salon") || lowercase.includes("hair") || lowercase.includes("facial") || lowercase.includes("nail") || lowercase.includes("manicure") || lowercase.includes("balayage") || lowercase.includes("cut")) {
    return `👋 **BookEase Salon & Beauty Services & Pricing**:
- **Precision Haircut & Styling** — **$65** (45 mins)
  *Custom senior-stylist haircut including premium deep wash, massage, and blow-dry.*
- **Signature Facial Treatment** — **$85** (60 mins)
  *An invigorating deep cleanse, scrub, hydration mask, and facial acupressure massage.*
- **Balayage Hair Coloring** — **$180** (120 mins)
  *Hand-painted premium French highlights with protective bond-building treatment included.*
- **Luxury Gel Manicure** — **$45** (45 mins)
  *Full nail care, cuticle care, custom gel polish, and calming lavender hand massage.*

**Specialists available:**
- **Sarah Jenkins** (Senior Hair Stylist, Salon) – 09:00 - 18:00
- **Antoine Rossi** (Master Aesthetician) – 10:00 - 19:00 (Facials)
- **Chloe Thompson** (Gel Extensions & Nail Art) – 09:00 - 17:00 (Nails)

*You can lock in your time with any of these professionals on our live **Booking** page!*`;
  }

  if (lowercase.includes("gym") || lowercase.includes("fit") || lowercase.includes("workout") || lowercase.includes("train") || lowercase.includes("yoga") || lowercase.includes("hiit") || lowercase.includes("athletic")) {
    return `👋 **BookEase Fitness & Personal Training & Pricing**:
- **1-on-1 Personal Training** — **$90** (60 mins)
  *Custom strength, conditioning, and posture session tailored to your dynamic goals.*
- **Vinyasa Yoga Guided Flow** — **$60** (60 mins)
  *Individualized yoga practice targeting core strength, alignment, and breath-control.*
- **HIIT & Endurance Training** — **$75** (45 mins)
  *High-intensity interval program designed to spike your metabolism and build stamina.*

**Specialists available:**
- **Coach Jack Harrison** (Strength, Athletic Prep) – 06:00 - 15:00
- **Maria Sanchez** (Yoga & Alignment) – 08:00 - 17:00

*Head over to the **Booking** tab in our navbar to select your slot!*`;
  }

  if (lowercase.includes("tutor") || lowercase.includes("math") || lowercase.includes("calculus") || lowercase.includes("sat") || lowercase.includes("chem") || lowercase.includes("academic") || lowercase.includes("act") || lowercase.includes("study")) {
    return `👋 **BookEase Academic Tutoring & Pricing**:
- **Advanced Calculus Coaching** — **$55** (60 mins)
  *Visual breakdowns of limits, derivatives, integration, and physics applications.*
- **SAT / ACT Prep Session** — **$80** (90 mins)
  *Strategic analysis of test layouts, math shortcuts, and critical reading.*
- **High School Chemistry Lab Review** — **$50** (60 mins)
  *Stoichiometry, molecular geometry, and thermodynamic calculation breakdowns.*

**Specialists available:**
- **Dr. Alex Chen** (Math & Calculus Specialist) – 13:00 - 20:00
- **Prof. Clara Sterling** (Chemistry & SAT Preparation) – 11:00 - 19:00

*Ensure your academic progression is secure by picking a tutoring slot on **Booking**!*`;
  }

  if (lowercase.includes("doctor") || lowercase.includes("pediatric") || lowercase.includes("medical") || lowercase.includes("skin") || lowercase.includes("clinic") || lowercase.includes("health") || lowercase.includes("exam")) {
    return `👋 **BookEase Clinic & Medical Services & Pricing**:
- **General Medical Examination** — **$120** (30 mins)
  *Comprehensive physical evaluation, vital signs screening, and generic lifestyle review.*
- **Pediatric Care Consultation** — **$110** (30 mins)
  *Caring development surveillance, immunization schedule checks, and child clinical triage.*
- **Dermatological Skin Inspection** — **$135** (40 mins)
  *Specialized diagnostic check for moles, lesions, rashes, and skincare therapy.*

**Specialists available:**
- **Dr. Robert Carter** (Internal Medicine) – 09:00 - 16:00
- **Dr. Emily Vance** (Dermatology, Pediatrics) – 08:30 - 15:30

*Schedule an instant checkup appointment inside the **Booking** panel.*`;
  }

  if (lowercase.includes("consult") || lowercase.includes("saas") || lowercase.includes("tax") || lowercase.includes("architecture") || lowercase.includes("finance") || lowercase.includes("cto") || lowercase.includes("cloud")) {
    return `👋 **BookEase SaaS & Financial Consulting & Pricing**:
- **Tech Architecture Review** — **$250** (60 mins)
  *Review of Cloud system infrastructure, bottlenecks, and security design.*
- **Tax Planning & Business Setup** — **$180** (60 mins)
  *Asset structure advice, state filing optimization, and deductions audit.*
- **Fractional CTO Consultation** — **$320** (90 mins)
  *Strategic roadmap audit, developer resource planning, and product delivery.*

**Specialists available:**
- **Marcus Vance** (Principal Cloud Architect) – 10:00 - 18:00
- **David Kojo** (Chartered Startup CPA) – 09:00 - 17:00

*Book our professional consulting review directly on our **Booking** screen!*`;
  }

  if (lowercase.includes("coach") || lowercase.includes("life") || lowercase.includes("career") || lowercase.includes("transition") || lowercase.includes("mindset") || lowercase.includes("leadership")) {
    return `👋 **BookEase Life & Career Coaching & Pricing**:
- **Executive Leadership Strategy** — **$150** (60 mins)
  *Conflict resolution, corporate team alignment, and performance psychology.*
- **Career Transition Roadmap** — **$110** (60 mins)
  *Resume reframing, high-leverage interview roleplays, and negotiation.*
- **Life & Mindset Calibration** — **$95** (60 mins)
  *Goal mapping, self-advocacy drills, positive habit loops, and productivity.*

**Specialists available:**
- **Coach Elena Rostova** (Peak Mindsets) – 09:00 - 17:00
- **Coach Tyler Smith** (Career Strategist) – 10:00 - 18:00

*Unlock your customized peak training by booking onto the scheduler!*`;
  }

  if (lowercase.includes("price") || lowercase.includes("pricing") || lowercase.includes("how much") || lowercase.includes("cost") || lowercase.includes("fee") || lowercase.includes("rate") || lowercase.includes("$")) {
    return `👋 **BookEase Pricing Overview**:
Here is a quick overview of our popular services. You can view all descriptions on our **Booking** page:
- **Salon**: Precision Haircut ($65) | Signature Facial ($85) | Balayage highlights ($180) | Gel Manicure ($45)
- **Fitness & Training**: Personal Training ($90) | Yoga ($60) | HIIT session ($75)
- **Tutoring**: Calculus coaching ($55) | SAT preparation ($80) | Chemistry ($50)
- **Medical & Doctors**: General Exam ($120) | Pediatrics ($110) | Skin Inspection ($135)
- **Consulting**: Tech Architecture ($250) | Business Tax Planning ($180) | Fractional CTO ($320)
- **Coaching**: Executive Leadership ($150) | Career Transition ($110) | Mindset Calibration ($95)

*Simply click 'Booking' in the top header to choose your preferred service, length, and staff.*`;
  }

  if (lowercase.includes("availab") || lowercase.includes("slot") || lowercase.includes("schedule") || lowercase.includes("when") || lowercase.includes("time") || lowercase.includes("hour")) {
    return `📅 **BookEase Scheduling and Slots Availability**:
- All operations run standard business hours (generally **09:00 to 18:00**) with early options for Fitness with **Jack Harrison** starting at **06:00**, and evening/night options for Academic Tutoring with **Dr. Alex Chen** up to **20:00**.
- You can filter and adjust custom appointment durations (**30, 60, or 90 minutes**) inside our dynamic booking platform. Time slots list automatically update instantly!

*Simply select your preferred slot dynamically under the **Booking** tab in our header!*`;
  }

  return `👋 Greetings! I am the **BookEase Companion** support bot. 

Currently, our primary AI cloud servers are experiencing transient high demand, so I've stepped in to assist you instantly. I can answer inquiries regarding:
1. 💇‍♀️ **Beauty & Hair Salon** services and pricing (cuts, colors, facials, gel manicure).
2. 🏋️‍♂️ **Fitness Gym Training** programs (1-on-1, yoga, HIIT).
3. 📐 **Academic Tutoring** (calculus, SAT/ACT prep, chemistry).
4. 🩺 **Medical Clinic** appointments (exams, pediatrics, skin).
5. 💼 **Consulting** packages (Tech reviews, CPAs, Fractional CTOs).
6. 📈 **Life & Career Coaching** sessions (leadership, interviews, calibration).

What information or pricing can I help you find? Try typing **"salon prices" or "coaching options"**!`;
}

export default function AIAssistantChat({ isDarkMode }: { isDarkMode: boolean }) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg_welcome',
      role: 'model',
      text: "👋 Hello! I am your **BookEase Companion**. I can help you find pricing, service details, and professional scheduling information. Try asking about our **beauty salons, fitness programs, calculus tutoring, or tech consulting**!"
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorStatus, setErrorStatus] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Suggested prompt chips to help steer users
  const SUGGESTED_CHIPS = [
    { label: "💇‍♀️ Salon Prices", prompt: "What salon services and pricing do you offer?" },
    { label: "🏋️‍♂️ Personal Trainers", prompt: "Tell me about your fitness trainers and pricing" },
    { label: "📐 Academic Tutors", prompt: "What academic tutors and courses are available?" },
    { label: "💼 Tech Consulting", prompt: "What is the price of a Tech Architecture Review?" }
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen, isLoading]);

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim() || isLoading) return;

    setErrorStatus(null);
    const userMsg: ChatMessage = {
      id: `msg_user_${Date.now()}`,
      role: 'user',
      text: textToSend
    };

    setMessages(prev => [...prev, userMsg]);
    setInputValue('');
    setIsLoading(true);

    try {
      // Map previous messages to the structured array format for backend consumption
      const historyPayload = messages.map(m => ({
        role: m.role,
        text: m.text
      }));

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: textToSend,
          history: historyPayload
        })
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `HTTP ${response.status} Error`);
      }

      const data = await response.json();
      
      const assistantMsg: ChatMessage = {
        id: `msg_ai_${Date.now()}`,
        role: 'model',
        text: data.text || "I apologize, I didn't receive a clean reply from the core brain."
      };

      setMessages(prev => [...prev, assistantMsg]);
    } catch (err: any) {
      console.warn("AI Communication Error fallback triggered:", err);
      const fallbackText = getClientFallbackResponse(textToSend);
      const assistantMsg: ChatMessage = {
        id: `msg_ai_${Date.now()}`,
        role: 'model',
        text: fallbackText
      };
      setMessages(prev => [...prev, assistantMsg]);
      setErrorStatus(null);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();
    handleSendMessage(inputValue);
  };

  return (
    <div className="fixed bottom-6 right-6 z-[100] font-sans">
      
      {/* 1. FLOATING CHAT TRIGGER BUTTON */}
      <motion.button
        id="btn_ai_chatbot_trigger"
        onClick={() => setIsOpen(!isOpen)}
        className={`relative p-4 rounded-full shadow-2xl flex items-center justify-center transition-all duration-300 pointer-events-auto cursor-pointer border ${
          isOpen
            ? 'bg-rose-600 hover:bg-rose-500 border-rose-500 text-white shadow-rose-600/25'
            : 'bg-indigo-600 hover:bg-indigo-500 border-indigo-500 text-white shadow-indigo-600/30'
        }`}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        title="Chat with BookEase AI"
      >
        <AnimatePresence mode="wait">
          {isOpen ? (
            <motion.div
              key="close"
              initial={{ rotate: -90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: 90, opacity: 0 }}
              transition={{ duration: 0.15 }}
            >
              <X className="w-6 h-6" />
            </motion.div>
          ) : (
            <motion.div
              key="sparkles"
              initial={{ rotate: 90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: -90, opacity: 0 }}
              transition={{ duration: 0.15 }}
              className="flex items-center gap-1"
            >
              <Sparkles className="w-6 h-6" />
              <span className="text-xs font-black tracking-tight uppercase pr-1 select-none hidden md:inline-block">AI Advisor</span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Pulse Dot Accent */}
        {!isOpen && (
          <span className="absolute top-0 right-0 h-3 w-3 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-950 animate-ping" />
        )}
      </motion.button>

      {/* 2. CHAT DRAWER PANEL */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            id="panel_ai_chatbot_drawer"
            initial={{ opacity: 0, y: 30, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.95 }}
            transition={{ type: 'spring', damping: 20, stiffness: 260 }}
            className={`absolute bottom-20 right-0 w-[92vw] sm:w-[440px] h-[580px] rounded-3xl overflow-hidden border shadow-3xl flex flex-col ${
              isDarkMode 
                ? 'bg-slate-900/95 border-slate-800 text-slate-100 shadow-slate-950/80 backdrop-blur-xl' 
                : 'bg-white border-slate-200 text-slate-800 shadow-slate-300/60'
            }`}
          >
            
            {/* Header section with branding */}
            <div className={`p-4 border-b flex items-center justify-between ${
              isDarkMode ? 'bg-slate-950 border-slate-800' : 'bg-slate-50 border-slate-200'
            }`}>
              <div className="flex items-center gap-2.5">
                <div className="bg-indigo-600 p-2 rounded-2xl flex items-center justify-center">
                  <Bot className="w-4 h-4 text-indigo-100" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <h3 className="text-sm font-extrabold tracking-tight">BookEase Companion</h3>
                    <span className="text-[10px] bg-indigo-500/10 text-indigo-500 font-extrabold px-1.5 py-0.5 rounded-full dark:text-indigo-400">Gemini AI</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Expert Support Bot</span>
                  </div>
                </div>
              </div>
              <button 
                onClick={() => setIsOpen(false)}
                className={`p-1.5 rounded-xl border transition ${
                  isDarkMode ? 'border-slate-800 hover:bg-slate-800 text-slate-400' : 'border-slate-200 hover:bg-slate-100 text-slate-500'
                }`}
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Message Area Section */}
            <div className={`flex-1 overflow-y-auto p-4 space-y-4 ${
              isDarkMode ? 'bg-slate-900/60' : 'bg-slate-50/40'
            }`}>
              
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`flex gap-2 max-w-[85%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                    
                    {/* Role Icon / Avatar */}
                    <div className={`w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 ${
                      msg.role === 'user'
                        ? 'bg-indigo-600 text-white'
                        : isDarkMode ? 'bg-slate-950 text-indigo-400 border border-slate-800' : 'bg-white text-indigo-600 border border-slate-200'
                    }`}>
                      {msg.role === 'user' ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
                    </div>

                    {/* Chat Bubble card */}
                    <div className={`p-3.5 rounded-2xl text-xs leading-relaxed space-y-2 whitespace-pre-wrap ${
                      msg.role === 'user'
                        ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/15'
                        : isDarkMode
                          ? 'bg-slate-950/80 border border-slate-850 text-slate-200'
                          : 'bg-white shadow border border-slate-100 text-slate-700'
                    }`}>
                      {formatText(msg.text)}
                    </div>

                  </div>
                </div>
              ))}

              {/* Typing generation animation load state */}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="flex gap-2 max-w-[85%]">
                    <div className={`w-7 h-7 rounded-lg flex items-center justify-center bg-slate-950 text-indigo-400 border border-slate-800`}>
                      <Bot className="w-3.5 h-3.5" />
                    </div>
                    <div className={`p-3.5 rounded-2xl text-xs card flex items-center gap-1.5 ${
                      isDarkMode ? 'bg-slate-950' : 'bg-white border'
                    }`}>
                      <span className="text-[10px] text-slate-400 font-medium">Assistant is formulating response</span>
                      <span className="flex gap-1">
                        <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce delay-75" />
                        <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce delay-150" />
                        <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce delay-300" />
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Dynamic error display banner */}
              {errorStatus && (
                <div className={`p-4 rounded-2xl border flex flex-col gap-2 ${
                  isDarkMode ? 'bg-rose-950/30 border-rose-900 text-rose-200' : 'bg-rose-50 border-rose-200 text-rose-800'
                }`}>
                  <span className="text-[11px] font-extrabold flex items-center gap-1.5">
                    <HelpCircle className="w-4 h-4 text-rose-500" /> API Server Connection Alert
                  </span>
                  <span className="text-[10px] leading-relaxed opacity-95">{errorStatus}</span>
                  <button
                    onClick={() => handleSendMessage(messages[messages.length - 1]?.text || "Hello")}
                    className="self-start text-[9px] font-black uppercase tracking-wider bg-rose-500/20 hover:bg-rose-500 text-rose-400 hover:text-white px-3 py-1.5 rounded-lg transition border border-rose-500/30 cursor-pointer"
                  >
                    Retry Connection
                  </button>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Quick-Suggestion Pills Tray */}
            {messages.length === 1 && !isLoading && (
              <div className={`p-3.5 border-t ${
                isDarkMode ? 'bg-slate-950/40 border-slate-850' : 'bg-slate-50 border-slate-200'
              }`}>
                <span className="text-[10px] text-slate-400 font-extrabold block uppercase tracking-wider mb-2">Prompt Suggestions:</span>
                <div className="flex flex-wrap gap-1.5">
                  {SUGGESTED_CHIPS.map((chip, i) => (
                    <button
                      key={i}
                      onClick={() => handleSendMessage(chip.prompt)}
                      className={`text-[10px] font-black px-2.5 py-1.5 rounded-xl border transition cursor-pointer ${
                        isDarkMode
                          ? 'bg-slate-900 border-slate-800 hover:border-slate-700 text-indigo-300 hover:bg-slate-800'
                          : 'bg-white border-slate-200 hover:border-slate-300 text-indigo-600 hover:bg-slate-100'
                      }`}
                    >
                      {chip.label}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Bottom Message Input Form */}
            <form 
              onSubmit={handleSubmitForm}
              className={`p-3 border-t flex items-center gap-2 ${
                isDarkMode ? 'bg-slate-950 border-slate-800' : 'bg-white border-slate-200'
              }`}
            >
              <input
                id="input_ai_chatbot"
                type="text"
                autoComplete="off"
                placeholder="Ask about booking or pricing..."
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                disabled={isLoading}
                className={`flex-1 text-xs px-3.5 py-2.5 rounded-xl border focus:outline-none focus:ring-1 transition ${
                  isDarkMode
                    ? 'bg-slate-900 border-slate-800 text-slate-100 focus:ring-indigo-500 focus:border-indigo-500'
                    : 'bg-slate-50 border-slate-200 text-slate-800 focus:ring-indigo-500 focus:border-indigo-500'
                }`}
              />
              <button
                id="btn_ai_chatbot_submit"
                type="submit"
                disabled={!inputValue.trim() || isLoading}
                className={`p-2.5 rounded-xl transition cursor-pointer  ${
                  !inputValue.trim() || isLoading
                    ? isDarkMode ? 'bg-slate-900 text-slate-600' : 'bg-slate-100 text-slate-300'
                    : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow shadow-indigo-600/10'
                }`}
                title="Send Message to Companion"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>

            {/* Tiny brand verification signature */}
            <div className={`py-1.5 text-center text-[9px] ${
              isDarkMode ? 'bg-slate-900 text-slate-500' : 'bg-slate-50 text-slate-400'
            }`}>
              Powered securely by Google Gemini &middot; Client Session Live
            </div>

          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
