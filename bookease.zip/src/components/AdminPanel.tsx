/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, Users, Calendar as CalendarIcon, Clock, DollarSign, Search, 
  Trash, CheckCircle, XCircle, Mail, Database, HelpCircle, AlertCircle, 
  RefreshCw, Settings, Sliders, ExternalLink, Linkedin, Github, Compass, 
  ChevronRight, ChevronLeft, Plus, Check, PlusCircle, Bell, MessageSquare, 
  Send, User, ArrowUpRight, Scissors, Dumbbell, GraduationCap, Stethoscope, Briefcase
} from 'lucide-react';
import { Booking, Customer, EmailLog, IndustryType, Service, StaffMember } from '../types';
import { INDUSTRIES, SERVICES, STAFF } from '../data';
import { bookEaseStore, registerListener, SQL_SEED_BLUEPRINT, getSupabaseDetails } from '../supabaseClient';
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { motion, AnimatePresence } from 'motion/react';

interface AdminPanelProps {
  currentIndustry: IndustryType;
  onIndustryChange: (ind: IndustryType) => void;
  onNavigateToBooking: () => void;
}

export default function AdminPanel({ 
  currentIndustry, 
  onIndustryChange, 
  onNavigateToBooking 
}: AdminPanelProps) {
  // Sync state with BookEaseStore
  const [bookings, setBookings] = useState<Booking[]>(bookEaseStore.getBookings());
  const [customers, setCustomers] = useState<Customer[]>(bookEaseStore.getCustomers());
  const [emailLogs, setEmailLogs] = useState<EmailLog[]>(bookEaseStore.getEmailLogs());
  
  // Tabs: 'dashboard' | 'calendar' | 'customers' | 'emails' | 'supabase'
  const [activeTab, setActiveTab] = useState<'dashboard' | 'calendar' | 'customers' | 'emails' | 'supabase'>('dashboard');
  
  // Search and Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [bookingStatusFilter, setBookingStatusFilter] = useState<string>('all');
  
  // Calendar settings
  const [calendarViewMode, setCalendarViewMode] = useState<'week' | 'month'>('week');
  const [calendarDateOffset, setCalendarDateOffset] = useState(0); // 0 = current week / month
  
  // Interactive selected items (e.g. open profile drawer)
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);
  const [editingNotes, setEditingNotes] = useState('');
  
  // Custom manual booking creator state
  const [isAddingBooking, setIsAddingBooking] = useState(false);
  const [newBService, setNewBService] = useState('');
  const [newBStaff, setNewBStaff] = useState('');
  const [newBDate, setNewBDate] = useState('2026-06-09');
  const [newBTime, setNewBTime] = useState('10:00');
  const [newBCustName, setNewBCustName] = useState('');
  const [newBCustEmail, setNewBCustEmail] = useState('');
  const [newBCustPhone, setNewBCustPhone] = useState('');

  // Toast log
  const [toasts, setToasts] = useState<{ id: string; msg: string; type: 'success' | 'info' | 'error' }[]>([]);

  const addToast = (msg: string, type: 'success' | 'info' | 'error' = 'success') => {
    const id = Date.now().toString();
    setToasts(prev => [...prev, { id, msg, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  };

  // Listen to store updates in real-time
  useEffect(() => {
    const unsubscribe = registerListener(() => {
      setBookings(bookEaseStore.getBookings());
      setCustomers(bookEaseStore.getCustomers());
      setEmailLogs(bookEaseStore.getEmailLogs());
    });
    return () => unsubscribe();
  }, []);

  const handleStatusChange = async (id: string, newStatus: Booking['status']) => {
    const updated = await bookEaseStore.updateBookingStatus(id, newStatus);
    if (updated) {
      addToast(`Appointment status changed to '${newStatus}'`, 'success');
    }
  };

  const handleMoveBooking = async (id: string, newDate: string, newTimeSlot: string) => {
    const updated = await bookEaseStore.updateBookingTime(id, newDate, newTimeSlot);
    if (updated) {
      addToast(`Rescheduled Booking to ${newDate} at ${newTimeSlot}`, 'info');
    }
  };

  const handleDeleteBooking = async (id: string) => {
    if (confirm('Are you sure you want to remove this booking permanently?')) {
      const ok = await bookEaseStore.deleteBooking(id);
      if (ok) {
        addToast('Appointment deleted permanently', 'error');
      }
    }
  };

  const handleCustomerNotesSave = async (id: string) => {
    const updated = await bookEaseStore.updateCustomerNotes(id, editingNotes);
    if (updated) {
      addToast('Customer notes updated successfully', 'success');
      setSelectedCustomerId(null);
    }
  };

  const triggerManualReminder = async (booking: Booking) => {
    await bookEaseStore.triggerReminderEmail(booking);
    addToast(`Friendly reminder email sent to ${booking.customerName}`, 'info');
  };

  const handleManualAddBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBService || !newBStaff || !newBCustName || !newBCustEmail || !newBCustPhone) {
      alert('Please fill all mandatory variables.');
      return;
    }
    const service = SERVICES.find(s => s.id === newBService);
    if (!service) return;

    await bookEaseStore.createBooking({
      customerName: newBCustName,
      customerEmail: newBCustEmail,
      customerPhone: newBCustPhone,
      customerNotes: 'Manual dashboard entry',
      serviceId: newBService,
      staffId: newBStaff,
      date: newBDate,
      timeSlot: newBTime,
      status: 'confirmed',
      price: service.price,
      industry: currentIndustry
    });

    addToast(`Created manual booking for ${newBCustName}!`, 'success');
    setIsAddingBooking(false);
    // Reset
    setNewBCustName('');
    setNewBCustEmail('');
    setNewBCustPhone('');
  };

  // Filter lists specifically for active industry view
  const industryBookings = bookings.filter(b => b.industry === currentIndustry);
  const todaysBookings = industryBookings.filter(b => b.date === '2026-06-09');
  const upcomingBookings = industryBookings.filter(b => b.date > '2026-06-09' && b.status !== 'cancelled');
  const completedBookings = industryBookings.filter(b => b.status === 'completed');
  const cancelledBookings = industryBookings.filter(b => b.status === 'cancelled');

  const activeCustomer = customers.find(c => c.id === selectedCustomerId);

  // Stats Counters
  const totalRevenue = completedBookings.reduce((sum, b) => sum + b.price, 0) + 
                       industryBookings.filter(b => b.date === '2026-06-09' && b.status === 'confirmed').reduce((sum, b) => sum + b.price, 0);
  
  const activeStaffCount = STAFF.filter(st => st.industry === currentIndustry).length;

  // --- ANALYTICAL CHART PARSING ---
  // 1. Revenue trend calculation over dates
  const parsedRevenueData = () => {
    const datesMap: { [date: string]: number } = {};
    // Seed basic range of dates June 1 to June 10
    for (let d = 1; d <= 10; d++) {
      datesMap[`2026-06-${String(d).padStart(2, '0')}`] = 0;
    }
    // Populate
    industryBookings.forEach(b => {
      if (b.status !== 'cancelled' && datesMap[b.date] !== undefined) {
        datesMap[b.date] += b.price;
      }
    });
    return Object.keys(datesMap).sort().map(date => ({
      name: date.slice(5), // Just MM-DD
      revenue: datesMap[date],
      bookings: industryBookings.filter(b => b.date === date && b.status !== 'cancelled').length
    }));
  };

  // 2. Popular services calculation
  const parsedPopularServices = () => {
    const list = SERVICES.filter(s => s.industry === currentIndustry);
    return list.map(srv => {
      const count = industryBookings.filter(b => b.serviceId === srv.id && b.status !== 'cancelled').length;
      return {
        name: srv.name.split(' ').slice(0, 2).join(' '), // truncate to 2 words
        fullName: srv.name,
        bookings: count
      };
    });
  };

  // --- CALENDAR MANAGEMENT DATA GENERATION ---
  const getWeekDates = () => {
    const baseDate = new Date('2026-06-09'); // Constant reference Point
    baseDate.setDate(baseDate.getDate() + (calendarDateOffset * 7));
    // Find previous Monday or starting point
    const day = baseDate.getDay();
    const diff = baseDate.getDate() - day + (day === 0 ? -6 : 1); // adjust when day is sunday
    const monday = new Date(baseDate.setDate(diff));
    
    const week = [];
    for (let i = 0; i < 7; i++) {
      const next = new Date(monday);
      next.setDate(monday.getDate() + i);
      const str = `${next.getFullYear()}-${String(next.getMonth() + 1).padStart(2, '0')}-${String(next.getDate()).padStart(2, '0')}`;
      week.push({
        dateStr: str,
        label: next.toLocaleDateString('en-US', { weekday: 'short' }),
        dayNum: next.getDate(),
        monthLabel: next.toLocaleDateString('en-US', { month: 'short' })
      });
    }
    return week;
  };

  const weekTimeline = getWeekDates();

  // Monthly dates helper
  const getMonthDateGrid = () => {
    const dates = [];
    // Standard June 2026 Grid starting from previous week Monday elements
    const start = new Date('2026-06-01');
    const startOffset = start.getDay(); // 1 = Monday
    for (let i = -startOffset + 1; i <= 30 + (7 - ((30 + startOffset) % 7)); i++) {
      const d = new Date('2026-06-01');
      d.setDate(i);
      dates.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`);
    }
    return dates;
  };

  const monthGrid = getMonthDateGrid();

  // Industry Visual config
  const getIndustryColorTheme = (ind: IndustryType) => {
    switch (ind) {
      case 'salon': return { primary: 'indigo', hex: '#4f46e5', ring: 'bg-indigo-600', text: 'text-indigo-600' };
      case 'fitness': return { primary: 'emerald', hex: '#059669', ring: 'bg-emerald-600', text: 'text-emerald-600' };
      case 'tutor': return { primary: 'amber', hex: '#d97706', ring: 'bg-amber-600', text: 'text-amber-600' };
      case 'doctor': return { primary: 'rose', hex: '#e11d48', ring: 'bg-rose-600', text: 'text-rose-600' };
      case 'consultant': return { primary: 'sky', hex: '#0284c7', ring: 'bg-sky-600', text: 'text-sky-600' };
      case 'coach': return { primary: 'violet', hex: '#7c3aed', ring: 'bg-violet-600', text: 'text-violet-600' };
    }
  };

  const themeConfig = getIndustryColorTheme(currentIndustry);

  return (
    <div className="flex flex-col min-h-screen bg-slate-900 text-slate-100">
      
      {/* Dynamic Toast Log Notification Drawer */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-2.5 max-w-sm">
        <AnimatePresence>
          {toasts.map((t) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: 30, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.85, transition: { duration: 0.15 } }}
              className={`p-4 rounded-xl shadow-2xl border flex items-start gap-3 text-sm font-semibold backdrop-blur ${
                t.type === 'success' 
                  ? 'bg-slate-950/95 border-emerald-500/30 text-emerald-400' 
                  : t.type === 'error' 
                    ? 'bg-slate-950/95 border-rose-500/30 text-rose-400' 
                    : 'bg-slate-950/95 border-sky-500/30 text-sky-400'
              }`}
            >
              <Bell className="w-5 h-5 flex-shrink-0 animate-bounce" />
              <span>{t.msg}</span>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Admin Panel Header Toolbar */}
      <header className="bg-slate-950/80 border-b border-slate-800/60 sticky top-0 z-40 backdrop-blur w-full">
        <div className="mx-auto px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className={`p-2.5 rounded-xl text-white ${themeConfig.ring} shadow-md shadow-slate-950`}>
              <Database className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
                BookEase <span className="text-[10px] bg-slate-800 text-slate-300 font-extrabold px-1.5 py-0.5 rounded uppercase">Admin Hub</span>
              </h1>
              <p className="text-xs text-slate-400">Manage records, calendars, emails and realtime-db</p>
            </div>
          </div>

          {/* Quick industry selector block */}
          <div className="flex items-center gap-2 bg-slate-900 p-1.5 rounded-xl border border-slate-800">
            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest pl-2">Role: </span>
            <select
              value={currentIndustry}
              id="select_industry_owner"
              onChange={(e) => onIndustryChange(e.target.value as IndustryType)}
              className="bg-slate-950 border border-slate-800 text-white rounded-lg text-xs font-bold py-1.5 px-3 focus:outline-none focus:ring-1 focus:ring-slate-700"
            >
              {INDUSTRIES.map(ind => (
                <option key={ind.id} value={ind.id}>{ind.name}</option>
              ))}
            </select>
            
            <button
              id="btn_top_scheduler_jump"
              onClick={onNavigateToBooking}
              className={`text-xs ml-1 bg-white hover:bg-slate-100 text-slate-950 font-bold py-1.5 px-3.5 rounded-lg flex items-center gap-1.5 transition cursor-pointer`}
            >
              <PlusCircle className="w-4 h-4 text-slate-600" /> Public Scheduler
            </button>
          </div>
        </div>
      </header>

      {/* Main Grid: Navigation Sidebar & Content Area */}
      <div className="flex-1 flex flex-col md:flex-row w-full max-w-7xl mx-auto px-4 py-6 gap-6">
        
        {/* Navigation Sidebar Panel */}
        <aside className="md:w-64 flex-shrink-0">
          <nav className="bg-slate-950 rounded-2xl p-4 border border-slate-800 flex flex-row md:flex-col gap-2 overflow-x-auto md:overflow-x-visible">
            <button
              id="btn_tab_dashboard"
              onClick={() => setActiveTab('dashboard')}
              className={`w-full text-left py-3 px-4 rounded-xl flex items-center gap-2.5 transition text-sm font-semibold cursor-pointer ${
                activeTab === 'dashboard' 
                  ? `${themeConfig.ring} text-white shadow-md shadow-slate-950` 
                  : 'text-slate-400 hover:text-white hover:bg-slate-900/60'
              }`}
            >
              <TrendingUp className="w-4 h-4" /> Dashboard
            </button>
            <button
              id="btn_tab_calendar"
              onClick={() => setActiveTab('calendar')}
              className={`w-full text-left py-3 px-4 rounded-xl flex items-center gap-2.5 transition text-sm font-semibold cursor-pointer ${
                activeTab === 'calendar' 
                  ? `${themeConfig.ring} text-white shadow-md shadow-slate-950` 
                  : 'text-slate-400 hover:text-white hover:bg-slate-900/60'
              }`}
            >
              <CalendarIcon className="w-4 h-4" /> Scheduler & Calendar
            </button>
            <button
              id="btn_tab_customers"
              onClick={() => setActiveTab('customers')}
              className={`w-full text-left py-3 px-4 rounded-xl flex items-center gap-2.5 transition text-sm font-semibold cursor-pointer ${
                activeTab === 'customers' 
                  ? `${themeConfig.ring} text-white shadow-md shadow-slate-950` 
                  : 'text-slate-400 hover:text-white hover:bg-slate-900/60'
              }`}
            >
              <Users className="w-4 h-4" /> Customer Directory
            </button>
            <button
              id="btn_tab_emails"
              onClick={() => setActiveTab('emails')}
              className={`w-full text-left py-3 px-4 rounded-xl flex items-center gap-2.5 transition text-sm font-semibold cursor-pointer ${
                activeTab === 'emails' 
                  ? `${themeConfig.ring} text-white shadow-md shadow-slate-950` 
                  : 'text-slate-400 hover:text-white hover:bg-slate-900/60'
              }`}
            >
              <Mail className="w-4 h-4" /> Notification Sandbox
            </button>
            <button
              id="btn_tab_supabase"
              onClick={() => setActiveTab('supabase')}
              className={`w-full text-left py-3 px-4 rounded-xl flex items-center gap-2.5 transition text-sm font-semibold cursor-pointer ${
                activeTab === 'supabase' 
                  ? `${themeConfig.ring} text-white shadow-md shadow-slate-950` 
                  : 'text-slate-400 hover:text-white hover:bg-slate-900/60'
              }`}
            >
              <Database className="w-4 h-4" /> Supabase Connection
            </button>

            {/* Re-seed button elements */}
            <div className="border-t border-slate-800/80 pt-4 mt-4 hidden md:block">
              <button
                onClick={() => {
                  if (confirm('Re-seed Default Demo Data? This will replace your customized local adjustments.')) {
                    bookEaseStore.clearAndReSeed();
                    addToast('Seeded pristine demo database!', 'info');
                  }
                }}
                className="w-full py-2 px-3 text-xs font-bold border border-slate-800 hover:border-slate-700 bg-slate-950 hover:bg-slate-900 text-slate-400 hover:text-white rounded-lg transition text-center cursor-pointer flex items-center justify-center gap-1"
              >
                <RefreshCw className="w-3" /> Re-Seed defaults
              </button>
            </div>
          </nav>
        </aside>

        {/* Panel Main Content Canvas */}
        <main className="flex-1 min-w-0 bg-slate-950 rounded-2xl border border-slate-800/60 p-6 shadow-xl relative overflow-hidden">
          
          {/* TAB 1: EXECUTIVE ANALYTICAL DASHBOARD */}
          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              
              {/* Widgets Stats Rows */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-slate-900/75 border border-slate-800 p-5 rounded-2xl text-left relative overflow-hidden">
                  <div className="absolute right-0 bottom-0 p-3 opacity-15"><DollarSign className="w-14 h-14" /></div>
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Calculated Revenue</span>
                  <p className="text-2xl font-black text-white mt-1">${totalRevenue}</p>
                  <p className="text-xs text-slate-400 mt-2">Active & Completed sessions</p>
                </div>
                <div className="bg-slate-900/75 border border-slate-800 p-5 rounded-2xl text-left relative overflow-hidden">
                  <div className="absolute right-0 bottom-0 p-3 opacity-15"><CalendarIcon className="w-14 h-14" /></div>
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Upcoming Slots</span>
                  <p className="text-2xl font-black text-white mt-1">{upcomingBookings.length}</p>
                  <p className="text-xs text-slate-400 mt-2">Pending / Confirmed bookings</p>
                </div>
                <div className="bg-slate-900/75 border border-slate-800 p-5 rounded-2xl text-left relative overflow-hidden">
                  <div className="absolute right-0 bottom-0 p-3 opacity-15"><CheckCircle className="w-14 h-14" /></div>
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Completed Sessions</span>
                  <p className="text-2xl font-black text-white mt-1">{completedBookings.length}</p>
                  <p className="text-xs text-slate-400 mt-2">Historic bookings archive</p>
                </div>
                <div className="bg-slate-900/75 border border-slate-800 p-5 rounded-2xl text-left relative overflow-hidden">
                  <div className="absolute right-0 bottom-0 p-3 opacity-15"><Users className="w-14 h-14" /></div>
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Active Providers</span>
                  <p className="text-2xl font-black text-white mt-1">{activeStaffCount}</p>
                  <p className="text-xs text-slate-400 mt-2">Staff for {currentIndustry.toUpperCase()}</p>
                </div>
              </div>

              {/* Dynamic Recharts Section */}
              <div className="grid md:grid-cols-2 gap-6 pt-2">
                
                {/* 1. Area chart for Revenue & Traffic */}
                <div className="bg-slate-900/40 border border-slate-800/80 p-5 rounded-2xl">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-4 flex items-center gap-1.5">
                    <TrendingUp className="w-4 h-4 text-indigo-400" /> Revenue & Intake Trends (June)
                  </h3>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={parsedRevenueData()} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                        <defs>
                          <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor={themeConfig.hex} stopOpacity={0.4}/>
                            <stop offset="95%" stopColor={themeConfig.hex} stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                        <XAxis dataKey="name" stroke="#64748b" fontSize={11} />
                        <YAxis stroke="#64748b" fontSize={11} />
                        <Tooltip contentStyle={{ backgroundColor: '#020617', borderColor: '#334155', color: '#fff' }} />
                        <Area type="monotone" dataKey="revenue" stroke={themeConfig.hex} strokeWidth={2.5} fillOpacity={1} fill="url(#colorRevenue)" name="Revenue ($)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* 2. Bar chart for Service popularity */}
                <div className="bg-slate-900/40 border border-slate-800/80 p-5 rounded-2xl">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-4 flex items-center gap-1.5">
                    <Sliders className="w-4 h-4 text-emerald-400" /> Service Type Sales Volume
                  </h3>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={parsedPopularServices()} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                        <XAxis dataKey="name" stroke="#64748b" fontSize={10} />
                        <YAxis stroke="#64748b" fontSize={11} allowDecimals={false} />
                        <Tooltip contentStyle={{ backgroundColor: '#020617', borderColor: '#334155', color: '#fff' }} />
                        <Bar dataKey="bookings" fill={themeConfig.hex} radius={[4, 4, 0, 0]} name="Completed Bookings">
                          {parsedPopularServices().map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={themeConfig.hex} opacity={0.8 + (index * 0.08)} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              {/* Today's appointments and actions list */}
              <div className="bg-slate-900/40 border border-slate-800 rounded-2xl p-6">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
                  <div>
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      📅 Today's Bookings <span className="text-xs bg-slate-800 text-slate-300 font-bold px-2 py-0.5 rounded-full">{todaysBookings.length}</span>
                    </h3>
                    <p className="text-xs text-slate-500">Live scheduling queue configured for June 9, 2026</p>
                  </div>
                  <button
                    onClick={() => setIsAddingBooking(true)}
                    className={`text-xs ${themeConfig.ring} hover:brightness-110 text-white font-black py-2 px-4 rounded-xl flex items-center gap-1.5 transition cursor-pointer shadow-md`}
                  >
                    <Plus className="w-3.5 h-3.5" /> Book Client Manually
                  </button>
                </div>

                {/* Manual Add Booking Dialogue Form */}
                <AnimatePresence>
                  {isAddingBooking && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="bg-slate-950 p-5 rounded-xl border border-slate-800 mb-6"
                    >
                      <form onSubmit={handleManualAddBooking} className="space-y-4">
                        <div className="flex justify-between items-center pb-2 border-b border-slate-800">
                          <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">Quick Admin Booking Scheduler</h4>
                          <button type="button" onClick={() => setIsAddingBooking(false)} className="text-slate-500 hover:text-white text-xs">Cancel</button>
                        </div>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <label className="text-[10px] text-slate-400 font-bold block mb-1">Service Type</label>
                            <select
                              value={newBService}
                              onChange={(e) => {
                                setNewBService(e.target.value);
                                // select first matching staff
                                const filtered = STAFF.filter(st => st.services.includes(e.target.value));
                                if (filtered.length > 0) setNewBStaff(filtered[0].id);
                              }}
                              required
                              className="w-full bg-slate-900 border border-slate-800 text-slate-200 text-xs py-2 px-3 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-700"
                            >
                              <option value="">-- Choose --</option>
                              {SERVICES.filter(s => s.industry === currentIndustry).map(s => (
                                <option key={s.id} value={s.id}>{s.name} (${s.price})</option>
                              ))}
                            </select>
                          </div>
                          <div>
                            <label className="text-[10px] text-slate-400 font-bold block mb-1">Assigned Specialist</label>
                            <select
                              value={newBStaff}
                              onChange={(e) => setNewBStaff(e.target.value)}
                              required
                              className="w-full bg-slate-900 border border-slate-800 text-slate-200 text-xs py-2 px-3 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-700"
                            >
                              <option value="">-- Choose --</option>
                              {STAFF.filter(st => st.industry === currentIndustry).map(st => (
                                <option key={st.id} value={st.id}>{st.name}</option>
                              ))}
                            </select>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="text-[10px] text-slate-400 font-bold block mb-1">Schedule Date</label>
                            <input
                              type="date"
                              value={newBDate}
                              onChange={(e) => setNewBDate(e.target.value)}
                              required
                              className="w-full bg-slate-900 border border-slate-800 text-slate-200 text-xs py-1.5 px-3 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-700"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] text-slate-400 font-bold block mb-1">Schedule Time</label>
                            <input
                              type="text"
                              value={newBTime}
                              placeholder="e.g. 10:30"
                              onChange={(e) => setNewBTime(e.target.value)}
                              required
                              className="w-full bg-slate-900 border border-slate-800 text-slate-200 text-xs py-1.5 px-3 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-700"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 border-t border-slate-800 pt-3">
                          <div>
                            <label className="text-[10px] text-slate-400 font-bold block mb-1">Client Name</label>
                            <input
                              type="text"
                              value={newBCustName}
                              onChange={(e) => setNewBCustName(e.target.value)}
                              placeholder="Sivanesan M"
                              required
                              className="w-full bg-slate-900 border border-slate-800 text-slate-200 text-xs py-1.5 px-3 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-700"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] text-slate-400 font-bold block mb-1">Client Email</label>
                            <input
                              type="email"
                              value={newBCustEmail}
                              onChange={(e) => setNewBCustEmail(e.target.value)}
                              placeholder="it055m.sivanesan@gmail.com"
                              required
                              className="w-full bg-slate-900 border border-slate-800 text-slate-200 text-xs py-1.5 px-3 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-700"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] text-slate-400 font-bold block mb-1">Client Phone</label>
                            <input
                              type="text"
                              value={newBCustPhone}
                              onChange={(e) => setNewBCustPhone(e.target.value)}
                              placeholder="9025020293"
                              required
                              className="w-full bg-slate-900 border border-slate-800 text-slate-200 text-xs py-1.5 px-3 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-700"
                            />
                          </div>
                        </div>

                        <button
                          type="submit"
                          className={`w-full py-2.5 text-xs font-black rounded-lg text-white transition ${themeConfig.ring} cursor-pointer`}
                        >
                          Confirm & Add To Schedule
                        </button>
                      </form>
                    </motion.div>
                  )}
                </AnimatePresence>

                {todaysBookings.length > 0 ? (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="border-b border-slate-800 text-slate-400 font-bold uppercase tracking-wider">
                          <th className="py-3 px-2">Time</th>
                          <th className="py-3 px-2">Customer Info</th>
                          <th className="py-3 px-2">Service Ordered</th>
                          <th className="py-3 px-2">Assignee</th>
                          <th className="py-3 px-2">Price</th>
                          <th className="py-3 px-2">Status</th>
                          <th className="py-3 px-2 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {todaysBookings.map((b) => {
                          const srvObj = SERVICES.find(s => s.id === b.serviceId);
                          const stObj = STAFF.find(st => st.id === b.staffId);
                          return (
                            <tr key={b.id} className="border-b border-slate-800/60 hover:bg-slate-900/40 transition">
                              <td className="py-3.5 px-2 font-black text-slate-200">{b.timeSlot}</td>
                              <td className="py-3.5 px-2">
                                <strong className="text-white block">{b.customerName}</strong>
                                <span className="text-[10px] text-slate-400">{b.customerEmail}</span>
                              </td>
                              <td className="py-3.5 px-2">
                                <span className="font-semibold block">{srvObj?.name || 'Booking service'}</span>
                                <span className="text-[10px] text-slate-500">{b.customDuration || srvObj?.duration || 30} mins</span>
                              </td>
                              <td className="py-3.5 px-2">
                                <div className="flex items-center gap-1.5">
                                  <img src={stObj?.avatar} className="w-5 h-5 rounded-full object-cover border border-slate-800" alt="" />
                                  <span>{stObj?.name.split(' ')[0]}</span>
                                </div>
                              </td>
                              <td className="py-3.5 px-2 font-bold text-slate-300">${b.price}</td>
                              <td className="py-3.5 px-2">
                                <span className={`px-2 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-widest ${
                                  b.status === 'completed' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                                  b.status === 'confirmed' ? 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30' :
                                  b.status === 'pending' ? 'bg-amber-500/20 text-amber-500 border border-amber-500/30' :
                                  'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                                }`}>
                                  {b.status}
                                </span>
                              </td>
                              <td className="py-3.5 px-2 text-right space-x-1">
                                {b.status === 'confirmed' && (
                                  <button
                                    title="Complete Session"
                                    onClick={() => handleStatusChange(b.id, 'completed')}
                                    className="p-1.5 rounded-md hover:bg-slate-800 text-emerald-400 hover:text-emerald-300 transition cursor-pointer inline-flex"
                                  >
                                    <CheckCircle className="w-3.5 h-3.5" />
                                  </button>
                                )}
                                {b.status !== 'cancelled' && b.status !== 'completed' && (
                                  <>
                                    <button
                                      title="Cancel Session"
                                      onClick={() => handleStatusChange(b.id, 'cancelled')}
                                      className="p-1.5 rounded-md hover:bg-slate-800 text-rose-400 hover:text-rose-300 transition cursor-pointer inline-flex"
                                    >
                                      <XCircle className="w-3.5 h-3.5" />
                                    </button>
                                    <button
                                      title="Trigger Reminder Email"
                                      onClick={() => triggerManualReminder(b)}
                                      className="p-1.5 rounded-md hover:bg-slate-800 text-amber-500 hover:text-amber-400 transition cursor-pointer inline-flex"
                                    >
                                      <Send className="w-3.5 h-3.5" />
                                    </button>
                                  </>
                                )}
                                <button
                                  title="Delete Appt"
                                  onClick={() => handleDeleteBooking(b.id)}
                                  className="p-1.5 rounded-md hover:bg-slate-800 text-slate-500 hover:text-rose-400 transition cursor-pointer inline-flex"
                                >
                                  <Trash className="w-3.5 h-3.5" />
                                </button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="bg-slate-950 p-8 rounded-xl border border-slate-800 text-center text-slate-400 font-semibold text-xs border-dashed">
                     No appointments registered for today's current queue.
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: INTERACTIVE CALENDAR SCHEDULER & DRAG/DROP */}
          {activeTab === 'calendar' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    📆 Weekly / Monthly Interactive Planner
                  </h3>
                  <p className="text-xs text-slate-500">
                    To reschedule, drag an appointment slot block and drop it onto any calendar day grid cell.
                  </p>
                </div>

                <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-xl p-1">
                  <button
                    onClick={() => { setCalendarViewMode('week'); setCalendarDateOffset(0); }}
                    className={`text-xs px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${
                      calendarViewMode === 'week' ? 'bg-slate-950 text-white shadow' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Weekly
                  </button>
                  <button
                    onClick={() => { setCalendarViewMode('month'); }}
                    className={`text-xs px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${
                      calendarViewMode === 'month' ? 'bg-slate-950 text-white shadow' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Monthly (June)
                  </button>
                </div>
              </div>

              {/* Navigation timeline */}
              {calendarViewMode === 'week' && (
                <div className="flex items-center gap-3 bg-slate-900/40 p-3 rounded-xl border border-slate-800/80">
                  <button
                    onClick={() => setCalendarDateOffset(prev => prev - 1)}
                    className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-850 cursor-pointer"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>
                  
                  <strong className="text-sm text-slate-300 flex-1 text-center font-extrabold uppercase tracking-wide">
                    {weekTimeline[0].monthLabel} {weekTimeline[0].dayNum} - {weekTimeline[6].monthLabel} {weekTimeline[6].dayNum}, {weekTimeline[0].dateStr.split('-')[0]}
                  </strong>

                  <button
                    onClick={() => setCalendarDateOffset(prev => prev + 1)}
                    className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-850 cursor-pointer"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </div>
              )}

              {/* WEEKLY TIMELINE GRID VIEW */}
              {calendarViewMode === 'week' && (
                <div className="grid grid-cols-7 gap-3 border-slate-800">
                  {weekTimeline.map((col) => {
                    const isToday = col.dateStr === '2026-06-09';
                    const activeDayBookings = industryBookings.filter(b => b.date === col.dateStr && b.status !== 'cancelled');

                    return (
                      <div
                        key={col.dateStr}
                        onDragOver={(e) => e.preventDefault()}
                        onDrop={async (e) => {
                          const bId = e.dataTransfer.getData('bookingId');
                          if (bId) {
                            await handleMoveBooking(bId, col.dateStr, '12:00'); // defaults to 12PM on dropped day
                          }
                        }}
                        className={`min-h-[380px] p-2.5 rounded-xl border flex flex-col transition duration-200 ${
                          isToday 
                            ? 'bg-slate-900 border-indigo-500/25 ring-1 ring-indigo-500/10' 
                            : 'bg-slate-900/30 border-slate-800/80 hover:border-slate-800'
                        }`}
                      >
                        {/* Header cell */}
                        <div className="text-center pb-2 border-b border-slate-800/80 mb-3">
                          <span className={`text-[10px] font-bold uppercase ${isToday ? 'text-indigo-400' : 'text-slate-500'}`}>{col.label}</span>
                          <strong className={`block text-lg font-black leading-none mt-1 ${isToday ? 'text-white' : 'text-slate-300'}`}>{col.dayNum}</strong>
                          {isToday && <span className="text-[8px] bg-indigo-500/20 text-indigo-400 px-1.5 py-0.5 rounded font-extrabold uppercase mt-1 inline-block">TODAY</span>}
                        </div>

                        {/* Drag and Drop booking slot blocks container */}
                        <div className="flex-1 space-y-1.5">
                          {activeDayBookings.length > 0 ? (
                            activeDayBookings.map((b) => {
                              const srvObj = SERVICES.find(s => s.id === b.serviceId);
                              const stObj = STAFF.find(st => st.id === b.staffId);
                              return (
                                <div
                                  key={b.id}
                                  draggable
                                  onDragStart={(e) => {
                                    e.dataTransfer.setData('bookingId', b.id);
                                    addToast(`Dragging ${b.customerName}'s slot`, 'info');
                                  }}
                                  className="bg-slate-950 hover:bg-slate-850 p-2 rounded-lg border border-slate-800 hover:border-slate-700 cursor-move transition text-left group"
                                >
                                  <div className="flex justify-between items-center mb-1">
                                    <span className="font-extrabold text-[9px] text-slate-400">{b.timeSlot}</span>
                                    <span className="text-[7px] text-slate-500 uppercase tracking-widest">{stObj?.name.split(' ')[0]}</span>
                                  </div>
                                  <strong className="text-[10px] text-white block truncate leading-tight">{b.customerName}</strong>
                                  <span className="text-[9px] text-slate-400 leading-none truncate block mt-0.5">{srvObj?.name}</span>
                                </div>
                              );
                            })
                          ) : (
                            <span className="text-[10px] text-slate-600 block text-center py-12 italic">Empty</span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* MONTHLY CALENDAR GRID VIEW */}
              {calendarViewMode === 'month' && (
                <div>
                  <div className="grid grid-cols-7 text-center font-bold text-[10px] uppercase tracking-wider text-slate-500 pb-2 border-b border-slate-800">
                    <div>Sun</div>
                    <div>Mon</div>
                    <div>Tue</div>
                    <div>Wed</div>
                    <div>Thu</div>
                    <div>Fri</div>
                    <div>Sat</div>
                  </div>

                  <div className="grid grid-cols-7 gap-1.5 mt-2">
                    {monthGrid.map((dateStr) => {
                      const dayVal = parseInt(dateStr.split('-')[2]);
                      const isToday = dateStr === '2026-06-09';
                      const isCurrentMonth = dateStr.includes('-06-');
                      const activeDayBookings = industryBookings.filter(b => b.date === dateStr && b.status !== 'cancelled');

                      return (
                        <div
                          key={dateStr}
                          onDragOver={(e) => e.preventDefault()}
                          onDrop={async (e) => {
                            const bId = e.dataTransfer.getData('bookingId');
                            if (bId) {
                              await handleMoveBooking(bId, dateStr, '14:00'); // defaults to 2PM on dropped day
                            }
                          }}
                          className={`min-h-[80px] p-1.5 rounded-lg border transition text-left flex flex-col justify-between ${
                            isToday 
                              ? 'bg-slate-900 border-indigo-500/40 text-white' 
                              : isCurrentMonth 
                                ? 'bg-slate-900/20 border-slate-800/60 hover:border-slate-800'
                                : 'bg-slate-950/20 border-transparent text-slate-600 opacity-30 pointer-events-none'
                          }`}
                        >
                          <div className="flex justify-between items-center">
                            <span className="text-xs font-black">{dayVal}</span>
                            {isToday && <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full" />}
                          </div>

                          <div className="space-y-0.5 mt-1.5">
                            {activeDayBookings.slice(0, 2).map(b => (
                              <div 
                                key={b.id} 
                                draggable
                                onDragStart={(e) => {
                                  e.dataTransfer.setData('bookingId', b.id);
                                }}
                                className="bg-slate-950 hover:bg-slate-850 border border-slate-800 rounded px-1 py-0.5 text-[8px] font-bold text-slate-300 truncate cursor-move"
                              >
                                {b.timeSlot} {b.customerName.split(' ')[0]}
                              </div>
                            ))}
                            {activeDayBookings.length > 2 && (
                              <span className="text-[7px] text-indigo-400 font-extrabold pl-1 cursor-pointer">+{activeDayBookings.length - 2} more...</span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: CUSTOMER MANAGER DIRECTORY */}
          {activeTab === 'customers' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    👥 Customer Directory & LTV Metrics
                  </h3>
                  <p className="text-xs text-slate-500">Audit client booking logs, notes preferences and cumulative spending</p>
                </div>

                <div className="relative w-full sm:w-64">
                  <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search by client name..."
                    className="w-full pl-9 pr-4 py-2 bg-slate-900 border border-slate-800 text-xs text-white rounded-xl focus:outline-none focus:ring-1 focus:ring-slate-700"
                  />
                </div>
              </div>

              {/* Grid content */}
              <div className="grid md:grid-cols-3 gap-6">
                
                {/* Customers Table/List */}
                <div className="md:col-span-2 bg-slate-900/40 border border-slate-800 rounded-2xl p-4 overflow-hidden">
                  <table className="w-full text-xs text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-800 text-slate-400 font-extrabold uppercase tracking-wide">
                        <th className="py-2.5 px-1">Customer</th>
                        <th className="py-2.5 px-1">Contact Phone</th>
                        <th className="py-2.5 px-1">Bookings</th>
                        <th className="py-2.5 px-1">Spent LTV</th>
                        <th className="py-2.5 px-1 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {customers.filter(c => c.name.toLowerCase().includes(searchQuery.toLowerCase())).map((c) => (
                        <tr 
                          key={c.id} 
                          onClick={() => {
                            setSelectedCustomerId(c.id);
                            setEditingNotes(c.notes);
                          }}
                          className={`hover:bg-slate-900/85 transition cursor-pointer border-b border-slate-850/80 ${
                            selectedCustomerId === c.id ? 'bg-slate-900' : ''
                          }`}
                        >
                          <td className="py-3 px-1">
                            <strong className="text-white block font-black">{c.name}</strong>
                            <span className="text-[10px] text-indigo-400">{c.email}</span>
                          </td>
                          <td className="py-3 px-1 text-slate-400 font-semibold">{c.phone || 'N/A'}</td>
                          <td className="py-3 px-1 font-bold">{c.totalBookings} sessions</td>
                          <td className="py-3 px-1 text-emerald-400 font-extrabold">${c.lifetimeSpent}</td>
                          <td className="py-3 px-1 text-right">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedCustomerId(c.id);
                                setEditingNotes(c.notes);
                              }}
                              className="text-[10px] text-slate-400 hover:text-white border border-slate-800 hover:border-slate-700 bg-slate-950 px-2 py-1 rounded"
                            >
                              Manage Notes
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Profile Drawer and Notes Editor */}
                <div className="md:col-span-1 bg-slate-900/50 border border-slate-800 rounded-2xl p-5">
                  {activeCustomer ? (
                    <div className="space-y-4">
                      <div className="text-center pb-4 border-b border-slate-800">
                        <div className="w-16 h-16 bg-gradient-to-tr from-indigo-500 to-violet-500 rounded-2xl flex items-center justify-center mx-auto mb-3 shadow">
                          <User className="w-8 h-8 text-white" />
                        </div>
                        <h4 className="font-extrabold text-white text-base leading-none mb-1">{activeCustomer.name}</h4>
                        <span className="text-xs text-slate-500">{activeCustomer.email}</span>
                      </div>

                      <div className="space-y-2 text-xs">
                        <div className="flex justify-between p-2 bg-slate-950 rounded">
                          <span className="text-slate-500">Life-time Spent:</span>
                          <strong className="text-emerald-400">${activeCustomer.lifetimeSpent}</strong>
                        </div>
                        <div className="flex justify-between p-2 bg-slate-950 rounded">
                          <span className="text-slate-500">Completed Sessions:</span>
                          <strong>{activeCustomer.totalBookings}</strong>
                        </div>
                        {activeCustomer.lastBookingDate && (
                          <div className="flex justify-between p-2 bg-slate-950 rounded">
                            <span className="text-slate-500">Last Appointment:</span>
                            <span>{activeCustomer.lastBookingDate}</span>
                          </div>
                        )}
                      </div>

                      {/* Notes Box form */}
                      <div className="pt-2">
                        <label className="text-[10px] text-slate-500 font-bold block uppercase tracking-wider mb-1.5 flex items-center justify-between">
                          <span>Internal Staff Notes</span>
                          <span className="text-[8px] bg-slate-800 py-0.5 px-1.5 rounded text-indigo-300">Private</span>
                        </label>
                        <textarea
                          value={editingNotes}
                          onChange={(e) => setEditingNotes(e.target.value)}
                          placeholder="e.g. Needs extra attention on highlights. Coffee preference is decaf."
                          rows={4}
                          className="w-full bg-slate-950 border border-slate-800 p-2.5 rounded-lg text-xs focus:ring-1 focus:ring-indigo-600 focus:outline-none text-slate-200"
                        />
                        <button
                          onClick={() => handleCustomerNotesSave(activeCustomer.id)}
                          className="w-full py-2 bg-white hover:bg-slate-100 text-slate-950 font-black text-xs rounded-lg transition mt-2 cursor-pointer"
                        >
                          Save Customer Notes
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-24 text-slate-500 text-xs">
                      👈 Select a customer in the tree to audit history and write preference notes.
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: SIMULATED EMAIL SANDBOX & LOG */}
          {activeTab === 'emails' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  📧 Email Notifications Log & Sandbox
                </h3>
                <p className="text-xs text-slate-500">
                  Audit transactional emails generated automatically by BookEase scheduler events. Click any record to inspect the layout.
                </p>
              </div>

              {emailLogs.length > 0 ? (
                <div className="space-y-4">
                  {emailLogs.map((log) => {
                    return (
                      <div key={log.id} className="bg-slate-900 border border-slate-800 p-4 rounded-xl text-left relative overflow-hidden">
                        <div className="absolute right-3 top-3 flex items-center gap-1.5">
                          <span className="text-[9px] text-slate-500 font-semibold">{log.sentAt.slice(11, 16)} • {log.sentAt.split('T')[0]}</span>
                          <span className={`text-[8px] font-black px-1.5 py-0.5 rounded uppercase tracking-wider ${
                            log.type === 'confirmation' ? 'bg-indigo-500/20 text-indigo-400' :
                            log.type === 'reminder' ? 'bg-amber-500/20 text-amber-500' :
                            'bg-rose-500/20 text-rose-400'
                          }`}>
                            {log.type}
                          </span>
                        </div>

                        <div className="flex gap-2 items-center mb-2">
                          <Mail className="w-4 h-4 text-slate-500" />
                          <span className="text-xs text-slate-400">To: <strong>{log.recipientEmail}</strong></span>
                        </div>

                        <h4 className="text-sm font-extrabold text-white mb-2">{log.subject}</h4>
                        
                        <div className="bg-slate-950 p-3 rounded-lg border border-slate-850 text-xs text-slate-400 font-mono whitespace-pre-wrap leading-relaxed">
                          {log.body}
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="bg-slate-900/40 p-12 rounded-xl border border-slate-800 text-center text-slate-400 font-semibold text-xs border-dashed">
                  No notifications recorded yet. Create an appointment in the scheduler to trigger confirmations!
                </div>
              )}
            </div>
          )}

          {/* TAB 5: SUPABASE PERSISTENCE UTILITIES */}
          {activeTab === 'supabase' && (
            <div className="space-y-6">
              <div className="bg-slate-900/60 p-5 rounded-2xl border border-slate-800">
                <h3 className="text-base font-bold text-white flex items-center gap-2 mb-2">
                  <Database className="w-5 h-5 text-indigo-400 animate-pulse" /> Supabase Connection Manager & Sync Logs
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed mb-4">
                  By default, BookEase operates on a premium local storage backup layer so everything works perfectly in the sandbox out-of-the-box. Add your Supabase credential variables in `.env.example` in the files explorer to connect to a real, durable relational database.
                </p>

                {/* Connection check status */}
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className="relative flex h-3 w-3">
                      <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${getSupabaseDetails().isConfigured ? 'bg-emerald-400' : 'bg-amber-400'}`}></span>
                      <span className={`relative inline-flex rounded-full h-3 w-3 ${getSupabaseDetails().isConfigured ? 'bg-emerald-500' : 'bg-amber-500'}`}></span>
                    </span>
                    <div>
                      <strong className="text-xs text-white block">
                        {getSupabaseDetails().isConfigured ? 'Connected to Supabase Server Instance' : 'Operating on local backup database'}
                      </strong>
                      <span className="text-[10px] text-slate-500 font-mono">
                        {getSupabaseDetails().url || 'No custom variables configured'}
                      </span>
                    </div>
                  </div>

                  <span className="text-xs font-bold text-slate-400 px-3 py-1 bg-slate-900 rounded border border-slate-800">
                    REALTIME BROADCAST ENROLLMENT: ON
                  </span>
                </div>
              </div>

              {/* migration helper and sql instructions code selection */}
              <div className="space-y-3">
                <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">Supabase DB Initialization Code (Durable Cloud Persistence)</h4>
                <p className="text-xs text-slate-500">
                  Open your custom Supabase Project Console, select **SQL Editor** & copy the schema tables blueprint below to execute and seed tables automatically:
                </p>

                <div className="relative">
                  <pre className="bg-slate-950 border border-slate-850 p-4 rounded-xl text-xs text-slate-400 font-mono overflow-x-auto max-h-64 leading-relaxed">
                    {SQL_SEED_BLUEPRINT}
                  </pre>
                  
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(SQL_SEED_BLUEPRINT);
                      addToast('SQL Migration Script copied!', 'success');
                    }}
                    className="absolute top-2.5 right-2.5 bg-slate-800 hover:bg-indigo-600 text-white font-bold text-[10px] py-1 px-2.5 rounded transition cursor-pointer shadow"
                  >
                    Copy SQL Script
                  </button>
                </div>
              </div>
            </div>
          )}

        </main>
      </div>

      {/* SIVANESAN (CREATOR CARD FOOTER) - INTEGRATED ACCORDING TO USER'S INSTRUCTIONS */}
      <footer className="bg-slate-950 border-t border-slate-800/80 py-8 px-6 mt-16 text-center text-slate-500 text-xs text-left">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="text-center md:text-left">
            <span className="text-[10px] text-slate-600 uppercase tracking-widest font-bold block mb-1">BookEase Appointment Booking Platform</span>
            <p className="text-slate-400 font-bold text-sm">Designed & Maintained by <span className="text-white">Sivanesan M</span></p>
            <p className="text-xs text-slate-500 max-w-sm mt-1.5 leading-relaxed">
              BookEase is an online-ready dynamic SaaS layout with responsive role selection and state orchestration.
            </p>
          </div>

          <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center gap-4 text-xs">
            <div>
              <span className="text-[9px] uppercase font-bold text-indigo-400 block">Creator Direct Contact</span>
              <strong className="text-white text-sm block">Sivanesan M</strong>
              <span className="text-[10px] block text-slate-400">Mobile: +91 9025020293</span>
            </div>
            
            <div className="flex flex-col gap-1 text-xs text-slate-300 font-semibold">
              <a 
                href="mailto:it055m.sivanesan@gmail.com" 
                className="hover:text-white transition flex items-center gap-1"
              >
                <Mail className="w-3.5 h-3.5 text-rose-400" /> it055m.sivanesan@gmail.com
              </a>
              <div className="flex gap-4 mt-1">
                <a 
                  href="https://www.linkedin.com/in/m-sivanesan-66415b24a/" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="hover:text-indigo-400 transition flex items-center gap-1"
                >
                  <Linkedin className="w-3" /> Linkedin
                </a>
                <a 
                  href="https://github.com/Sivanesan-m" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="hover:text-slate-100 transition flex items-center gap-1"
                >
                  <Github className="w-3" /> Github
                </a>
              </div>
            </div>
          </div>
        </div>
      </footer>

    </div>
  );
}
