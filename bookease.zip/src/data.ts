/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Service, StaffMember, Booking, Customer } from './types';

export const INDUSTRIES = [
  { id: 'salon', name: 'Beauty & Hair Salon', label: 'Salon', icon: 'Scissors', color: 'indigo' },
  { id: 'fitness', name: 'Fitness & Gym Training', label: 'Fitness', icon: 'Dumbbell', color: 'emerald' },
  { id: 'tutor', name: 'Academic Tutoring', label: 'Tutor', icon: 'GraduationCap', color: 'amber' },
  { id: 'doctor', name: 'Medical Clinics', label: 'Doctor', icon: 'Stethoscope', color: 'rose' },
  { id: 'consultant', name: 'SaaS & Financial Consulting', label: 'Consultant', icon: 'Briefcase', color: 'sky' },
  { id: 'coach', name: 'Life & Career Coaching', label: 'Coach', icon: 'Compass', color: 'violet' }
] as const;

export const SERVICES: Service[] = [
  // --- SALON SERVICES ---
  {
    id: 'srv_salon_1',
    name: 'Precision Haircut & Styling',
    duration: 45,
    price: 65,
    description: 'Custom senior-stylist haircut including premium deep wash, massage, and blow-dry styling.',
    industry: 'salon'
  },
  {
    id: 'srv_salon_2',
    name: 'Signature Facial Treatment',
    duration: 60,
    price: 85,
    description: 'An invigorating deep cleanse, scrub, hydration mask, and facial acupressure massage.',
    industry: 'salon'
  },
  {
    id: 'srv_salon_3',
    name: 'Balayage Hair Coloring',
    duration: 120,
    price: 180,
    description: 'Hand-painted premium French highlights with protective bond-building treatment included.',
    industry: 'salon'
  },
  {
    id: 'srv_salon_4',
    name: 'Luxury Gel Manicure',
    duration: 45,
    price: 45,
    description: 'Full nail care, cuticle care, custom gel polish, and calming lavender hand massage.',
    industry: 'salon'
  },

  // --- FITNESS SERVICES ---
  {
    id: 'srv_fit_1',
    name: '1-on-1 Personal Training',
    duration: 60,
    price: 90,
    description: 'Custom strength, conditioning, and posture session tailored to your dynamic goals.',
    industry: 'fitness'
  },
  {
    id: 'srv_fit_2',
    name: 'Vinyasa Yoga Guided Flow',
    duration: 60,
    price: 60,
    description: 'Individualized yoga practice targeting core strength, alignment, breath-control and flexibility.',
    industry: 'fitness'
  },
  {
    id: 'srv_fit_3',
    name: 'HIIT & Endurance Training',
    duration: 45,
    price: 75,
    description: 'High-intensity interval program designed to spike your metabolism and build stamina.',
    industry: 'fitness'
  },

  // --- TUTOR SERVICES ---
  {
    id: 'srv_tut_1',
    name: 'Advanced Calculus Coaching',
    duration: 60,
    price: 55,
    description: 'Visual breakdowns of limits, derivatives, integration, and physics-based applications.',
    industry: 'tutor'
  },
  {
    id: 'srv_tut_2',
    name: 'SAT / ACT Prep Session',
    duration: 90,
    price: 80,
    description: 'Strategic analysis of test layouts, math shortcuts, critical reading, and essay-scoring.',
    industry: 'tutor'
  },
  {
    id: 'srv_tut_3',
    name: 'High School Chemistry Lab Review',
    duration: 60,
    price: 50,
    description: 'Stoichiometry, molecular geometry, and thermodynamic calculation breakdowns.',
    industry: 'tutor'
  },

  // --- DOCTOR SERVICES ---
  {
    id: 'srv_doc_1',
    name: 'General Medical Examination',
    duration: 30,
    price: 120,
    description: 'Comprehensive physical evaluation, vital signs screening, and generic lifestyle consult.',
    industry: 'doctor'
  },
  {
    id: 'srv_doc_2',
    name: 'Pediatric Care Consultation',
    duration: 30,
    price: 110,
    description: 'Caring development surveillance, immunization schedule checks, and gentle clinical review.',
    industry: 'doctor'
  },
  {
    id: 'srv_doc_3',
    name: 'Dermatological Skin Inspection',
    duration: 40,
    price: 135,
    description: 'Specialized diagnostic checkout for lesions, eczema, mole mapping, and acne therapies.',
    industry: 'doctor'
  },

  // --- CONSULTANT SERVICES ---
  {
    id: 'srv_con_1',
    name: 'Tech Architecture Review',
    duration: 60,
    price: 250,
    description: 'Review of Cloud system infrastructure, server bottlenecks, security design, and database schemas.',
    industry: 'consultant'
  },
  {
    id: 'srv_con_2',
    name: 'Tax Planning & Business Setup',
    duration: 60,
    price: 180,
    description: 'Asset structure advice, state filing optimization, deductions audit, and ledger planning.',
    industry: 'consultant'
  },
  {
    id: 'srv_con_3',
    name: 'Fractional CTO Consultation',
    duration: 90,
    price: 320,
    description: 'Strategic roadmap audit, developer resource planning, and product delivery management.',
    industry: 'consultant'
  },

  // --- COACH SERVICES ---
  {
    id: 'srv_ch_1',
    name: 'Executive Leadership Strategy',
    duration: 60,
    price: 150,
    description: 'Conflict resolution, corporate team alignment, and performance psychology for C-Suite leads.',
    industry: 'coach'
  },
  {
    id: 'srv_ch_2',
    name: 'Career Transition Roadmap',
    duration: 60,
    price: 110,
    description: 'Resume reframing, high-leverage interview roleplays, and negotiation frameworks.',
    industry: 'coach'
  },
  {
    id: 'srv_ch_3',
    name: 'Life & Mindset Calibration',
    duration: 60,
    price: 95,
    description: 'Goal mapping, self-advocacy drills, positive habit loops, and productivity workflows.',
    industry: 'coach'
  }
];

export const STAFF: StaffMember[] = [
  // --- SALON STAFF ---
  {
    id: 'st_sal_1',
    name: 'Sarah Jenkins',
    role: 'Senior Hair Stylist',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150',
    rating: 4.9,
    specialty: 'Balayage & Modern Cuts',
    services: ['srv_salon_1', 'srv_salon_3'],
    industry: 'salon',
    email: 'sarah.j@bookease.demo',
    workingHours: { start: '09:00', end: '18:00' }
  },
  {
    id: 'st_sal_2',
    name: 'Antoine Rossi',
    role: 'Master Aesthetician',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
    rating: 4.8,
    specialty: 'Hydra-Facials & Skin Therapy',
    services: ['srv_salon_2'],
    industry: 'salon',
    email: 'antoine.r@bookease.demo',
    workingHours: { start: '10:00', end: '19:00' }
  },
  {
    id: 'st_sal_3',
    name: 'Chloe Thompson',
    role: 'Nail Artist Stylist',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    rating: 4.9,
    specialty: 'Gel Extensions & Nail Art',
    services: ['srv_salon_4', 'srv_salon_1'],
    industry: 'salon',
    email: 'chloe.t@bookease.demo',
    workingHours: { start: '09:00', end: '17:00' }
  },

  // --- FITNESS STAFF ---
  {
    id: 'st_fit_1',
    name: 'Coach Jack Harrison',
    role: 'Strength & Conditioning Guide',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150',
    rating: 4.9,
    specialty: 'Powerlifting & Athletic Prep',
    services: ['srv_fit_1', 'srv_fit_3'],
    industry: 'fitness',
    email: 'jack.h@bookease.demo',
    workingHours: { start: '06:00', end: '15:00' }
  },
  {
    id: 'st_fit_2',
    name: 'Maria Sanchez',
    role: 'Certified Yoga Instructor',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
    rating: 4.9,
    specialty: 'Vinyasa Flow & Pranayama',
    services: ['srv_fit_2'],
    industry: 'fitness',
    email: 'maria.s@bookease.demo',
    workingHours: { start: '08:00', end: '17:00' }
  },

  // --- TUTOR STAFF ---
  {
    id: 'st_tut_1',
    name: 'Dr. Alex Chen',
    role: 'Mathematics Specialist',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150',
    rating: 5.0,
    specialty: 'Calculus, Algebra, SAT Math',
    services: ['srv_tut_1', 'srv_tut_2'],
    industry: 'tutor',
    email: 'alex.c@bookease.demo',
    workingHours: { start: '13:00', end: '20:00' }
  },
  {
    id: 'st_tut_2',
    name: 'Prof. Clara Sterling',
    role: 'Chemistry & Science Educator',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150',
    rating: 4.7,
    specialty: 'Analytical Chem & Math Basics',
    services: ['srv_tut_3', 'srv_tut_2'],
    industry: 'tutor',
    email: 'clara.s@bookease.demo',
    workingHours: { start: '11:00', end: '19:00' }
  },

  // --- DOCTOR STAFF ---
  {
    id: 'st_doc_1',
    name: 'Dr. Robert Carter',
    role: 'General Physician',
    avatar: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=150',
    rating: 4.8,
    specialty: 'Internal Medicine & Screenings',
    services: ['srv_doc_1'],
    industry: 'doctor',
    email: 'robert.carter@bookease.demo',
    workingHours: { start: '09:00', end: '16:00' }
  },
  {
    id: 'st_doc_2',
    name: 'Dr. Emily Vance',
    role: 'Dermatology & Skin Expert',
    avatar: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=150',
    rating: 4.9,
    specialty: 'Mole Diagnosis & Facial Care',
    services: ['srv_doc_3', 'srv_doc_2'],
    industry: 'doctor',
    email: 'emily.vance@bookease.demo',
    workingHours: { start: '08:30', end: '15:30' }
  },

  // --- CONSULTANTS ---
  {
    id: 'st_con_1',
    name: 'Marcus Vance',
    role: 'Principal Cloud Architect',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150',
    rating: 4.9,
    specialty: 'Google Cloud, Firebase, React Scale',
    services: ['srv_con_1', 'srv_con_3'],
    industry: 'consultant',
    email: 'marcus.v@bookease.demo',
    workingHours: { start: '10:00', end: '18:00' }
  },
  {
    id: 'st_con_2',
    name: 'David Kojo',
    role: 'Chartered Corporate CPA',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150',
    rating: 4.8,
    specialty: 'Startup Structuring & IRS and state compliance',
    services: ['srv_con_2'],
    industry: 'consultant',
    email: 'david.k@bookease.demo',
    workingHours: { start: '09:00', end: '17:00' }
  },

  // --- COACHES ---
  {
    id: 'st_ch_1',
    name: 'Coach Elena Rostova',
    role: 'C-Suite Performance Bio-Hacker',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150',
    rating: 4.9,
    specialty: 'Venture Capital Mindsets & Peak Performance',
    services: ['srv_ch_1', 'srv_ch_3'],
    industry: 'coach',
    email: 'elena.r@bookease.demo',
    workingHours: { start: '09:00', end: '17:00' }
  },
  {
    id: 'st_ch_2',
    name: 'Coach Tyler Smith',
    role: 'Career Design Strategist',
    avatar: 'https://images.unsplash.com/photo-1531427186611-ecfd6d936c79?w=150',
    rating: 4.6,
    specialty: 'FAANG Interview Placement & Negotiations',
    services: ['srv_ch_2', 'srv_ch_3'],
    industry: 'coach',
    email: 'tyler.s@bookease.demo',
    workingHours: { start: '10:00', end: '18:00' }
  }
];

// Seed initial custom bookings that range across May/June 2026 to make amazing charts!
export const SEED_BOOKINGS: Booking[] = [
  // Salon Bookings
  {
    id: 'b_sal_1',
    customerName: 'Jennifer Lopez',
    customerEmail: 'jennifer.lopez@example.com',
    customerPhone: '321-456-7890',
    customerNotes: 'Prefers mild styling cream and extra hot green tea.',
    serviceId: 'srv_salon_3',
    staffId: 'st_sal_1',
    date: '2026-06-09', // Today
    timeSlot: '10:00',
    status: 'confirmed',
    price: 180,
    createdAt: '2026-06-05T14:22:00Z',
    industry: 'salon'
  },
  {
    id: 'b_sal_2',
    customerName: 'Emma Watson',
    customerEmail: 'emma.watson@gmail.com',
    customerPhone: '555-019-3829',
    customerNotes: 'Need a short, tidy haircut. Running slightly late.',
    serviceId: 'srv_salon_1',
    staffId: 'st_sal_1',
    date: '2026-06-09', // Today
    timeSlot: '13:30',
    status: 'pending',
    price: 65,
    createdAt: '2026-06-08T09:00:00Z',
    industry: 'salon'
  },
  {
    id: 'b_sal_3',
    customerName: 'Chris Evans',
    customerEmail: 'cap.evans@marvel.com',
    customerPhone: '444-998-1111',
    customerNotes: 'Acupressure face skincare needed for a film prep.',
    serviceId: 'srv_salon_2',
    staffId: 'st_sal_2',
    date: '2026-06-09', // Today
    timeSlot: '15:00',
    status: 'confirmed',
    price: 85,
    createdAt: '2026-06-04T18:30:00Z',
    industry: 'salon'
  },
  {
    id: 'b_sal_4',
    customerName: 'Robert Downey Jr.',
    customerEmail: 'rdj@stark.com',
    customerPhone: '900-300-4000',
    customerNotes: 'Needs luxury gel manicure.',
    serviceId: 'srv_salon_4',
    staffId: 'st_sal_3',
    date: '2026-06-08', // Yesterday (Completed)
    timeSlot: '11:00',
    status: 'completed',
    price: 45,
    createdAt: '2026-06-04T12:00:00Z',
    industry: 'salon'
  },
  {
    id: 'b_sal_5',
    customerName: 'Taylor Swift',
    customerEmail: 'taylor.swift@reputation.ms',
    customerPhone: '198-900-2024',
    customerNotes: 'Balayage hair highlights before the tour restarts.',
    serviceId: 'srv_salon_3',
    staffId: 'st_sal_1',
    date: '2026-06-10', // Tomorrow
    timeSlot: '11:00',
    status: 'confirmed',
    price: 180,
    createdAt: '2026-06-06T15:00:00Z',
    industry: 'salon'
  },
  {
    id: 'b_sal_6',
    customerName: 'Selena Gomez',
    customerEmail: 'selena.g@rarebeauty.com',
    customerPhone: '222-333-4444',
    customerNotes: 'Manicure block. Cancelled due to conflict.',
    serviceId: 'srv_salon_4',
    staffId: 'st_sal_3',
    date: '2026-06-09', // Today
    timeSlot: '16:00',
    status: 'cancelled',
    price: 45,
    createdAt: '2026-06-07T10:00:00Z',
    industry: 'salon'
  },
  // Rich Historic Bookings for Analytics (past weeks/months)
  {
    id: 'b_sal_h1',
    customerName: 'Bill Gates',
    customerEmail: 'bill.g@gatesfoundation.org',
    customerPhone: '555-900-8888',
    serviceId: 'srv_salon_1',
    staffId: 'st_sal_1',
    date: '2026-06-01',
    timeSlot: '09:30',
    status: 'completed',
    price: 65,
    createdAt: '2026-05-28T10:00:00Z',
    industry: 'salon'
  },
  {
    id: 'b_sal_h2',
    customerName: 'Ada Lovelace',
    customerEmail: 'ada@computing.edu',
    customerPhone: '555-111-2222',
    serviceId: 'srv_salon_3',
    staffId: 'st_sal_1',
    date: '2026-06-02',
    timeSlot: '14:00',
    status: 'completed',
    price: 180,
    createdAt: '2026-05-29T11:00:00Z',
    industry: 'salon'
  },
  {
    id: 'b_sal_h3',
    customerName: 'Alan Turing',
    customerEmail: 'alan@bletchley.gov',
    customerPhone: '555-987-6543',
    serviceId: 'srv_salon_2',
    staffId: 'st_sal_2',
    date: '2026-06-03',
    timeSlot: '10:00',
    status: 'completed',
    price: 85,
    createdAt: '2026-05-30T15:00:00Z',
    industry: 'salon'
  },
  {
    id: 'b_sal_h4',
    customerName: 'Grace Hopper',
    customerEmail: 'grace.cobol@navy.mil',
    customerPhone: '111-222-3333',
    serviceId: 'srv_salon_4',
    staffId: 'st_sal_3',
    date: '2026-06-04',
    timeSlot: '11:30',
    status: 'completed',
    price: 45,
    createdAt: '2026-05-31T09:00:00Z',
    industry: 'salon'
  },
  {
    id: 'b_sal_h5',
    customerName: 'Marie Curie',
    customerEmail: 'marie@radium.univ',
    customerPhone: '555-888-9999',
    serviceId: 'srv_salon_2',
    staffId: 'st_sal_2',
    date: '2026-06-05',
    timeSlot: '16:00',
    status: 'completed',
    price: 85,
    createdAt: '2026-06-01T12:00:00Z',
    industry: 'salon'
  },
  {
    id: 'b_sal_h6',
    customerName: 'Albert Einstein',
    customerEmail: 'albert@relativity.edu',
    customerPhone: '456-123-7890',
    serviceId: 'srv_salon_1',
    staffId: 'st_sal_1',
    date: '2026-06-06',
    timeSlot: '10:00',
    status: 'completed',
    price: 65,
    createdAt: '2026-06-02T13:00:00Z',
    industry: 'salon'
  },

  // --- Doctor Bookings ---
  {
    id: 'b_doc_1',
    customerName: 'Lionel Messi',
    customerEmail: 'messi@leofutbol.com',
    customerPhone: '305-100-3000',
    customerNotes: 'Annual checkup for athletic registration.',
    serviceId: 'srv_doc_1',
    staffId: 'st_doc_1',
    date: '2026-06-09',
    timeSlot: '09:00',
    status: 'completed',
    price: 120,
    createdAt: '2026-06-01T10:00:00Z',
    industry: 'doctor'
  },
  {
    id: 'b_doc_2',
    customerName: 'Cristiano Ronaldo',
    customerEmail: 'cr7.siuu@real.com',
    customerPhone: '777-777-7777',
    customerNotes: 'Needs dynamic allergy and skin screen review.',
    serviceId: 'srv_doc_3',
    staffId: 'st_doc_2',
    date: '2026-06-09',
    timeSlot: '14:00',
    status: 'confirmed',
    price: 135,
    createdAt: '2026-06-05T08:00:00Z',
    industry: 'doctor'
  },

  // --- Fitness Bookings ---
  {
    id: 'b_fit_1',
    customerName: 'Dwayne Johnson',
    customerEmail: 'therock@sevenbucks.com',
    customerPhone: '900-500-1000',
    customerNotes: 'Needs 500lbs squat assessment.',
    serviceId: 'srv_fit_1',
    staffId: 'st_fit_1',
    date: '2026-06-09',
    timeSlot: '06:30',
    status: 'completed',
    price: 90,
    createdAt: '2026-06-02T14:00:00Z',
    industry: 'fitness'
  },
  {
    id: 'b_fit_2',
    customerName: 'Gisele Bündchen',
    customerEmail: 'gisele@runway.br',
    customerPhone: '555-321-4567',
    customerNotes: 'Mindfulness yoga focusing on diaphragmatic loops.',
    serviceId: 'srv_fit_2',
    staffId: 'st_fit_2',
    date: '2026-06-09',
    timeSlot: '09:30',
    status: 'confirmed',
    price: 60,
    createdAt: '2026-06-04T11:00:00Z',
    industry: 'fitness'
  },

  // --- Tutor Bookings ---
  {
    id: 'b_tut_1',
    customerName: 'Malala Yousafzai',
    customerEmail: 'malala@girlsedu.org',
    customerPhone: '111-555-6666',
    customerNotes: 'Preparing for SAT advanced exam topics.',
    serviceId: 'srv_tut_2',
    staffId: 'st_tut_1',
    date: '2026-06-09',
    timeSlot: '14:30',
    status: 'confirmed',
    price: 80,
    createdAt: '2026-06-06T12:00:00Z',
    industry: 'tutor'
  },

  // --- Consultant Bookings ---
  {
    id: 'b_con_1',
    customerName: 'Elon Musk',
    customerEmail: 'elon@spacex.com',
    customerPhone: '420-999-0000',
    customerNotes: 'Wants architectural audit of Mars transport cloud server systems.',
    serviceId: 'srv_con_1',
    staffId: 'st_con_1',
    date: '2026-06-09',
    timeSlot: '16:00',
    status: 'pending',
    price: 250,
    createdAt: '2026-06-05T09:00:00Z',
    industry: 'consultant'
  },

  // --- Coach Bookings ---
  {
    id: 'b_ch_1',
    customerName: 'Oprah Winfrey',
    customerEmail: 'oprah@own.com',
    customerPhone: '800-444-5555',
    customerNotes: 'Executive coaching for international foundation sync.',
    serviceId: 'srv_ch_1',
    staffId: 'st_ch_1',
    date: '2026-06-09',
    timeSlot: '11:00',
    status: 'confirmed',
    price: 150,
    createdAt: '2026-06-01T15:00:00Z',
    industry: 'coach'
  }
];

export const SEED_CUSTOMERS: Customer[] = [
  {
    id: 'c_1',
    name: 'Jennifer Lopez',
    email: 'jennifer.lopez@example.com',
    phone: '321-456-7890',
    notes: 'Prefers quiet sessions, herbal teas, and extra pillows.',
    totalBookings: 8,
    lifetimeSpent: 1440,
    lastBookingDate: '2026-06-09'
  },
  {
    id: 'c_2',
    name: 'Emma Watson',
    email: 'emma.watson@gmail.com',
    phone: '555-019-3829',
    notes: 'Always prompt. Loves book suggestions. Prefers morning appointments.',
    totalBookings: 12,
    lifetimeSpent: 780,
    lastBookingDate: '2026-06-09'
  },
  {
    id: 'c_3',
    name: 'Chris Evans',
    email: 'cap.evans@marvel.com',
    phone: '444-998-1111',
    notes: 'Very friendly. Interested in full package deals.',
    totalBookings: 5,
    lifetimeSpent: 425,
    lastBookingDate: '2026-06-09'
  },
  {
    id: 'c_4',
    name: 'Robert Downey Jr.',
    email: 'rdj@stark.com',
    phone: '900-300-4000',
    notes: 'Inquires about custom membership packages.',
    totalBookings: 22,
    lifetimeSpent: 1980,
    lastBookingDate: '2026-06-08'
  },
  {
    id: 'c_5',
    name: 'Taylor Swift',
    email: 'taylor.swift@reputation.ms',
    phone: '198-900-2024',
    notes: 'BookEase enthusiast. Requests early styling slots block.',
    totalBookings: 15,
    lifetimeSpent: 2700,
    lastBookingDate: '2026-06-10'
  },
  {
    id: 'c_6',
    name: 'Lionel Messi',
    email: 'messi@leofutbol.com',
    phone: '305-100-3000',
    notes: 'Extremely polite, usually schedules physical diagnostics directly.',
    totalBookings: 4,
    lifetimeSpent: 480,
    lastBookingDate: '2026-06-09'
  },
  {
    id: 'c_7',
    name: 'Cristiano Ronaldo',
    email: 'cr7.siuu@real.com',
    phone: '777-777-7777',
    notes: 'Dedicated, asks about customized wellness plans.',
    totalBookings: 3,
    lifetimeSpent: 405,
    lastBookingDate: '2026-06-09'
  },
  {
    id: 'c_8',
    name: 'Elon Musk',
    email: 'elon@spacex.com',
    phone: '420-999-0000',
    notes: 'Needs flexible rescheduling. Prefers evening calendars.',
    totalBookings: 2,
    lifetimeSpent: 500,
    lastBookingDate: '2026-06-09'
  }
];
