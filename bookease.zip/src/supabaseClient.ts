/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { Booking, Customer, EmailLog, IndustryType } from './types';
import { SERVICES, STAFF, SEED_BOOKINGS, SEED_CUSTOMERS } from './data';
import { db, handleFirestoreError, OperationType } from './firebase';
import { collection, doc, getDocs, setDoc, updateDoc, deleteDoc } from 'firebase/firestore';

// Read optional keys from Vite environment variables
const SUPABASE_URL = ((import.meta as any).env?.VITE_SUPABASE_URL || '').trim();
const SUPABASE_ANON_KEY = ((import.meta as any).env?.VITE_SUPABASE_ANON_KEY || '').trim();

let supabaseClient: SupabaseClient | null = null;
let isConfigured = false;

if (SUPABASE_URL && SUPABASE_ANON_KEY && SUPABASE_URL !== 'YOUR_SUPABASE_URL' && SUPABASE_ANON_KEY !== 'YOUR_SUPABASE_ANON_KEY') {
  try {
    supabaseClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
    isConfigured = true;
    console.log('BookEase: Supabase Client initialized successfully.');
  } catch (error) {
    console.error('BookEase: Failed to initialize Supabase client:', error);
  }
}

// Global state callback registry for mock Realtime updates
type UpdateCallback = () => void;
const listeners = new Set<UpdateCallback>();

function emitUpdate() {
  listeners.forEach((listener) => {
    try {
      listener();
    } catch (e) {
      console.error(e);
    }
  });
}

// In-Memory & LocalStorage backup store
class BookEaseStoreLocal {
  private bookings: Booking[] = [];
  private customers: Customer[] = [];
  private emailLogs: EmailLog[] = [];
  private isSyncingWithFirebase = false;

  constructor() {
    this.loadFromStorage();
    this.syncFromFirebase();
  }

  public async syncFromFirebase() {
    if (this.isSyncingWithFirebase) return;
    this.isSyncingWithFirebase = true;
    console.log('BookEase: Starting sync with Firebase Firestore...');

    try {
      // 1. Fetch bookings
      const bookingsCol = collection(db, 'bookings');
      const bookingsSnapshot = await getDocs(bookingsCol);
      
      let fbBookings: Booking[] = [];
      bookingsSnapshot.forEach((doc) => {
        fbBookings.push({ id: doc.id, ...doc.data() } as Booking);
      });

      // 2. Fetch customers
      const customersCol = collection(db, 'customers');
      const customersSnapshot = await getDocs(customersCol);
      
      let fbCustomers: Customer[] = [];
      customersSnapshot.forEach((doc) => {
        fbCustomers.push({ id: doc.id, ...doc.data() } as Customer);
      });

      // 3. Fetch email logs
      const emailLogsCol = collection(db, 'emailLogs');
      const emailLogsSnapshot = await getDocs(emailLogsCol);
      
      let fbEmailLogs: EmailLog[] = [];
      emailLogsSnapshot.forEach((doc) => {
        fbEmailLogs.push({ id: doc.id, ...doc.data() } as EmailLog);
      });

      // If Firebase Firestore has data, overwrite local state
      if (fbBookings.length > 0) {
        this.bookings = fbBookings;
        this.saveBookingsToStorage();
      } else {
        // If Firestore is empty, we seed Firestore with our generated local records!
        console.log('BookEase: Firestore database is empty. Seeding with local startup records...');
        for (const b of this.bookings) {
          await setDoc(doc(db, 'bookings', b.id), {
            customerName: b.customerName,
            customerEmail: b.customerEmail,
            customerPhone: b.customerPhone,
            customerNotes: b.customerNotes || '',
            serviceId: b.serviceId,
            staffId: b.staffId,
            date: b.date,
            timeSlot: b.timeSlot,
            status: b.status,
            price: Number(b.price),
            createdAt: b.createdAt,
            industry: b.industry,
            ...(b.customDuration ? { customDuration: b.customDuration } : {})
          });
        }
      }

      if (fbCustomers.length > 0) {
        this.customers = fbCustomers;
        this.saveCustomersToStorage();
      } else {
        for (const c of this.customers) {
          await setDoc(doc(db, 'customers', c.id), {
            name: c.name,
            email: c.email,
            phone: c.phone,
            notes: c.notes || '',
            totalBookings: Number(c.totalBookings || 0),
            lifetimeSpent: Number(c.lifetimeSpent || 0),
            ...(c.lastBookingDate ? { lastBookingDate: c.lastBookingDate } : {})
          });
        }
      }

      if (fbEmailLogs.length > 0) {
        this.emailLogs = fbEmailLogs;
        this.saveEmailLogsToStorage();
      } else {
        for (const l of this.emailLogs) {
          await setDoc(doc(db, 'emailLogs', l.id), {
            recipientEmail: l.recipientEmail,
            type: l.type,
            subject: l.subject,
            body: l.body,
            sentAt: l.sentAt,
            ...(l.bookingId ? { bookingId: l.bookingId } : {})
          });
        }
      }

      console.log('BookEase: Firebase synchronization of all records succeeded.');
      emitUpdate();
    } catch (err) {
      console.error('BookEase: Error syncing with Firebase:', err);
    } finally {
      this.isSyncingWithFirebase = false;
    }
  }

  private loadFromStorage() {
    try {
      const storedBookings = localStorage.getItem('bookease_bookings');
      const storedCustomers = localStorage.getItem('bookease_customers');
      const storedEmailLogs = localStorage.getItem('bookease_emaillogs');

      if (storedBookings && JSON.parse(storedBookings).length >= 50) {
        this.bookings = JSON.parse(storedBookings);
      } else {
        this.bookings = this.generate50PlusBookings();
        this.saveBookingsToStorage();
      }

      if (storedCustomers && JSON.parse(storedCustomers).length >= 10) {
        this.customers = JSON.parse(storedCustomers);
      } else {
        this.customers = this.generateCustomersFromBookings();
        this.saveCustomersToStorage();
      }

      if (storedEmailLogs) {
        this.emailLogs = JSON.parse(storedEmailLogs);
      } else {
        this.emailLogs = [];
      }
    } catch (err) {
      console.error('BookEase: Failed to load local storage, using fresh records.', err);
      this.bookings = [...SEED_BOOKINGS];
      this.customers = [...SEED_CUSTOMERS];
      this.emailLogs = [];
    }
  }

  private generate50PlusBookings(): Booking[] {
    const list: Booking[] = [...SEED_BOOKINGS];
    const firstNames = ['James', 'Emma', 'Liam', 'Olivia', 'Noah', 'Ava', 'Oliver', 'Sophia', 'Elijah', 'Isabella', 'William', 'Mia', 'Benjamin', 'Charlotte', 'Lucas', 'Amelia', 'Michael', 'Emily', 'Alexander', 'Elizabeth'];
    const lastNames = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez', 'Hernandez', 'Lopez', 'Gonzalez', 'Wilson', 'Anderson', 'Thomas', 'Taylor', 'Moore', 'Jackson'];
    const services = SERVICES;
    const staff = STAFF;
    const notesList = [
      'Prefers herbal tea.', 'First-time customer.', 'Requested quiet room.',
      'Needs confirmation call.', 'Recommended by Gisele.', 'Wants additional styling tips.',
      'Will arrive 5 mins early.', 'Has custom workout patterns.', 'Strictest privacy requested.',
      'Prefers evening appointments.', 'Needs accessible seating.', 'Always prompt.'
    ];
    
    // Generate dates from May 15 to June 15, 2026
    const baseDate = new Date('2026-05-15');
    
    // Generate about 55 more bookings to easily exceed the 50+ bookings threshold
    for (let i = 0; i < 55; i++) {
      const randomDate = new Date(baseDate);
      randomDate.setDate(baseDate.getDate() + Math.floor(Math.random() * 30));
      const year = randomDate.getFullYear();
      const month = String(randomDate.getMonth() + 1).padStart(2, '0');
      const day = String(randomDate.getDate()).padStart(2, '0');
      const dateString = `${year}-${month}-${day}`;
      
      const randomSrv = services[Math.floor(Math.random() * services.length)];
      const randomStaff = staff.filter(st => st.industry === randomSrv.industry)[0] || staff[0];
      const hours = ['09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00'];
      const randomTime = hours[Math.floor(Math.random() * hours.length)];
      
      const fName = firstNames[Math.floor(Math.random() * firstNames.length)];
      const lName = lastNames[Math.floor(Math.random() * lastNames.length)];
      const name = `${fName} ${lName}`;
      const email = `${fName.toLowerCase()}.${lName.toLowerCase()}${Math.floor(Math.random() * 99)}@gmail.com`;
      const phone = `${100 + Math.floor(Math.random()*899)}-${100 + Math.floor(Math.random()*899)}-${1000 + Math.floor(Math.random()*8999)}`;
      
      const isPast = dateString < '2026-06-09';
      const status: Booking['status'] = isPast ? 'completed' : (Math.random() > 0.15 ? 'confirmed' : 'pending');
      
      list.push({
        id: `b_seeded_${100 + i}`,
        customerName: name,
        customerEmail: email,
        customerPhone: phone,
        customerNotes: notesList[Math.floor(Math.random() * notesList.length)],
        serviceId: randomSrv.id,
        staffId: randomStaff.id,
        date: dateString,
        timeSlot: randomTime,
        status: status,
        price: randomSrv.price,
        createdAt: new Date(randomDate.getTime() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        industry: randomSrv.industry
      });
    }
    
    return list;
  }

  private generateCustomersFromBookings(): Customer[] {
    const custMap = new Map<string, Customer>();
    
    // Add default template ones first to preserve details
    SEED_CUSTOMERS.forEach(sc => {
      custMap.set(sc.email.toLowerCase(), { ...sc });
    });
    
    // Scan bookings to capture generated ones
    this.bookings.forEach(b => {
      const emailKey = b.customerEmail.toLowerCase();
      if (custMap.has(emailKey)) {
        const c = custMap.get(emailKey)!;
        if (b.status !== 'cancelled') {
          c.totalBookings += 1;
          c.lifetimeSpent += b.price;
          if (!c.lastBookingDate || b.date > c.lastBookingDate) {
            c.lastBookingDate = b.date;
          }
        }
      } else {
        custMap.set(emailKey, {
          id: `c_gen_${Math.floor(Math.random() * 100000)}`,
          name: b.customerName,
          email: b.customerEmail,
          phone: b.customerPhone,
          notes: b.customerNotes || 'Regular client',
          totalBookings: b.status !== 'cancelled' ? 1 : 0,
          lifetimeSpent: b.status !== 'cancelled' ? b.price : 0,
          lastBookingDate: b.date
        });
      }
    });
    
    return Array.from(custMap.values());
  }

  private saveBookingsToStorage() {
    localStorage.setItem('bookease_bookings', JSON.stringify(this.bookings));
  }

  private saveCustomersToStorage() {
    localStorage.setItem('bookease_customers', JSON.stringify(this.customers));
  }

  private saveEmailLogsToStorage() {
    localStorage.setItem('bookease_emaillogs', JSON.stringify(this.emailLogs));
  }

  public getBookings(industry?: IndustryType): Booking[] {
    if (industry) {
      return this.bookings.filter((b) => b.industry === industry);
    }
    return this.bookings;
  }

  public getCustomers(): Customer[] {
    return this.customers;
  }

  public getEmailLogs(): EmailLog[] {
    return this.emailLogs;
  }

  public async createBooking(bookingData: Omit<Booking, 'id' | 'createdAt'>): Promise<Booking> {
    const newBooking: Booking = {
      ...bookingData,
      id: `b_local_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      createdAt: new Date().toISOString()
    };
    this.bookings.unshift(newBooking);
    this.saveBookingsToStorage();

    // Async sync with Firestore with strict error boundaries
    try {
      await setDoc(doc(db, 'bookings', newBooking.id), {
        customerName: newBooking.customerName,
        customerEmail: newBooking.customerEmail,
        customerPhone: newBooking.customerPhone,
        customerNotes: newBooking.customerNotes || '',
        serviceId: newBooking.serviceId,
        staffId: newBooking.staffId,
        date: newBooking.date,
        timeSlot: newBooking.timeSlot,
        status: newBooking.status,
        price: Number(newBooking.price),
        createdAt: newBooking.createdAt,
        industry: newBooking.industry,
        ...(newBooking.customDuration ? { customDuration: newBooking.customDuration } : {})
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `bookings/${newBooking.id}`);
    }

    // Side-effects: sync customer metrics & simulate sending emails
    await this.updateOrCreateCustomer(newBooking);
    await this.triggerEmailSimulations(newBooking, 'confirmation');

    emitUpdate();
    return newBooking;
  }

  public async updateBookingStatus(id: string, status: Booking['status']): Promise<Booking | null> {
    const bookingIndex = this.bookings.findIndex((b) => b.id === id);
    if (bookingIndex === -1) return null;

    const oldStatus = this.bookings[bookingIndex].status;
    this.bookings[bookingIndex].status = status;
    this.saveBookingsToStorage();

    const booking = this.bookings[bookingIndex];

    // Trigger emails accordingly
    if (status === 'cancelled') {
      await this.triggerEmailSimulations(booking, 'cancellation');
    }

    // Refresh Customer Lifetime Value on updates
    await this.recalculateCustomerMetrics(booking.customerEmail);

    // Sync to Firebase
    try {
      await updateDoc(doc(db, 'bookings', id), {
        status: status
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `bookings/${id}`);
    }

    emitUpdate();
    return booking;
  }

  public async updateBookingTime(id: string, date: string, timeSlot: string): Promise<Booking | null> {
    const bookingIndex = this.bookings.findIndex((b) => b.id === id);
    if (bookingIndex === -1) return null;

    this.bookings[bookingIndex].date = date;
    this.bookings[bookingIndex].timeSlot = timeSlot;
    this.saveBookingsToStorage();

    const booking = this.bookings[bookingIndex];
    await this.triggerEmailSimulations(booking, 'confirmation'); // Rescheduled notification

    // Sync to Firebase
    try {
      await updateDoc(doc(db, 'bookings', id), {
        date: date,
        timeSlot: timeSlot
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `bookings/${id}`);
    }

    emitUpdate();
    return booking;
  }

  public async deleteBooking(id: string): Promise<boolean> {
    const originalLength = this.bookings.length;
    const booking = this.bookings.find((b) => b.id === id);
    this.bookings = this.bookings.filter((b) => b.id !== id);
    this.saveBookingsToStorage();

    if (booking) {
      await this.recalculateCustomerMetrics(booking.customerEmail);
    }

    // Sync to Firebase
    try {
      await deleteDoc(doc(db, 'bookings', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `bookings/${id}`);
    }

    emitUpdate();
    return originalLength !== this.bookings.length;
  }

  public async updateCustomerNotes(id: string, notes: string): Promise<Customer | null> {
    const target = this.customers.find((c) => c.id === id);
    if (!target) return null;
    target.notes = notes;
    this.saveCustomersToStorage();

    // Sync to Firebase
    try {
      await updateDoc(doc(db, 'customers', id), {
        notes: notes
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `customers/${id}`);
    }

    emitUpdate();
    return target;
  }

  private async updateOrCreateCustomer(booking: Booking) {
    const existingIndex = this.customers.findIndex(
      (c) => c.email.toLowerCase() === booking.customerEmail.toLowerCase()
    );

    let customerDoc: Customer;

    if (existingIndex !== -1) {
      const cust = this.customers[existingIndex];
      cust.phone = booking.customerPhone || cust.phone;
      cust.name = booking.customerName || cust.name;
      cust.totalBookings += 1;
      cust.lifetimeSpent += booking.price;
      cust.lastBookingDate = booking.date;
      customerDoc = cust;
    } else {
      const newCustomer: Customer = {
        id: `c_local_${Date.now()}`,
        name: booking.customerName,
        email: booking.customerEmail,
        phone: booking.customerPhone,
        notes: booking.customerNotes || '',
        totalBookings: 1,
        lifetimeSpent: booking.price,
        lastBookingDate: booking.date
      };
      this.customers.push(newCustomer);
      customerDoc = newCustomer;
    }
    this.saveCustomersToStorage();

    // Sync to Firebase
    try {
      await setDoc(doc(db, 'customers', customerDoc.id), {
        name: customerDoc.name,
        email: customerDoc.email,
        phone: customerDoc.phone,
        notes: customerDoc.notes || '',
        totalBookings: Number(customerDoc.totalBookings),
        lifetimeSpent: Number(customerDoc.lifetimeSpent),
        ...(customerDoc.lastBookingDate ? { lastBookingDate: customerDoc.lastBookingDate } : {})
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `customers/${customerDoc.id}`);
    }
  }

  private async recalculateCustomerMetrics(email: string) {
    const customer = this.customers.find((c) => c.email.toLowerCase() === email.toLowerCase());
    if (!customer) return;

    const customerBookings = this.bookings.filter(
      (b) => b.customerEmail.toLowerCase() === email.toLowerCase() && b.status !== 'cancelled'
    );

    customer.totalBookings = customerBookings.length;
    customer.lifetimeSpent = customerBookings.reduce((sum, b) => sum + b.price, 0);

    const sorted = [...customerBookings].sort(
      (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
    );
    customer.lastBookingDate = sorted[0]?.date || undefined;

    this.saveCustomersToStorage();

    // Sync to Firebase
    try {
      await updateDoc(doc(db, 'customers', customer.id), {
        totalBookings: Number(customer.totalBookings),
        lifetimeSpent: Number(customer.lifetimeSpent),
        lastBookingDate: customer.lastBookingDate || null
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `customers/${customer.id}`);
    }
  }

  private async triggerEmailSimulations(booking: Booking, type: 'confirmation' | 'reminder' | 'cancellation') {
    const service = SERVICES.find((s) => s.id === booking.serviceId);
    const staff = STAFF.find((st) => st.id === booking.staffId);
    const serviceName = service ? service.name : 'Booking';
    const staffName = staff ? staff.name : 'Associate';

    let subject = '';
    let body = '';

    if (type === 'confirmation') {
      subject = `Appointment Confirmed! BookEase: ${serviceName}`;
      body = `Hello ${booking.customerName},\n\nYour appointment for ${serviceName} with ${staffName} is confirmed!\n\nDetails:\nDate: ${booking.date}\nTimeSlot: ${booking.timeSlot}\nDuration: ${service ? service.duration : 45} mins\nPrice: $${booking.price}\n\nThank you for choosing BookEase. We look forward to serving you!`;
    } else if (type === 'reminder') {
      subject = `Reminder: Your appointment with BookEase is tomorrow!`;
      body = `Hello ${booking.customerName},\n\nThis is a quick friendly reminder that your session for ${serviceName} is scheduled for tomorrow (${booking.date}) at ${booking.timeSlot} with ${staffName}.\n\nIf you need to reschedule, please access your profile or call your service provider.\n\nSee you soon!`;
    } else if (type === 'cancellation') {
      subject = `Canceled: Appointment for ${serviceName}`;
      body = `Hello ${booking.customerName},\n\nYour appointment for ${serviceName} with ${staffName} on ${booking.date} at ${booking.timeSlot} has been canceled.\n\nIf this was a mistake, or if you wish to choose another service slot, head over to our booking page.\n\nThank you,\nThe BookEase Team`;
    }

    const newLog: EmailLog = {
      id: `email_${Date.now()}_${Math.floor(Math.random() * 100)}`,
      bookingId: booking.id,
      recipientEmail: booking.customerEmail,
      type,
      subject,
      body,
      sentAt: new Date().toISOString()
    };

    this.emailLogs.unshift(newLog);
    this.saveEmailLogsToStorage();

    // Sync to Firebase
    try {
      await setDoc(doc(db, 'emailLogs', newLog.id), {
        recipientEmail: newLog.recipientEmail,
        type: newLog.type,
        subject: newLog.subject,
        body: newLog.body,
        sentAt: newLog.sentAt,
        ...(newLog.bookingId ? { bookingId: newLog.bookingId } : {})
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `emailLogs/${newLog.id}`);
    }
  }

  public async triggerReminderEmail(booking: Booking): Promise<void> {
    await this.triggerEmailSimulations(booking, 'reminder');
    emitUpdate();
  }

  // Clear all changes and re-seed to defaults
  public async clearAndReSeed() {
    localStorage.removeItem('bookease_bookings');
    localStorage.removeItem('bookease_customers');
    localStorage.removeItem('bookease_emaillogs');
    this.loadFromStorage();

    // Wipe Firestore collections by deleting current documents
    try {
      const bookingsCol = collection(db, 'bookings');
      const bookingsSnapshot = await getDocs(bookingsCol);
      for (const d of bookingsSnapshot.docs) {
        await deleteDoc(doc(db, 'bookings', d.id));
      }

      const customersCol = collection(db, 'customers');
      const customersSnapshot = await getDocs(customersCol);
      for (const d of customersSnapshot.docs) {
        await deleteDoc(doc(db, 'customers', d.id));
      }

      const emailLogsCol = collection(db, 'emailLogs');
      const emailLogsSnapshot = await getDocs(emailLogsCol);
      for (const d of emailLogsSnapshot.docs) {
        await deleteDoc(doc(db, 'emailLogs', d.id));
      }
    } catch (e) {
      console.warn('BookEase: Failed to clear some cloud documents:', e);
    }

    // Re-sync after clearing and creating fresh seeds
    await this.syncFromFirebase();
    emitUpdate();
  }
}

export const bookEaseStore = new BookEaseStoreLocal();

// Listen hook helper
export function registerListener(callback: UpdateCallback) {
  listeners.add(callback);
  return () => {
    listeners.delete(callback);
  };
}

export function getSupabaseDetails() {
  return {
    url: SUPABASE_URL,
    isConfigured,
    client: supabaseClient
  };
}

export const SQL_SEED_BLUEPRINT = `-- SQL Blueprint for BookEase Supabase Backend
-- Create modern schema with real-time replication supported.

-- 1. Create Profiles/Admin Table
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID REFERENCES auth.users ON DELETE CASCADE PRIMARY KEY,
  full_name TEXT,
  phone_number TEXT,
  industry TEXT DEFAULT 'salon',
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Create Bookings Table
CREATE TABLE IF NOT EXISTS public.bookings (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  customer_name TEXT NOT NULL,
  customer_email TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  customer_notes TEXT,
  service_id TEXT NOT NULL,
  staff_id TEXT NOT NULL,
  date DATE NOT NULL,
  time_slot TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'confirmed', -- pending, confirmed, completed, cancelled
  price DECIMAL(10,2) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  industry TEXT NOT NULL
);

-- 3. Create Customers Table
CREATE TABLE IF NOT EXISTS public.customers (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  phone TEXT NOT NULL,
  notes TEXT,
  total_bookings INTEGER DEFAULT 0,
  lifetime_spent DECIMAL(10,2) DEFAULT 0.00,
  last_booking_date DATE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. Email Logs Table
CREATE TABLE IF NOT EXISTS public.email_logs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  booking_id UUID,
  recipient_email TEXT NOT NULL,
  type TEXT NOT NULL, -- confirmation, reminder, cancellation
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  sent_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Realtime Replication:
ALTER PUBLICATION supabase_realtime ADD TABLE public.bookings;
ALTER PUBLICATION supabase_realtime ADD TABLE public.customers;
ALTER PUBLICATION supabase_realtime ADD TABLE public.email_logs;

-- Set up Row Level Security (RLS) Rules:
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.email_logs ENABLE ROW LEVEL SECURITY;

-- Allow public access for bookings insertions (for customer booking page)
CREATE POLICY "Allow public booking creation" ON public.bookings 
  FOR INSERT WITH CHECK (true);

-- Allow admins to read/write all rows
CREATE POLICY "Admins full access on Bookings" ON public.bookings
  FOR ALL TO authenticated USING (true);

CREATE POLICY "Admins full access on Customers" ON public.customers
  FOR ALL TO authenticated USING (true);

CREATE POLICY "Admins full access on Email Logs" ON public.email_logs
  FOR ALL TO authenticated USING (true);
`;
