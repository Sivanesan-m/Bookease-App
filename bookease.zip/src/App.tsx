/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import PublicBooking from './components/PublicBooking';
import AdminPanel from './components/AdminPanel';
import LandingPage from './components/LandingPage';
import AuthUI from './components/AuthUI';
import AIAssistantChat from './components/AIAssistantChat';
import { IndustryType } from './types';
import { 
  CalendarCheck2, LayoutDashboard, Sparkles, Building2, UserSearch, 
  Home, Lock, Sun, Moon, LogOut, CheckCircle2 
} from 'lucide-react';

export default function App() {
  const [currentView, setCurrentView] = useState<'landing' | 'booking' | 'admin' | 'auth'>('landing');
  const [activeIndustry, setActiveIndustry] = useState<IndustryType>('salon');
  
  // Dark/Light Mode toggle persistent in LocalStorage
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('bookease_darkmode');
    return saved ? saved === 'true' : true; // Default to eye-care dark theme!
  });

  // Admin authentication state
  const [adminEmail, setAdminEmail] = useState<string | null>(() => {
    return localStorage.getItem('bookease_admin_email') || null;
  });

  useEffect(() => {
    localStorage.setItem('bookease_darkmode', String(isDarkMode));
    if (isDarkMode) {
      document.body.classList.add('dark');
    } else {
      document.body.classList.remove('dark');
    }
  }, [isDarkMode]);

  const handleAdminSuccess = (email: string) => {
    setAdminEmail(email);
    localStorage.setItem('bookease_admin_email', email);
    setCurrentView('admin');
  };

  const handleLogout = () => {
    setAdminEmail(null);
    localStorage.removeItem('bookease_admin_email');
    setCurrentView('landing');
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 antialiased font-sans selection:bg-indigo-500 selection:text-white ${
      isDarkMode 
        ? 'bg-slate-950 text-slate-100 dark' 
        : 'bg-slate-50 text-slate-800'
    }`}>
      
      {/* 1. DYNAMIC SYSTEM CONTROL HEADER */}
      <div className={`sticky top-0 z-50 border-b backdrop-blur-xl transition duration-300 ${
        isDarkMode 
          ? 'bg-slate-950/80 border-slate-900 shadow-slate-950/45 shadow-lg' 
          : 'bg-white/95 border-slate-200/80 shadow-slate-100 shadow-md'
      }`}>
        <div className="max-w-7xl mx-auto px-4 py-3 sm:py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          
          {/* Logo Branding */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setCurrentView('landing')}>
            <div className="bg-indigo-600 text-white p-2 rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-600/10">
              <CalendarCheck2 className="w-5 h-5 text-indigo-100" />
            </div>
            <div>
              <span className="text-[9px] text-indigo-500 font-extrabold block uppercase tracking-widest leading-none">Enterprise</span>
              <h1 className={`text-lg font-black tracking-tight ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>BookEase</h1>
            </div>
          </div>

          {/* Central Platform View Switcher */}
          <div className={`flex items-center gap-1 p-1 rounded-2xl ${
            isDarkMode ? 'bg-slate-900 border border-slate-800' : 'bg-slate-100 border border-slate-200'
          }`}>
            <button
              id="btn_switch_view_landing"
              onClick={() => setCurrentView('landing')}
              className={`flex items-center gap-1.5 text-[11px] font-black px-3.5 py-2 rounded-xl transition-all cursor-pointer ${
                currentView === 'landing'
                  ? isDarkMode ? 'bg-indigo-600 text-white' : 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-400 hover:text-slate-350'
              }`}
            >
              <Home className="w-3.5 h-3.5" /> Landing
            </button>
            <button
              id="btn_switch_view_booking"
              onClick={() => setCurrentView('booking')}
              className={`flex items-center gap-1.5 text-[11px] font-black px-3.5 py-2 rounded-xl transition-all cursor-pointer ${
                currentView === 'booking'
                  ? isDarkMode ? 'bg-indigo-600 text-white' : 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-400 hover:text-slate-350'
              }`}
            >
              <UserSearch className="w-3.5 h-3.5" /> Booking
            </button>
            <button
              id="btn_switch_view_admin"
              onClick={() => {
                if (adminEmail) {
                  setCurrentView('admin');
                } else {
                  setCurrentView('auth');
                }
              }}
              className={`flex items-center gap-1.5 text-[11px] font-black px-3.5 py-2 rounded-xl transition-all cursor-pointer ${
                currentView === 'admin' || currentView === 'auth'
                  ? isDarkMode ? 'bg-indigo-600 text-white' : 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-400 hover:text-slate-350'
              }`}
            >
              <LayoutDashboard className="w-3.5 h-3.5" /> Admin Panel {adminEmail && '✓'}
            </button>
          </div>

          {/* Right Accessories Area */}
          <div className="flex items-center gap-3">
            {/* Dark Mode toggle switcher */}
            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className={`p-2.5 rounded-xl border transition cursor-pointer ${
                isDarkMode 
                  ? 'bg-slate-900 border-slate-800 text-amber-400 hover:bg-slate-800' 
                  : 'bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200'
              }`}
              title="Toggle Contrast Mode"
            >
              {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* Authenticated user status bar */}
            {adminEmail ? (
              <div className="flex items-center gap-2">
                <div className="hidden md:block max-w-32 truncate text-right">
                  <span className="text-[9px] uppercase font-bold text-slate-400 block tracking-wider">Authorized Console</span>
                  <span className="text-[10px] text-indigo-400 font-extrabold">{adminEmail}</span>
                </div>
                <button
                  onClick={handleLogout}
                  className={`p-2.5 rounded-xl border transition cursor-pointer ${
                    isDarkMode 
                      ? 'bg-slate-900 hover:bg-slate-800 border-slate-800 text-rose-400' 
                      : 'bg-slate-100 hover:bg-slate-200 border-slate-200 text-rose-600'
                  }`}
                  title="Sign Out Workspace"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => setCurrentView('auth')}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-extrabold rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow shadow-indigo-600/10"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Lock Gate</span>
              </button>
            )}
          </div>

        </div>
      </div>

      {/* 2. DYNAMIC APP VIEW STAGE */}
      <main className="w-full">
        {currentView === 'landing' && (
          <div className="relative py-12">
            <LandingPage
              isDarkMode={isDarkMode}
              onStartBooking={() => setCurrentView('booking')}
              onGoToAdmin={() => {
                if (adminEmail) setCurrentView('admin');
                else setCurrentView('auth');
              }}
            />
          </div>
        )}

        {currentView === 'booking' && (
          <div className={`py-12 ${isDarkMode ? 'bg-slate-950' : 'bg-slate-100/50'}`}>
            <PublicBooking 
              currentIndustry={activeIndustry} 
              onIndustryChange={setActiveIndustry}
              onNavigateToDashboard={() => {
                if (adminEmail) setCurrentView('admin');
                else setCurrentView('auth');
              }}
              isDarkMode={isDarkMode}
            />
          </div>
        )}

        {currentView === 'auth' && (
          <div className={`py-16 flex items-center justify-center ${isDarkMode ? 'bg-slate-950' : 'bg-slate-100/30'}`}>
            <AuthUI
              onSuccess={handleAdminSuccess}
              onCancel={() => setCurrentView('landing')}
              isDarkMode={isDarkMode}
            />
          </div>
        )}

        {currentView === 'admin' && (
          <div className="w-full">
            <AdminPanel 
              currentIndustry={activeIndustry}
              onIndustryChange={setActiveIndustry}
              onNavigateToBooking={() => setCurrentView('booking')} 
            />
          </div>
        )}
      </main>

      {/* 3. SIMPLIFIED Humble human footer */}
      <footer className={`py-10 border-t text-center text-xs transition duration-300 ${
        isDarkMode ? 'bg-slate-950 border-slate-900 text-slate-500' : 'bg-white border-slate-200 text-slate-400'
      }`}>
        <p className="font-semibold select-none">&copy; 2026 BookEase SaaS Platform. Inspired by commercial client requirements.</p>
        <div className="flex justify-center gap-4 mt-2 font-medium">
          <a href="#booking" onClick={(e) => { e.preventDefault(); setCurrentView('booking'); }} className="hover:text-indigo-500 transition">Scheduler</a>
          <span>&middot;</span>
          <a href="#admin" onClick={(e) => { e.preventDefault(); if (adminEmail) setCurrentView('admin'); else setCurrentView('auth'); }} className="hover:text-indigo-500 transition">Admin Dashboard</a>
          <span>&middot;</span>
          <a href="mailto:it055m.sivanesan@gmail.com" className="hover:text-indigo-500 transition">Developer Connect</a>
        </div>
      </footer>

      {/* Floating Interactive AI Assistant Chatbot */}
      <AIAssistantChat isDarkMode={isDarkMode} />

    </div>
  );
}
