/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Service, StaffMember, IndustryType } from '../types';
import { SERVICES, STAFF, INDUSTRIES } from '../data';

export interface ParseResult {
  industry: IndustryType;
  service: Service;
  staff: StaffMember;
  dateStr: string;
  timeSlot: string;
  explanation: string;
}

export function parseAISchedulingRequest(prompt: string): ParseResult | null {
  const lowercase = prompt.toLowerCase();
  
  // 1. Detect industry or service
  let detectedIndustry: IndustryType = 'salon';
  let matchedService: Service | null = null;
  
  // Score industries
  const scores: Record<IndustryType, number> = {
    salon: 0,
    fitness: 0,
    tutor: 0,
    doctor: 0,
    consultant: 0,
    coach: 0
  };

  if (lowercase.includes('hair') || lowercase.includes('cut') || lowercase.includes('style') || lowercase.includes('salon') || lowercase.includes('facial') || lowercase.includes('manicure') || lowercase.includes('balayage')) {
    scores.salon += 10;
  }
  if (lowercase.includes('fitness') || lowercase.includes('gym') || lowercase.includes('workout') || lowercase.includes('train') || lowercase.includes('yoga') || lowercase.includes('vinyasa') || lowercase.includes('hiit') || lowercase.includes('squat')) {
    scores.fitness += 10;
  }
  if (lowercase.includes('tutor') || lowercase.includes('math') || lowercase.includes('chem') || lowercase.includes('sat') || lowercase.includes('calculus') || lowercase.includes('academic')) {
    scores.tutor += 10;
  }
  if (lowercase.includes('doctor') || lowercase.includes('clinic') || lowercase.includes('medical') || lowercase.includes('physician') || lowercase.includes('skin') || lowercase.includes('dermatology') || lowercase.includes('pediatric')) {
    scores.doctor += 10;
  }
  if (lowercase.includes('consultant') || lowercase.includes('saas') || lowercase.includes('tax') || lowercase.includes('architecture') || lowercase.includes('cloud') || lowercase.includes('cto') || lowercase.includes('finance')) {
    scores.consultant += 10;
  }
  if (lowercase.includes('coach') || lowercase.includes('life') || lowercase.includes('transition') || lowercase.includes('mindset') || lowercase.includes('leadership')) {
    scores.coach += 10;
  }

  // Find highest scoring industry
  let maxScore = -1;
  Object.entries(scores).forEach(([ind, s]) => {
    if (s > maxScore) {
      maxScore = s;
      detectedIndustry = ind as IndustryType;
    }
  });

  // Find optimal service based on keyword matching
  const matchingServices = SERVICES.filter(s => s.industry === detectedIndustry);
  let bestServiceScore = -1;
  matchedService = matchingServices[0]; // fallback

  matchingServices.forEach(s => {
    let score = 0;
    const words = s.name.toLowerCase().split(' ');
    words.forEach(w => {
      if (w.length > 3 && lowercase.includes(w)) {
        score += 5;
      }
    });
    if (score > bestServiceScore) {
      bestServiceScore = score;
      matchedService = s;
    }
  });

  // 2. Detect staff member
  const eligibleStaff = STAFF.filter(st => st.industry === detectedIndustry);
  let matchedStaff: StaffMember = eligibleStaff[0]; // default fallback
  
  eligibleStaff.forEach(st => {
    const names = st.name.toLowerCase().split(' ');
    names.forEach(namePart => {
      if (namePart.length > 2 && lowercase.includes(namePart)) {
        matchedStaff = st;
      }
    });
  });

  // 3. Detect date
  // Base date is Tuesday, June 9, 2026.
  let targetDate = new Date('2026-06-09');
  let dateExplanation = "Today, Jun 9";

  if (lowercase.includes('tomorrow') || lowercase.includes('next day')) {
    targetDate.setDate(targetDate.getDate() + 1);
    dateExplanation = "Tomorrow, Jun 10";
  } else if (lowercase.includes('day after') || lowercase.includes('in 2 days')) {
    targetDate.setDate(targetDate.getDate() + 2);
    dateExplanation = "Thursday, Jun 11";
  } else if (lowercase.includes('monday')) {
    // find next monday: day 1. Current day is 9 (Tuesday, day 2). Next Monday is in 6 days (Jun 15).
    targetDate.setDate(targetDate.getDate() + 6);
    dateExplanation = "Next Monday, Jun 15";
  } else if (lowercase.includes('tuesday')) {
    targetDate.setDate(targetDate.getDate() + 7);
    dateExplanation = "Next Tuesday, Jun 16";
  } else if (lowercase.includes('wednesday')) {
    targetDate.setDate(targetDate.getDate() + 1); // June 10 is tomorrow (Wednesday)
    dateExplanation = "Tomorrow Wednesday, Jun 10";
  } else if (lowercase.includes('thursday')) {
    targetDate.setDate(targetDate.getDate() + 2); // June 11
    dateExplanation = "This Thursday, Jun 11";
  } else if (lowercase.includes('friday')) {
    targetDate.setDate(targetDate.getDate() + 3); // June 12
    dateExplanation = "This Friday, Jun 12";
  } else if (lowercase.includes('saturday')) {
    targetDate.setDate(targetDate.getDate() + 4); // June 13
    dateExplanation = "This Saturday, Jun 13";
  } else if (lowercase.includes('sunday')) {
    targetDate.setDate(targetDate.getDate() + 5); // June 14
    dateExplanation = "This Sunday, Jun 14";
  } else {
    // Default: in 2 days (Thursday, June 11) to avoid busy today slots
    targetDate.setDate(targetDate.getDate() + 2);
    dateExplanation = "This Thursday, Jun 11";
  }

  const year = targetDate.getFullYear();
  const m = String(targetDate.getMonth() + 1).padStart(2, '0');
  const d = String(targetDate.getDate()).padStart(2, '0');
  const dateStr = `${year}-${m}-${d}`;

  // 4. Detect time slot
  let timeSlot = '11:00'; // morning default
  if (lowercase.includes('afternoon') || lowercase.includes('pm') || lowercase.includes('evening') || lowercase.includes('late')) {
    timeSlot = '14:30';
  } else if (lowercase.includes('morning') || lowercase.includes('am') || lowercase.includes('early')) {
    timeSlot = '09:30';
  } else if (lowercase.includes('noon') || lowercase.includes('lunch')) {
    timeSlot = '12:00';
  }

  // Adjust to match staff hours
  const startH = parseInt(matchedStaff.workingHours.start.split(':')[0]);
  const endH = parseInt(matchedStaff.workingHours.end.split(':')[0]);
  const currentSlotH = parseInt(timeSlot.split(':')[0]);

  if (currentSlotH < startH) {
    timeSlot = `${String(startH).padStart(2, '0')}:30`;
  } else if (currentSlotH >= endH) {
    timeSlot = `${String(endH - 1).padStart(2, '0')}:00`;
  }

  const explanation = `BookEase AI matched your request to a **${matchedService.name}** service with **${matchedStaff.name}** scheduled on **${dateExplanation}** at **${timeSlot}**.`;

  return {
    industry: detectedIndustry,
    service: matchedService,
    staff: matchedStaff,
    dateStr,
    timeSlot,
    explanation
  };
}
